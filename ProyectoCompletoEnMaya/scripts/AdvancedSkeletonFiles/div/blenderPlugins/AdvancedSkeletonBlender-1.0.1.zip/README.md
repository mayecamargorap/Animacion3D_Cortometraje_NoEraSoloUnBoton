# AdvancedSkeleton Blender 0.3.0-dev

From AdvancedSkeleton 6.8501
Last Modified 18/08/2026

Blender 5.2 LTS add-on for importing an AdvancedSkeleton FBX export and its
Body Rig JSON. This clean foundation intentionally stops after import and
validation; the native Blender rig builder will be rebuilt separately.

## Install

1. In Blender, open **Edit → Preferences → Get Extensions**.
2. Choose **Install from Disk…**.
3. Select `AdvancedSkeletonBlender.zip`.
4. Enable **AdvancedSkeleton Blender** if it is not enabled automatically.

## Use

1. In a 3D View, open the right sidebar and select the **AdvancedSkeleton** tab.
2. Choose **Import FBX**.
3. Choose the exported **Body JSON** file.
4. Click **Read Body JSON**.

The add-on reports the number of exported controls and JSON joint names that
match the imported skeleton. It does not build a rig yet.

## Development update

For an installed development copy, sync the add-on `__init__.py`, then reload
the add-on in Blender.

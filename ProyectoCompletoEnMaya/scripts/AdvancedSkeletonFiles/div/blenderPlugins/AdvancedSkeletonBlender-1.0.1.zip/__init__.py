﻿"""AdvancedSkeleton Blender: FBX + JSON compatibility importer and rig builder."""

import bpy
import importlib
import json
import os
import re
import sys
from math import cos, radians, sin
from pathlib import Path
from bpy_extras.io_utils import ImportHelper
from mathutils import Euler, Matrix, Quaternion, Vector


ADDON_VERSION = "1.0.1"
# The development source intentionally exposes rig-debug tools.  The release
# packager rewrites this one flag in its staging copy, so public ZIPs retain no
# Developer panel while the synced working install does.
DEVELOPER_BUILD = False
RIG_UI_TEXT_NAME = "AdvancedSkeleton_RigUI.py"
FACE_SOLVER_TEXT_NAME = "AdvancedSkeleton_FaceSolver.py"
FACE_DEBUG_OUTPUT_PATH = Path(r"C:\Users\me\Documents\Codex\Projects\AdvancedSkeletonBlender\FaceFearDiagnostic.txt")
MAIN_SCALE_DEBUG_OUTPUT_PATH = Path(r"C:\Users\me\Documents\Codex\Projects\AdvancedSkeletonBlender\MainScaleDiagnostic.txt")
_DEMO_BLEND_CACHE = {}

# This script is embedded in every generated .blend which uses Face SDKs.
# Blender executes it as a trusted text block, just like many shipped Blender
# rigs.  Unlike transform F-Curve drivers it evaluates all SDK inputs first,
# then writes each joint once from its captured build pose.
FACE_SOLVER_SCRIPT_TEMPLATE = '''import bpy
import math

# The builder substitutes a Python literal here (not JSON text), so Boolean
# values remain valid when this self-contained text block is executed.
FACE_SDK_DATA = __CONFIG_PYTHON__
_RUNNING = False


def _evaluate(keys, value):
    if not keys:
        return 0.0
    if len(keys) == 1:
        return keys[0][1]
    if value <= keys[0][0]:
        a, b = keys[0], keys[1]
    elif value >= keys[-1][0]:
        a, b = keys[-2], keys[-1]
    else:
        a, b = keys[0], keys[-1]
        for index in range(len(keys) - 1):
            if keys[index][0] <= value <= keys[index + 1][0]:
                a, b = keys[index], keys[index + 1]
                break
    width = b[0] - a[0]
    return a[1] if abs(width) < 0.0000001 else a[1] + (b[1] - a[1]) * ((value - a[0]) / width)


def _rig():
    return bpy.data.objects.get(FACE_SDK_DATA["rig"])


def _solve(*_args):
    global _RUNNING
    if _RUNNING:
        return
    rig = _rig()
    if rig is None or rig.type != "ARMATURE":
        return
    _RUNNING = True
    try:
        accum = {}
        for bone_name, record in FACE_SDK_DATA["bones"].items():
            accum[bone_name] = {
                "location": list(record["base_location"]),
                "rotation": list(record["base_rotation"]),
                "scale": list(record["base_scale"]),
            }
        for row in FACE_SDK_DATA["rows"]:
            source = rig.pose.bones.get(row["source_bone"])
            if source is None:
                continue
            if row["source_kind"] == "LOCATION":
                value = float(source.location[row["source_axis"]])
            elif row["source_kind"] == "ROTATION":
                value = float(source.rotation_euler[row["source_axis"]])
            elif row["source_kind"] == "SCALE":
                value = float(source.scale[row["source_axis"]])
            else:
                value = float(source.get(row["source_property"], 0.0))
            result = _evaluate(row["keys"], value) * row["multiplier"]
            target = accum.get(row["bone"])
            if target is None:
                continue
            if row["kind"] == "Translation":
                vector = row["vector"]
                for axis in range(3):
                    target["location"][axis] += result * vector[axis]
            elif row["kind"] == "Rotation":
                target["rotation"][row["axis"]] += math.radians(result)
            elif row["kind"] == "Scale":
                target["scale"][row["axis"]] *= 1.0 + result
        for bone_name, result in accum.items():
            bone = rig.pose.bones.get(bone_name)
            if bone is None:
                continue
            bone.location = result["location"]
            bone.rotation_mode = "XYZ"
            bone.rotation_euler = result["rotation"]
            bone.scale = result["scale"]

        # On-face controls are attached to facial joints so their displayed
        # shapes follow the skin.  Their *raw* Pose-Bone location is also the
        # SDK input, however.  Without cancelling that raw location in the
        # display offset, a dragged shape moves once as animator input and a
        # second time when its follow helper updates.  Preserve the authored
        # surface/pick offset and cancel only the entered local translation;
        # the SDK continues to read the unmodified pose channel above.
        for bone_name, display in FACE_SDK_DATA.get("on_face_display_controls", {}).items():
            bone = rig.pose.bones.get(bone_name)
            if bone is None:
                continue
            base = display.get("shape_translation", (0.0, 0.0, 0.0))
            bone.custom_shape_translation = tuple(
                float(base[index]) - float(bone.location[index])
                for index in range(3)
            )
    finally:
        _RUNNING = False


for handler in tuple(bpy.app.handlers.depsgraph_update_post):
    if getattr(handler, "_advanced_skeleton_face_solver", False):
        bpy.app.handlers.depsgraph_update_post.remove(handler)
_solve._advanced_skeleton_face_solver = True
bpy.app.handlers.depsgraph_update_post.append(_solve)
_solve()
'''

# This deliberately remains small.  It is stored inside the finished .blend,
# so an animator can use the panel without this authoring extension installed.
RIG_UI_SCRIPT = '''import bpy


def _advanced_skeleton_rig():
    return next(
        (
            obj for obj in bpy.data.objects
            if obj.type == "ARMATURE"
            and obj.get("advanced_skeleton_role") == "RIG"
        ),
        None,
    )


def _bone_collection(armature, name):
    def walk(collection):
        if collection.name == name:
            return collection
        for child in collection.children:
            found = walk(child)
            if found is not None:
                return found
        return None

    for collection in armature.collections:
        found = walk(collection)
        if found is not None:
            return found
    return None


def _reset_custom_properties(rig):
    for pose_bone in rig.pose.bones:
        for name in tuple(pose_bone.keys()):
            if str(name).startswith("_"):
                continue
            try:
                default = pose_bone.id_properties_ui(name).as_dict().get("default")
            except (AttributeError, TypeError):
                default = None
            if default is not None:
                pose_bone[name] = default


class ADVANCEDSKELETON_RIG_PT_settings(bpy.types.Panel):
    bl_label = "Rig Settings"
    bl_idname = "ADVANCEDSKELETON_RIG_PT_settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Rig Settings"

    def draw(self, context):
        layout = self.layout
        rig = _advanced_skeleton_rig()
        controls = _bone_collection(rig.data, "Controls") if rig else None
        main = rig.pose.bones.get("Main") if rig else None
        if controls is None or main is None or "ctrlVis" not in main:
            layout.label(text="No AdvancedSkeleton controls found.", icon="INFO")
            return
        layout.label(text="Visibility")
        # This is the exact Custom Property on Main, not a duplicate UI state.
        layout.prop(main, '["ctrlVis"]', text="Controls", toggle=True)
        layout.prop(main, '["geoVis"]', text="Geometry", toggle=True)
        active = context.active_pose_bone
        if active is not None:
            properties = [
                name for name in active.keys()
                if not str(name).startswith("_")
                and name not in {"ctrlVis", "geoVis", "version", "pluginVersion"}
            ]
            if properties:
                layout.separator()
                layout.label(text=active.name)
                for name in sorted(properties):
                    layout.prop(active, f'["{name}"]', text=name)
        layout.separator()
        layout.operator("advanced_skeleton_rig.go_to_build_pose", text="Go to Build Pose", icon="LOOP_BACK")


class ADVANCEDSKELETON_RIG_OT_go_to_build_pose(bpy.types.Operator):
    bl_idname = "advanced_skeleton_rig.go_to_build_pose"
    bl_label = "Go to Build Pose"

    def execute(self, context):
        rig = _advanced_skeleton_rig()
        if rig is None:
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        rig.select_set(True)
        context.view_layer.objects.active = rig
        bpy.ops.object.mode_set(mode="POSE")
        _reset_custom_properties(rig)
        bpy.ops.pose.select_all(action="SELECT")
        bpy.ops.pose.transforms_clear()
        bpy.ops.pose.select_all(action="DESELECT")
        return {"FINISHED"}


def register():
    for existing_name in (
        "ADVANCEDSKELETON_RIG_PT_settings",
        "ADVANCEDSKELETON_RIG_OT_go_to_build_pose",
    ):
        existing = getattr(bpy.types, existing_name, None)
        if existing is None:
            continue
        try:
            bpy.utils.unregister_class(existing)
        except RuntimeError:
            pass
    bpy.utils.register_class(ADVANCEDSKELETON_RIG_OT_go_to_build_pose)
    bpy.utils.register_class(ADVANCEDSKELETON_RIG_PT_settings)


def unregister():
    for cls in (ADVANCEDSKELETON_RIG_PT_settings, ADVANCEDSKELETON_RIG_OT_go_to_build_pose):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


register()
'''

bl_info = {
    "name": "AdvancedSkeleton Blender",
    "author": "AdvancedSkeleton",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > AdvancedSkeleton",
    "description": "Import an AdvancedSkeleton FBX export and Body JSON",
    "category": "Rigging",
}


def _armatures_from_scene(scene):
    """Return armatures belonging to the current AdvancedSkeleton import."""
    names = scene.get("as_import_armatures", [])
    return [
        bpy.data.objects[name]
        for name in names
        if name in bpy.data.objects and bpy.data.objects[name].type == "ARMATURE"
    ]


def _current_import_session_id(scene):
    return str(scene.get("as_import_session_id", ""))


def _current_import_objects(scene):
    """Return precisely the FBX objects belonging to the current import."""
    session_id = _current_import_session_id(scene)
    if not session_id:
        return []
    return [
        obj for obj in bpy.data.objects
        if obj.get("as_import_session_id") == session_id
    ]


def _has_current_import(scene):
    return bool(_current_import_objects(scene) or _armatures_from_scene(scene))


def _clear_current_import(scene):
    """Delete a tracked FBX import and its generated RIG, preserving settings."""
    objects = _current_import_objects(scene)
    current_object_names = {obj.name for obj in objects}
    objects.extend(
        obj for obj in bpy.data.objects
        if obj.get("advanced_skeleton_role") in {"GEOMETRY_GROUP", "WIDGET"}
        or (
            obj.type == "EMPTY"
            and (obj.name == "Geometry" or obj.name.startswith("Geometry."))
            and any(child.name in current_object_names for child in obj.children)
        )
    )
    sources = _armatures_from_scene(scene)
    rig = _generated_rig(scene)

    # Compatibility fallback for a scene imported before session tracking was
    # introduced. It removes the known armatures and their bound meshes, but
    # does not guess about unrelated Empty objects.
    if not objects:
        known_armatures = set(sources)
        if rig is not None:
            known_armatures.add(rig)
        objects = list(known_armatures)
        objects.extend(
            obj for obj in scene.objects
            if obj.type == "MESH" and any(
                modifier.type == "ARMATURE" and modifier.object in known_armatures
                for modifier in obj.modifiers
            )
        )

    unique_objects = {obj.name: obj for obj in objects}.values()
    object_data = [
        (obj, obj.data if obj.type in {"ARMATURE", "MESH"} else None)
        for obj in unique_objects
    ]
    for obj, _data in object_data:
        bpy.data.objects.remove(obj, do_unlink=True)
    for _obj, data in object_data:
        if data and data.users == 0:
            if isinstance(data, bpy.types.Armature):
                bpy.data.armatures.remove(data)
            elif isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)

    rig_collection = bpy.data.collections.get("AdvancedSkeleton")
    if rig_collection and not rig_collection.objects and not rig_collection.children:
        bpy.data.collections.remove(rig_collection)
    widgets_collection = bpy.data.collections.get("Widgets")
    if widgets_collection and not widgets_collection.objects and not widgets_collection.children:
        bpy.data.collections.remove(widgets_collection)
    for key in (
        "as_import_session_id",
        "as_import_armatures",
        "as_import_object_count",
        "as_import_body_json_loaded",
        "as_import_control_count",
        "as_import_declared_joint_count",
        "as_import_matched_joint_count",
        "as_rig_armature",
    ):
        if key in scene:
            del scene[key]


def _load_body_json(path_string):
    """Read and minimally validate the public AdvancedSkeleton Body JSON."""
    if not path_string:
        return None, "Choose a Body JSON file first."
    path = Path(path_string)
    try:
        with path.open("r", encoding="utf-8") as stream:
            data = json.load(stream)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        return None, f"Could not read Body JSON: {error}"

    if data.get("exportType") != "AdvancedSkeletonBodyRig":
        return None, "This is not an AdvancedSkeleton Body Rig JSON export."
    rig = data.get("rig")
    if not isinstance(rig, dict):
        return None, "Body JSON has no valid rig definition."
    controls = rig.get("controls")
    if not isinstance(controls, list):
        return None, "Body JSON has no valid controls list."
    return data, ""


def _load_face_json(path_string):
    """Read the optional AdvancedSkeleton Face SDK JSON export."""
    if not path_string:
        return None, ""
    path = Path(path_string)
    try:
        with path.open("r", encoding="utf-8") as stream:
            data = json.load(stream)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        return None, f"Could not read Face JSON: {error}"
    if not isinstance(data.get("drivers"), list):
        return None, "This is not an AdvancedSkeleton Face JSON export."
    return data, ""


def _add_face_emotion_properties(armature, face_data, allowed_channels=None):
    """Expose ctrlEmotions_M's animator channels on the existing FKHead_M.

    This intentionally does *not* create a solver or a new face controller.
    It is the small first compatibility step: validate the Face JSON schema
    and present its actual animator-facing channels on an existing control.
    """
    if not face_data:
        return 0
    head = armature.pose.bones.get("FKHead_M")
    if head is None:
        return 0
    added = 0
    seen = set()
    for driver in face_data.get("drivers", []):
        if not isinstance(driver, dict) or driver.get("control") != "ctrlEmotions_M":
            continue
        name = str(driver.get("channel", ""))
        if (
            not name
            or name in seen
            or (allowed_channels is not None and name not in allowed_channels)
        ):
            continue
        seen.add(name)
        head[name] = 0.0
        head.id_properties_ui(name).update(
            default=0.0,
            min=float(driver.get("mayaDriverMin", 0.0)),
            max=float(driver.get("mayaDriverMax", 10.0)),
            description=f"Face emotion ({name}) from ctrlEmotions_M",
        )
        added += 1
    return added


def _add_face_brow_right_properties(armature, face_data):
    """Expose every exported SDK channel for the right brow controller."""
    head = armature.pose.bones.get("FKHead_M")
    if head is None:
        return 0
    added = 0
    sources = [
        item for item in face_data.get("drivers", [])
        if isinstance(item, dict)
        and item.get("control") == "ctrlBrow_R"
    ]
    for source in sources:
        control = str(source.get("control", ""))
        channel = str(source.get("channel", ""))
        maya_channel = str(source.get("mayaAttribute", channel)).rsplit(".", 1)[-1]
        name = f"{control}.{maya_channel}"
        head[name] = 0.0
        head.id_properties_ui(name).update(
            default=0.0,
            min=float(source.get("mayaDriverMin", -1.0)),
            max=float(source.get("mayaDriverMax", 1.0)),
            description=f"Direct Face SDK test: Maya {name}",
        )
        added += 1
    return added


def _add_all_face_properties(armature, face_data):
    """Expose every exported Face JSON driver property on FKHead_M.

    This is intentionally a performance/behaviour proof for the final
    self-contained solver.  The actual face controls can later receive these
    properties directly; placing them on FKHead_M keeps this test compact.
    """
    head = armature.pose.bones.get("FKHead_M")
    if head is None:
        return 0
    added = 0
    seen = set()
    for source in face_data.get("drivers", []):
        if not isinstance(source, dict):
            continue
        control = str(source.get("control", ""))
        channel = str(source.get("channel", ""))
        if not control or not channel:
            continue
        maya_channel = str(source.get("mayaAttribute", channel)).rsplit(".", 1)[-1]
        name = f"{control}.{maya_channel}"
        if name in seen:
            continue
        seen.add(name)
        head[name] = 0.0
        head.id_properties_ui(name).update(
            default=0.0,
            min=float(source.get("mayaDriverMin", 0.0)),
            max=float(source.get("mayaDriverMax", 10.0)),
            description=f"Face SDK: {control}.{channel}",
        )
        added += 1
    return added


def _add_face_jaw_test(armature):
    """Small, deliberately obvious first Face SDK test.

    One animator property on FKHead_M moves JawJoint_M straight down in world
    space.  This is intentionally independent of the broad Maya emotion SDK;
    it lets us prove the Armature face pipeline with one understandable result.
    """
    head = armature.pose.bones.get("FKHead_M")
    jaw = armature.pose.bones.get("JawJoint_M")
    if head is None or jaw is None:
        return 0
    head["Jaw"] = 0.0
    head.id_properties_ui("Jaw").update(
        default=0.0,
        min=0.0,
        max=10.0,
        description="Move JawJoint_M downward (face SDK test)",
    )
    # A value of 10 moves the jaw 0.12 Blender world units downward. Convert
    # that once into its parent bind space, then use normal pose drivers.
    down_local = _maya_world_delta_to_blender_local(
        armature, jaw, "Y",
    ) * -0.12
    for axis, amount in enumerate(down_local):
        if abs(amount) < 0.0000001:
            continue
        _add_face_emotion_driver(
            jaw, "location", axis,
            [{
                "source": "Jaw",
                "keys": [{"x": 0.0, "y": 0.0}, {"x": 10.0, "y": amount}],
                "multiplier": 1.0,
            }],
            armature,
        )
    return 1


def _face_sdk_axis(channel):
    """Return an exported face joint's authored *local* transform axis.

    The FBX armature object carries the scene axis conversion.  Local SDK
    channels therefore remain in the exported joint's X/Y/Z basis; converting
    them as world vectors was the source of the previous jaw/eyelid errors.
    """
    return {
        "X": (0, 1.0),
        "Y": (1, 1.0),
        "Z": (2, 1.0),
    }.get(str(channel).rsplit(".", 1)[-1], (0, 1.0))


def _maya_row_matrix_rotation(values):
    """Convert a Maya row-major/rest-basis matrix to Blender rotation."""
    if not isinstance(values, (list, tuple)) or len(values) != 16:
        return None
    try:
        # Maya xform matrices use row-vector layout; transpose into
        # mathutils' column-vector basis before extracting a quaternion.
        matrix = Matrix((
            (float(values[0]), float(values[4]), float(values[8])),
            (float(values[1]), float(values[5]), float(values[9])),
            (float(values[2]), float(values[6]), float(values[10])),
        ))
        return matrix.normalized().to_quaternion()
    except (TypeError, ValueError):
        return None


def _blender_bone_local_rest_rotation(bone):
    """Return a Blender bone's rest basis relative to its parent."""
    matrix = bone.matrix_local.copy()
    if bone.parent is not None:
        matrix = bone.parent.matrix_local.inverted() @ matrix
    return matrix.to_3x3().normalized().to_quaternion()


def _maya_world_delta_to_blender_local(armature, pose_bone, maya_axis):
    """Return pose-location coefficients for one exported face SDK axis.

    Despite their historic ``World Translation`` label, the AdvancedSkeleton
    face-export vectors are already expressed in the FBX controller frame:
    X is left/right, Y is depth, Z is up.  The imported armature object holds
    the Maya-to-Blender conversion itself.  Applying a second Y-up conversion
    here made e.g. eyebrow Z (up) become Blender Y (forward).
    """
    exported_to_blender_world = {
        "X": Vector((1.0, 0.0, 0.0)),
        # Face depth has the opposite sign in Blender's imported character
        # view: positive exported Y is toward the face/front.
        "Y": Vector((0.0, -1.0, 0.0)),
        "Z": Vector((0.0, 0.0, 1.0)),
    }
    delta_world = exported_to_blender_world.get(maya_axis, Vector((0.0, 0.0, 0.0)))
    # The FBX armature itself can carry the Maya-to-Blender import transform.
    delta_armature = armature.matrix_world.to_3x3().inverted_safe() @ delta_world
    # ``PoseBone.location`` is expressed in the driven bone's own rest basis,
    # not simply its parent's basis.  This distinction matters particularly
    # for mirrored facial bones: feeding parent-space values made L/R brows
    # react in different directions.  Convert through the driven rest matrix
    # so the same Maya world delta is reconstructed in Blender world space.
    return pose_bone.bone.matrix_local.to_3x3().inverted_safe() @ delta_armature


def _face_sdk_expression(variable, keys, multiplier, radians_output=False, scale_output=False):
    """Return a clamped, piecewise-linear Blender driver expression.

    The current emotion SDK keys are two-point (0 to 10), but this also
    preserves a three-point curve should one appear in a future export.
    """
    values = []
    for key in keys if isinstance(keys, list) else []:
        try:
            values.append((float(key["x"]), float(key["y"])))
        except (KeyError, TypeError, ValueError):
            continue
    values.sort()
    if len(values) < 2:
        return "1.0" if scale_output else "0.0"
    pieces = [f"{values[0][1]:.10g}"]
    for index in range(len(values) - 1):
        start_x, start_y = values[index]
        end_x, end_y = values[index + 1]
        width = end_x - start_x
        if abs(width) < 0.0000001:
            continue
        slope = (end_y - start_y) / width
        amount = f"min(max({variable}-{start_x:.10g},0),{width:.10g})"
        pieces.append(f"({slope:.10g})*({amount})")
    expression = "(" + "+".join(pieces) + ")"
    factor = float(multiplier)
    if radians_output:
        factor *= 0.017453292519943295
    if factor != 1.0:
        expression = f"({factor:.12g})*{expression}"
    return f"1.0+{expression}" if scale_output else expression


def _add_face_emotion_driver(owner, data_path, axis, terms, armature, radians_output=False, scale_output=False, replace_existing=True):
    """Add one self-contained Blender driver accumulating emotion SDK keys."""
    if replace_existing:
        try:
            owner.driver_remove(data_path, axis)
        except (TypeError, ValueError):
            pass
    driver = owner.driver_add(data_path, axis).driver
    driver.type = "SCRIPTED"
    expression_terms = []
    for index, term in enumerate(terms):
        variable = driver.variables.new()
        variable.name = f"emotion_{index}"
        variable.type = "SINGLE_PROP"
        target = variable.targets[0]
        target.id = armature
        target.data_path = f'pose.bones["FKHead_M"]["{term["source"]}"]'
        expression_terms.append(
            _face_sdk_expression(
                variable.name,
                term["keys"],
                term["multiplier"],
                radians_output=radians_output,
                scale_output=False,
            )
        )
    expression = "+".join(expression_terms) if expression_terms else "0.0"
    driver.expression = f"1.0+({expression})" if scale_output else expression


def _disconnect_face_sdk_bones(context, armature, bone_names):
    """Allow face SDK location channels on otherwise-connected FBX bones."""
    if not bone_names:
        return
    if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    for bone_name in bone_names:
        edit_bone = armature.data.edit_bones.get(bone_name)
        if edit_bone is not None:
            edit_bone.use_connect = False
    bpy.ops.object.mode_set(mode="OBJECT")
    for bone_name in bone_names:
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is not None:
            pose_bone.lock_location = (False, False, False)


def _build_face_emotions_solver(context, armature, face_data, allowed_channels=None, controls=None, allowed_pairs=None):
    """Compile ctrlEmotions_M SDK relationships into Blender-native drivers."""
    if not face_data or armature.pose.bones.get("FKHead_M") is None:
        return 0
    # Clean the short-lived helper-constraint experiment from earlier builds.
    # Rebuilds are intentionally in-place, so leaving these behind would make
    # the new native parent-space drivers appear to be wrong as well.
    for pose_bone in armature.pose.bones:
        for constraint in tuple(pose_bone.constraints):
            if constraint.name in {"AS_FaceEmotion_Location", "AS_FaceEmotion_Rotation"}:
                pose_bone.constraints.remove(constraint)
    rows = []
    allowed_controls = set(controls or {"ctrlEmotions_M"})
    for source in face_data.get("drivers", []):
        if not isinstance(source, dict) or source.get("control") not in allowed_controls:
            continue
        source_name = str(source.get("channel", ""))
        if (
            not source_name
            or (allowed_channels is not None and source_name not in allowed_channels)
            or (allowed_pairs is not None and (source.get("control"), source_name) not in allowed_pairs)
        ):
            continue
        for driven in source.get("driven", []):
            if not isinstance(driven, dict):
                continue
            bone_name = str(driven.get("bone", ""))
            channel = str(driven.get("channel", ""))
            if bone_name not in armature.pose.bones or "." not in channel:
                continue
            property_name = source_name
            if source.get("control") != "ctrlEmotions_M":
                property_name = f'{source.get("control")}.{str(source.get("mayaAttribute", source_name)).rsplit(".", 1)[-1]}'
            rows.append({
                "source": property_name,
                "bone": bone_name,
                "channel": channel,
                "space": str(driven.get("space", "Local")),
                "keys": driven.get("keys", []),
                "multiplier": float(driven.get("multiplier", 1.0)),
            })
    if not rows:
        return 0

    # Imported facial chains are commonly marked as connected.  That is fine
    # for drawing the FBX skeleton, but Blender then locks their pose-location
    # to the parent's tail.  The Maya face SDK explicitly animates these bones
    # in world translation, so disconnect only the affected bones while
    # retaining their parent hierarchy and skinning relationship.
    _disconnect_face_sdk_bones(
        context,
        armature,
        {
            row["bone"] for row in rows
            if row["space"] == "World" and row["channel"].startswith("Translation.")
        },
    )

    # Blender's PoseBone.driver_remove(path, index) can remove the complete
    # array-property driver group, not only the requested component.  Clearing
    # once here, before rebuilding, preserves all X/Y/Z drivers we add below.
    # The previous per-axis clear is why a brow with authored X+Y movement
    # received only its final axis.
    # This isolated test replaces the earlier broad face experiment.  Remove
    # all previously-authored face transform drivers first, not only the six
    # brow targets, so zero-valued emotion drivers cannot remain in the rig.
    driven_bones = {
        str(driven.get("bone", ""))
        for source in face_data.get("drivers", []) if isinstance(source, dict)
        for driven in source.get("driven", []) if isinstance(driven, dict)
        if str(driven.get("bone", "")) in armature.pose.bones
    }
    for bone_name in driven_bones:
        pose_bone = armature.pose.bones[bone_name]
        for data_path in ("location", "rotation_euler", "scale"):
            try:
                pose_bone.driver_remove(data_path)
            except (TypeError, ValueError):
                pass

    # Compile to final Blender pose components first.  A component must get
    # exactly ONE F-Curve driver: ``driver_add`` returns the pre-existing
    # component driver, so separate local/world passes silently overwrite each
    # other instead of adding.  This was the source of the apparent
    # zero-valued properties competing with the active property.
    outputs = {}

    def add_output(bone_name, data_path, axis, terms, *, radians=False, scale=False):
        key = (bone_name, data_path, axis)
        entry = outputs.setdefault(key, {"terms": [], "radians": radians, "scale": scale})
        entry["terms"].extend(terms)

    for row in rows:
        bone_name = row["bone"]
        kind, _dot, authored_axis = row["channel"].partition(".")
        if row["space"] == "World" and kind == "Translation":
            coefficients = _maya_world_delta_to_blender_local(
                armature, armature.pose.bones[bone_name], authored_axis,
            )
            for blender_axis, coefficient in enumerate(coefficients):
                if abs(coefficient) >= 0.0000001:
                    add_output(
                        bone_name, "location", blender_axis,
                        [dict(row, multiplier=row["multiplier"] * coefficient)],
                    )
            continue

        axis, sign = _face_sdk_axis(row["channel"])
        term = [dict(row, multiplier=row["multiplier"] * sign)]
        if kind == "Translation":
            add_output(bone_name, "location", axis, term)
        elif kind == "Rotation":
            armature.pose.bones[bone_name].rotation_mode = "XYZ"
            add_output(bone_name, "rotation_euler", axis, term, radians=True)
        elif kind == "Scale":
            add_output(bone_name, "scale", axis, term, scale=True)

    created = 0
    for (bone_name, data_path, axis), entry in outputs.items():
        _add_face_emotion_driver(
            armature.pose.bones[bone_name], data_path, axis, entry["terms"], armature,
            radians_output=entry["radians"], scale_output=entry["scale"],
            replace_existing=True,
        )
        created += 1
    return created


def _face_source_descriptor(source):
    """Return the native Pose Bone source channel for one Face JSON driver."""
    control = str(source.get("control", ""))
    attribute = str(source.get("mayaAttribute", source.get("channel", ""))).rsplit(".", 1)[-1]
    normalized = attribute.lower()
    transform_channels = {
        "translatex": ("LOCATION", 0),
        "translatey": ("LOCATION", 1),
        "translatez": ("LOCATION", 2),
        # On-face controls are exported with Maya's short channel names.
        # Treat them as the native Blender transform channels too, rather
        # than incorrectly creating inert custom properties named ``tx``.
        "tx": ("LOCATION", 0),
        "ty": ("LOCATION", 1),
        "tz": ("LOCATION", 2),
        "rotatex": ("ROTATION", 0),
        "rotatey": ("ROTATION", 1),
        "rotatez": ("ROTATION", 2),
        "rx": ("ROTATION", 0),
        "ry": ("ROTATION", 1),
        "rz": ("ROTATION", 2),
        "scalex": ("SCALE", 0),
        "scaley": ("SCALE", 1),
        "scalez": ("SCALE", 2),
        "sx": ("SCALE", 0),
        "sy": ("SCALE", 1),
        "sz": ("SCALE", 2),
    }
    kind_axis = transform_channels.get(normalized)
    if kind_axis is not None:
        return {
            "source_bone": control,
            "source_kind": kind_axis[0],
            "source_axis": kind_axis[1],
            "source_property": "",
        }
    return {
        "source_bone": control,
        "source_kind": "PROPERTY",
        "source_axis": 0,
        "source_property": attribute,
    }


def _add_face_control_properties(armature, face_data, controls):
    """Add only real non-transform Face attributes to their own controls.

    Translate/rotate/scale drivers use the pose bone's native channels.  This
    keeps the animator workflow recognisably Blender instead of adding fake
    `translateX` properties beside the actual transform fields.
    """
    created = 0
    seen = set()
    for source in face_data.get("drivers", []):
        if not isinstance(source, dict):
            continue
        control = str(source.get("control", ""))
        if control not in controls:
            continue
        descriptor = _face_source_descriptor(source)
        if descriptor["source_kind"] != "PROPERTY":
            continue
        name = descriptor["source_property"]
        pose_bone = armature.pose.bones.get(control)
        if pose_bone is None or not name or (control, name) in seen:
            continue
        seen.add((control, name))
        try:
            minimum = float(source.get("mayaDriverMin", 0.0))
            maximum = float(source.get("mayaDriverMax", 10.0))
            default = float(source.get("mayaDriverDefault", 0.0))
        except (TypeError, ValueError):
            minimum, maximum, default = 0.0, 10.0, 0.0
        if name not in pose_bone:
            pose_bone[name] = default
            created += 1
        pose_bone.id_properties_ui(name).update(
            default=default, min=minimum, max=maximum,
            description=f"AdvancedSkeleton Face: {control}.{name}",
        )
    return created


def _ensure_embedded_face_solver(
    context, armature, face_data, *, controls, allowed_pairs=None,
    on_face_display_controls=None,
):
    """Embed and activate one accumulated face solver for the generated rig.

    This is intentionally different from Blender transform drivers: all face
    properties are sampled in one pass and each pose bone is written once from
    its build-pose transform.  That matches the AdvancedSkeleton/Unreal face
    solver behaviour and avoids competing F-Curves on shared joints.
    """
    if not face_data:
        return 0

    rows = []
    for source in face_data.get("drivers", []):
        if not isinstance(source, dict) or source.get("control") not in controls:
            continue
        channel_name = str(source.get("channel", ""))
        if allowed_pairs is not None and (source.get("control"), channel_name) not in allowed_pairs:
            continue
        source_descriptor = _face_source_descriptor(source)
        for driven in source.get("driven", []):
            if not isinstance(driven, dict):
                continue
            bone_name = str(driven.get("bone", ""))
            channel = str(driven.get("channel", ""))
            pose_bone = armature.pose.bones.get(bone_name)
            kind, _dot, authored_axis = channel.partition(".")
            if pose_bone is None or kind not in {"Translation", "Rotation", "Scale"}:
                continue
            keys = []
            for key in driven.get("keys", []):
                try:
                    keys.append([float(key["x"]), float(key["y"])])
                except (KeyError, TypeError, ValueError):
                    continue
            if not keys:
                continue
            keys.sort(key=lambda item: item[0])
            axis, sign = _face_sdk_axis(channel)
            row = {
                **source_descriptor,
                "bone": bone_name,
                "kind": kind,
                "axis": axis,
                "keys": keys,
                "multiplier": (
                    float(driven.get("multiplier", 1.0))
                    * sign
                    * float(source.get("_as_input_scale", 1.0))
                ),
                "vector": [0.0, 0.0, 0.0],
            }
            # The current Blender FBX import represents Tongue local rotation
            # opposite to the direct Maya SDK Euler response.  Keep this
            # narrow release compatibility rule here; all other face joints,
            # including Jaw, retain their established direct local solver.
            if kind == "Rotation" and bone_name.startswith("Tongue"):
                row["multiplier"] *= -1.0
            # The exported EyeJoint aim SDK is the one facial exception to
            # the otherwise direct local-rotation mapping: its left/right
            # aim channel is mirrored by the Maya-FBX-to-Blender conversion.
            # Lid joints use their normal local bases and must remain
            # untouched.  Limit this to the authored eyeball aim relation,
            # rather than flipping an entire controller or face side.
            if (
                kind == "Rotation"
                and bone_name.startswith("EyeJoint_")
                and str(source.get("control", "")).startswith("ctrlEye_")
                and str(source.get("mayaAttribute", "")).rsplit(".", 1)[-1].lower() == "translatex"
            ):
                row["multiplier"] *= -1.0
            if kind == "Translation":
                if str(driven.get("space", "Local")) == "World":
                    row["vector"] = list(_maya_world_delta_to_blender_local(
                        armature, pose_bone, authored_axis,
                    ))
                else:
                    row["vector"][axis] = 1.0
            rows.append(row)
    if not rows:
        return 0

    affected_bones = sorted({row["bone"] for row in rows})
    _disconnect_face_sdk_bones(
        context, armature,
        {row["bone"] for row in rows if row["kind"] == "Translation"},
    )

    # The embedded solver exclusively owns face transforms.  Remove every
    # previous experimental F-Curve driver once, before recording base poses.
    for bone_name in affected_bones:
        pose_bone = armature.pose.bones[bone_name]
        for data_path in ("location", "rotation_euler", "scale"):
            try:
                pose_bone.driver_remove(data_path)
            except (TypeError, ValueError):
                pass

    config = {
        "rig": armature.name,
        "rows": rows,
        # Only these on-face controls need visual input cancellation.  Box
        # controls deliberately display their own normal panel travel.
        "on_face_display_controls": on_face_display_controls or {},
        "bones": {
            bone_name: {
                "base_location": list(armature.pose.bones[bone_name].location),
                "base_rotation": list(armature.pose.bones[bone_name].rotation_euler),
                "base_scale": list(armature.pose.bones[bone_name].scale),
            }
            for bone_name in affected_bones
        },
    }
    text = bpy.data.texts.get(FACE_SOLVER_TEXT_NAME)
    if text is None:
        text = bpy.data.texts.new(FACE_SOLVER_TEXT_NAME)
    text.clear()
    text.write(FACE_SOLVER_SCRIPT_TEMPLATE.replace("__CONFIG_PYTHON__", repr(config)))
    text.use_module = True
    # Activate immediately in the current Blender session.  On a saved rig,
    # Blender will run this trusted text block when the user allows scripts.
    namespace = {"__name__": FACE_SOLVER_TEXT_NAME, "__file__": FACE_SOLVER_TEXT_NAME}
    exec(compile(text.as_string(), FACE_SOLVER_TEXT_NAME, "exec"), namespace, namespace)
    return len(rows)


def _remove_embedded_face_solver():
    """Remove the previous generated face solver before rebuilding the body."""
    for handler in tuple(bpy.app.handlers.depsgraph_update_post):
        if getattr(handler, "_advanced_skeleton_face_solver", False):
            bpy.app.handlers.depsgraph_update_post.remove(handler)
    text = bpy.data.texts.get(FACE_SOLVER_TEXT_NAME)
    if text is not None:
        bpy.data.texts.remove(text)


def _face_sdk_value_at_end(keys):
    """Return the value at the largest authored SDK key."""
    values = []
    for key in keys if isinstance(keys, list) else []:
        try:
            values.append((float(key["x"]), float(key["y"])))
        except (KeyError, TypeError, ValueError):
            continue
    return max(values)[1] if values else 0.0


def _write_fear_face_diagnostic(scene, context):
    """Record actual Fear 0/10 results for Maya/Blender space comparison."""
    armature = _generated_rig(scene)
    face_data, error = _load_face_json(scene.advanced_skeleton_face_json_path)
    if armature is None or face_data is None:
        return None, error or "Build the rig and choose a Face JSON first."

    targets = sorted({
        str(driven.get("bone", ""))
        for driver in face_data.get("drivers", [])
        if isinstance(driver, dict)
        and driver.get("control") == "ctrlEmotions_M"
        and driver.get("channel") == "fear"
        for driven in driver.get("driven", [])
        if isinstance(driven, dict) and str(driven.get("bone", "")) in armature.pose.bones
    })
    world_deltas = {name: Vector((0.0, 0.0, 0.0)) for name in targets}
    local_rows = {name: [] for name in targets}
    for driver in face_data.get("drivers", []):
        if not isinstance(driver, dict) or driver.get("control") != "ctrlEmotions_M" or driver.get("channel") != "fear":
            continue
        for driven in driver.get("driven", []):
            if not isinstance(driven, dict):
                continue
            name = str(driven.get("bone", ""))
            if name not in world_deltas:
                continue
            channel = str(driven.get("channel", ""))
            value = _face_sdk_value_at_end(driven.get("keys", [])) * float(driven.get("multiplier", 1.0))
            if driven.get("space") == "World" and channel.startswith("Translation."):
                axis = channel.rsplit(".", 1)[-1]
                world_deltas[name] += {
                    "X": Vector((value, 0.0, 0.0)),
                    "Y": Vector((0.0, value, 0.0)),
                    "Z": Vector((0.0, 0.0, value)),
                }.get(axis, Vector())
            else:
                local_rows[name].append(f"{channel}={value:.6g} ({driven.get('space', 'Local')})")

    # Capture the actual rig result at 0 and 10, then leave the animator's
    # property exactly where it was. This gives us evidence rather than a
    # guessed coordinate conversion.
    head = armature.pose.bones.get("FKHead_M")
    previous_fear = float(head.get("fear", 0.0)) if head else 0.0
    if head is not None:
        head["fear"] = 0.0
    armature.update_tag()
    context.view_layer.update()
    evaluated_armature = armature.evaluated_get(context.evaluated_depsgraph_get())
    pose_zero = {
        name: evaluated_armature.matrix_world @ evaluated_armature.pose.bones[name].matrix.translation
        for name in targets
    }
    local_zero = {
        name: (
            armature.pose.bones[name].location.copy(),
            armature.pose.bones[name].rotation_euler.copy(),
            armature.pose.bones[name].scale.copy(),
        )
        for name in targets
    }
    if head is not None:
        head["fear"] = 10.0
    armature.update_tag()
    context.view_layer.update()
    evaluated_armature = armature.evaluated_get(context.evaluated_depsgraph_get())
    pose_ten = {
        name: evaluated_armature.matrix_world @ evaluated_armature.pose.bones[name].matrix.translation
        for name in targets
    }
    local_ten = {
        name: (
            armature.pose.bones[name].location.copy(),
            armature.pose.bones[name].rotation_euler.copy(),
            armature.pose.bones[name].scale.copy(),
        )
        for name in targets
    }
    if head is not None:
        head["fear"] = previous_fear
    armature.update_tag()
    context.view_layer.update()

    lines = [
        "ADVANCEDSKELETON FACE DEBUG â€” fear at 10",
        "Automatically captured Blender world-position deltas: Fear 0 -> 10.",
        f"Armature world matrix: {tuple(round(value, 6) for row in armature.matrix_world for value in row)}",
        f"FKHead_M fear after test restore: {float(head.get('fear', 0.0)) if head else '<missing>'}",
        f"Registered armature drivers: {len(armature.animation_data.drivers) if armature.animation_data else 0}",
        "",
    ]
    for name in targets:
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            lines.append(f"{name}: MISSING FROM FBX")
            continue
        maya_delta = world_deltas[name]
        blender_world = Vector((maya_delta.x, -maya_delta.z, maya_delta.y))
        blender_local = sum(
            (_maya_world_delta_to_blender_local(armature, pose_bone, axis) * value
             for axis, value in zip(("X", "Y", "Z"), maya_delta)),
            Vector((0.0, 0.0, 0.0)),
        )
        lines.extend((
            name,
            f"  parent: {pose_bone.parent.name if pose_bone.parent else '<armature>'}",
            f"  Maya world translation delta: {tuple(round(value, 6) for value in maya_delta)}",
            f"  Blender world delta used: {tuple(round(value, 6) for value in blender_world)}",
            f"  Blender parent-local driver delta: {tuple(round(value, 6) for value in blender_local)}",
            f"  ACTUAL Blender world delta: {tuple(round(value, 6) for value in (pose_ten[name] - pose_zero[name]))}",
            f"  ACTUAL pose location delta: {tuple(round(value, 6) for value in (local_ten[name][0] - local_zero[name][0]))}",
            f"  ACTUAL pose rotation delta: {tuple(round(value, 6) for value in (Vector(local_ten[name][1]) - Vector(local_zero[name][1])))}",
            f"  ACTUAL pose scale delta: {tuple(round(value, 6) for value in (local_ten[name][2] - local_zero[name][2]))}",
            f"  Local SDK rows: {', '.join(local_rows[name]) or '<none>'}",
            "",
        ))
    try:
        FACE_DEBUG_OUTPUT_PATH.write_text("\n".join(lines), encoding="utf-8")
    except OSError as write_error:
        return None, f"Could not write Face debug report: {write_error}"
    return FACE_DEBUG_OUTPUT_PATH, ""


def _set_status(scene, message):
    scene["as_import_status"] = message


def _write_face_control_box_debug(scene, context):
    """Write concise face-placement and active Spline scale diagnostics."""
    armature = _generated_rig(scene)
    face_data, error = _load_face_json(scene.advanced_skeleton_face_json_path)
    if armature is None or face_data is None:
        return None, error or "Build the Body Rig and choose a Face JSON first."
    reference = _face_reference_bone(armature, face_data)
    rig_data = face_data.get("rig", {}) if isinstance(face_data, dict) else {}
    lines = [
        "ADVANCEDSKELETON FACE CONTROL BOX DEBUG",
        f"Armature: {armature.name}",
        f"Armature scale: {tuple(round(value, 6) for value in armature.matrix_world.to_scale())}",
        f"Face reference: {reference.name if reference else '<missing>'}",
        f"JSON ctrlBoxOffsetWorldLocation: {rig_data.get('ctrlBoxOffsetWorldLocation')}",
        f"JSON ctrlBoxOffsetWorldRotation: {rig_data.get('ctrlBoxOffsetWorldRotation')}",
        f"JSON ctrlBoxShapeLocation: {rig_data.get('ctrlBoxShapeLocation')}",
        f"JSON ctrlBoxShapeScale: {rig_data.get('ctrlBoxShapeScale')}",
        "",
    ]
    for name in ("FaceJoint_M", "Head_M", "ctrlBoxAttach", "ctrlBoxOffset", "ctrlBox"):
        pose = armature.pose.bones.get(name)
        if pose is None:
            lines.append(f"{name}: MISSING")
            continue
        world = armature.matrix_world @ pose.matrix
        lines.extend((
            name,
            f"  parent: {pose.parent.name if pose.parent else '<none>'}",
            f"  world location: {tuple(round(value, 6) for value in world.translation)}",
            f"  rest location: {tuple(round(value, 6) for value in pose.bone.matrix_local.translation)}",
            f"  constraints: {', '.join(item.name for item in pose.constraints) or '<none>'}",
        ))

    # Targeted evidence for the mouth-open/tongue issue.  This only reports
    # evaluated axes and authored SDK rows; it deliberately does not pose or
    # reset any control while the animator is testing.
    mouth = armature.pose.bones.get("ctrlMouth_M")
    mouth_rows = [
        source for source in face_data.get("drivers", [])
        if isinstance(source, dict)
        and source.get("control") == "ctrlMouth_M"
        and str(source.get("mayaAttribute", "")).lower().endswith(".translatey")
    ]
    if mouth is not None or mouth_rows:
        lines.extend(("", "MOUTH OPEN / TONGUE DEBUG"))
        if mouth is not None:
            lines.append(
                "ctrlMouth_M pose location: "
                f"{tuple(round(value, 6) for value in mouth.location)}"
            )
        for source in mouth_rows:
            lines.append(
                f"Source: {source.get('control')}.{source.get('mayaAttribute')} "
                f"(channel {source.get('channel')})"
            )
            for driven in source.get("driven", []):
                if not isinstance(driven, dict) or driven.get("bone") not in {"JawJoint_M", "Tongue0Joint_M"}:
                    continue
                lines.append(
                    f"  {driven.get('bone')} {driven.get('channel')} "
                    f"space={driven.get('space')} multiplier={driven.get('multiplier')} "
                    f"keys={driven.get('keys')}"
                )
        for name in ("JawJoint_M", "Tongue0Joint_M"):
            pose = armature.pose.bones.get(name)
            if pose is None:
                lines.append(f"{name}: MISSING")
                continue
            rest_axes = pose.bone.matrix_local.to_3x3()
            pose_axes = pose.matrix_basis.to_3x3()
            lines.extend((
                name,
                f"  rotation mode: {pose.rotation_mode}",
                f"  rest local axes X/Y/Z: {tuple(tuple(round(v, 6) for v in rest_axes.col[i]) for i in range(3))}",
                f"  current pose-basis axes X/Y/Z: {tuple(tuple(round(v, 6) for v in pose_axes.col[i]) for i in range(3))}",
                f"  current pose quaternion: {tuple(round(v, 6) for v in pose.rotation_quaternion)}",
            ))

    # Keep the existing generic Write Debug button useful while working on
    # body systems too.  This reports evaluated control/joint scale values
    # from the currently built rig; it does not alter the pose.
    body_data, _body_error = _load_body_json(scene.advanced_skeleton_body_json_path)
    if body_data is not None:
        spline_specs = _spline_ik_specs(body_data)
        if spline_specs:
            lines.extend(("", "SPLINE IK SCALE DEBUG"))
        for system, joint_names, controls in spline_specs:
            lines.append(f"System: {system.get('name', 'Spline')}")
            for control in controls:
                name = str(control.get("name", ""))
                pose = armature.pose.bones.get(name)
                if pose is None:
                    lines.append(f"  Control {name}: MISSING")
                    continue
                world_scale = (armature.matrix_world @ pose.matrix).to_scale()
                lines.append(
                    f"  Control {name}: local scale {tuple(round(v, 5) for v in pose.scale)}, "
                    f"world scale {tuple(round(v, 5) for v in world_scale)}"
                )
            for joint_name in joint_names:
                pose = armature.pose.bones.get(joint_name)
                bone = armature.data.bones.get(joint_name)
                if pose is None or bone is None:
                    lines.append(f"  Joint {joint_name}: MISSING")
                    continue
                world_scale = (armature.matrix_world @ pose.matrix).to_scale()
                scale_drivers = [
                    curve.data_path for curve in (armature.animation_data.drivers if armature.animation_data else [])
                    if curve.data_path == f'pose.bones["{joint_name}"].scale'
                ]
                lines.append(
                    f"  Joint {joint_name}: inherit={bone.inherit_scale}, "
                    f"local scale {tuple(round(v, 5) for v in pose.scale)}, "
                    f"world scale {tuple(round(v, 5) for v in world_scale)}, "
                    f"scale drivers={len(scale_drivers)}"
                )
    try:
        FACE_DEBUG_OUTPUT_PATH.write_text("\n".join(lines), encoding="utf-8")
    except OSError as write_error:
        return None, f"Could not write Face debug report: {write_error}"
    return FACE_DEBUG_OUTPUT_PATH, ""


def _write_main_scale_diagnostic(scene, context):
    """Record evaluated scale paths without altering the animator's pose."""
    armature = _generated_rig(scene)
    body_data, error = _load_body_json(scene.advanced_skeleton_body_json_path)
    if armature is None or body_data is None:
        return None, error or "Build the Body Rig and choose a Body JSON first."

    context.view_layer.update()
    evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
    interesting = {"Main", "RootX_M"}
    ik_specs = _ik_limb_specs(body_data)
    for switch, ik_control, _pole, names, _data in ik_specs:
        interesting.update(names)
        interesting.update("IK" + name for name in names)
        interesting.update("IKX" + name for name in names)
        interesting.add(str(switch.get("name", "")))
        interesting.add(str(ik_control.get("name", "")))
    for _system, names, controls in _spline_ik_specs(body_data):
        interesting.update(names)
        interesting.update(str(control.get("name", "")) for control in controls)
    interesting.update(
        bone.name for bone in armature.data.bones
        if bone.name.startswith("FKParentConstraintTo")
    )

    lines = [
        "ADVANCEDSKELETON MAIN SCALE DEBUG",
        "This report is observational: it does not change the pose.",
        f"Armature: {armature.name}",
        f"Armature world scale: {tuple(round(v, 6) for v in armature.matrix_world.to_scale())}",
        "",
    ]
    for name in sorted(item for item in interesting if item):
        bone = armature.data.bones.get(name)
        pose = armature.pose.bones.get(name)
        evaluated_pose = evaluated.pose.bones.get(name)
        if bone is None or pose is None or evaluated_pose is None:
            continue
        world_scale = (evaluated.matrix_world @ evaluated_pose.matrix).to_scale()
        constraints = []
        for constraint in pose.constraints:
            target = constraint.subtarget or (constraint.target.name if constraint.target else "")
            constraints.append(f"{constraint.name}:{constraint.type}:{target}")
        lines.extend((
            name,
            f"  parent: {bone.parent.name if bone.parent else '<armature>'}",
            f"  inherit scale: {bone.inherit_scale}",
            f"  local pose scale: {tuple(round(v, 6) for v in pose.scale)}",
            f"  evaluated world scale: {tuple(round(v, 6) for v in world_scale)}",
            f"  constraints: {', '.join(constraints) or '<none>'}",
            "",
        ))
        if name.startswith("IK") and name not in {"IKSpine1_M", "IKSpine2_M", "IKSpine3_M"}:
            lines.append(f"  native IK stretch: {round(float(pose.ik_stretch), 6)}")
            lines.append("")
        if "FKIKBlend" in pose or "stretchy" in pose:
            lines.append(
                "  animator properties: "
                f"FKIKBlend={pose.get('FKIKBlend', '<none>')}, "
                f"stretchy={pose.get('stretchy', '<none>')}"
            )
            lines.append("")
    try:
        MAIN_SCALE_DEBUG_OUTPUT_PATH.write_text("\n".join(lines), encoding="utf-8")
    except OSError as write_error:
        return None, f"Could not write Main scale debug report: {write_error}"
    return MAIN_SCALE_DEBUG_OUTPUT_PATH, ""


def _ensure_embedded_rig_ui(armature):
    """Store and immediately register the self-contained animator panel."""
    text = bpy.data.texts.get(RIG_UI_TEXT_NAME)
    if text is None:
        text = bpy.data.texts.new(RIG_UI_TEXT_NAME)
    text.clear()
    text.write(RIG_UI_SCRIPT)
    text.use_module = True
    namespace = {"__name__": "__main__", "__file__": RIG_UI_TEXT_NAME}
    exec(compile(RIG_UI_SCRIPT, RIG_UI_TEXT_NAME, "exec"), namespace, namespace)


def _configure_main_control_visibility(armature):
    """Make Main.ctrlVis the animator-facing Controls visibility switch."""
    main = armature.pose.bones.get("Main")
    controls = _find_bone_collection(armature.data, "Controls")
    if main is None or controls is None:
        return

    main["ctrlVis"] = True
    main.id_properties_ui("ctrlVis").update(
        default=True,
        description="Show animator control bones",
    )

    try:
        controls.driver_remove("is_visible")
    except (TypeError, ValueError):
        pass
    driver_fcurve = controls.driver_add("is_visible")
    driver = driver_fcurve.driver
    driver.type = "SCRIPTED"
    variable = driver.variables.new()
    variable.name = "ctrl_vis"
    variable.type = "SINGLE_PROP"
    target = variable.targets[0]
    target.id = armature
    target.data_path = 'pose.bones["Main"]["ctrlVis"]'
    driver.expression = "ctrl_vis"


def _configure_main_geometry_visibility(armature):
    """Make Main.geoVis the animator-facing Geometry visibility switch.

    Geometry is deliberately driven per mesh rather than through an Outliner
    collection state.  This keeps the switch self-contained in the saved rig,
    avoids changing a user's view-layer configuration, and works after the
    authoring add-on has been removed.
    """
    main = armature.pose.bones.get("Main")
    if main is None:
        return

    geometry_group = next(
        (
            obj for obj in bpy.data.objects
            if obj.get("advanced_skeleton_role") == "GEOMETRY_GROUP"
            and obj.get("as_import_session_id") == armature.get("as_import_session_id")
        ),
        None,
    )
    if geometry_group is None:
        return

    main["geoVis"] = True
    main.id_properties_ui("geoVis").update(
        default=True,
        description="Show the character geometry in the viewport",
    )
    meshes = [obj for obj in geometry_group.children_recursive if obj.type == "MESH"]
    for mesh in meshes:
        try:
            mesh.driver_remove("hide_viewport")
        except (TypeError, ValueError):
            pass
        driver = mesh.driver_add("hide_viewport").driver
        driver.type = "SCRIPTED"
        variable = driver.variables.new()
        variable.name = "geo_vis"
        variable.type = "SINGLE_PROP"
        target = variable.targets[0]
        target.id = armature
        target.data_path = 'pose.bones["Main"]["geoVis"]'
        driver.expression = "not geo_vis"


def _apply_character_scale(scene):
    """Apply the requested scale exactly as the former importer did.

    AdvancedSkeleton exports commonly arrive with an FBX armature-object scale
    such as 0.01.  The Character Scale field is the final scale, not a
    multiplier of that importer value: setting it to 1 must therefore produce
    armature scale (1, 1, 1).
    """
    armatures = _armatures_from_scene(scene)
    scale = scene.advanced_skeleton_character_scale
    for armature in armatures:
        armature.scale = (scale, scale, scale)
    message = (
        f"Character scale set to {scale:g}."
        if armatures
        else "No imported armature available to scale."
    )
    scene["as_import_scale_status"] = message
    return message


def _import_fbx(filepath):
    """Use Blender's available FBX importer, across supported versions."""
    if hasattr(bpy.ops.wm, "fbx_import"):
        bpy.ops.wm.fbx_import(filepath=filepath)
    elif hasattr(bpy.ops.import_scene, "fbx"):
        bpy.ops.import_scene.fbx(filepath=filepath)
    else:
        raise RuntimeError("No FBX importer is available in this Blender installation.")


def _body_json_fk_joint_controls(body_data):
    """Return direct FK controller records keyed by deform-joint name.

    An FK controller is authored at its corresponding joint.  This makes it
    the most reliable Body JSON position for validating an FBX armature rest
    pose.  FKIK and pole controls deliberately do not qualify: their visible
    placement is intentionally offset from the driven joint.
    """
    controls_by_joint = {}
    controls = body_data.get("rig", {}).get("controls", []) if body_data else []
    for control in controls:
        if not isinstance(control, dict):
            continue
        name = str(control.get("name", ""))
        joint_name = str(control.get("joint", ""))
        position = control.get("positionWorld")
        if (
            not name.startswith("FK")
            or name.startswith("FKIK")
            or not joint_name
            or not isinstance(position, (list, tuple))
            or len(position) < 3
        ):
            continue

        # Exact FK<joint> names are preferred.  A fallback remains useful for
        # any future AdvancedSkeleton naming variant that still represents
        # the same joint directly.
        exact = name == f"FK{joint_name}"
        previous = controls_by_joint.get(joint_name)
        if previous is None or exact:
            controls_by_joint[joint_name] = (control, exact)
    return {name: value[0] for name, value in controls_by_joint.items()}


def _body_json_fk_joint_positions(body_data):
    """Return authored direct-FK joint positions keyed by deform joint."""
    return {
        name: control.get("positionWorld")
        for name, control in _body_json_fk_joint_controls(body_data).items()
        if isinstance(control.get("positionWorld"), (list, tuple))
        and len(control["positionWorld"]) >= 3
    }


def _action_fcurves(action):
    """Yield f-curves from both legacy and Blender 5.2 Action layouts."""
    if action is None:
        return ()
    if hasattr(action, "fcurves"):
        return tuple(action.fcurves)
    return tuple(
        curve
        for layer in action.layers
        for strip in layer.strips
        for bag in strip.channelbags
        for curve in bag.fcurves
    )


def _bake_static_import_pose_to_rest(context, armatures):
    """Convert a constant OPM FBX compensation Action into the rest pose.

    Maya must sometimes bake static joint keys when exporting an
    offsetParentMatrix rig to FBX. Blender then receives a collapsed rest
    skeleton plus a *constant* pose Action that compensates it at every frame.
    Blender's native Apply Pose as Rest Pose is the appropriate conversion.
    It is deliberately gated by both signals below, so ordinary animated FBXs
    are never touched.
    """
    if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode="OBJECT")

    baked = []
    epsilon = 0.00001
    for armature in armatures:
        animation_data = armature.animation_data
        action = animation_data.action if animation_data else None
        curves = _action_fcurves(action)
        if not curves:
            continue
        # Every relevant baked channel must be constant over the action.
        # A genuine animation immediately opts out.
        pose_curves = [
            curve for curve in curves
            if curve.data_path.startswith('pose.bones[')
        ]
        if not pose_curves:
            continue
        if any(
            any(
                abs(point.co.y - curve.keyframe_points[0].co.y) > epsilon
                for point in curve.keyframe_points
            )
            for curve in pose_curves
            if curve.keyframe_points
        ):
            continue

        # Do not bake a harmless static identity Action. We require both an
        # origin-collapsed rest bone and a meaningful evaluated pose offset.
        collapsed = any(
            bone.head_local.length < 0.001 and bone.length > 1.0
            for bone in armature.data.bones
        )
        posed = any(
            pose_bone.location.length > 0.01
            # Quaternions in Blender do not expose a vector ``length``.  The
            # identity test is the absolute dot product; q and -q are the
            # same rotation.
            or abs(pose_bone.rotation_quaternion.dot(
                Quaternion((1.0, 0.0, 0.0, 0.0))
            )) < (1.0 - epsilon)
            for pose_bone in armature.pose.bones
        )
        if not (collapsed and posed):
            continue

        bpy.ops.object.select_all(action="DESELECT")
        armature.select_set(True)
        context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode="POSE")
        bpy.ops.pose.select_all(action="SELECT")
        # Native Blender operation: creates the correct rest skeleton and
        # invalidates the static compensation keys in one operation.
        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode="OBJECT")
        armature.animation_data_clear()
        armature["advanced_skeleton_static_pose_baked"] = True
        baked.append(armature.name)
    return baked


def _repair_zeroed_fbx_bone_heads(context, armatures, body_data):
    """Repair a narrowly-defined Blender FBX mirrored-bone import failure.

    Some Maya FBXs arrive with an isolated bone head at armature origin even
    though both the FBX/Maya re-import and Body JSON place that joint far
    away.  Blender then draws a giant origin bone and downstream FK helpers
    inherit the corrupt rest transform.  We repair only this unambiguous
    case: an FK-authored joint is far from origin while Blender imported its
    head at origin.  Normal bones and any JSON-free import are untouched.
    """
    joint_controls = _body_json_fk_joint_controls(body_data)
    joint_positions = _body_json_fk_joint_positions(body_data)
    if not joint_controls or not armatures:
        return []

    repaired = []
    if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode="OBJECT")

    for armature in armatures:
        armature_inverse = armature.matrix_world.normalized().inverted_safe()
        expected_heads = {
            name: armature_inverse @ _maya_point_to_blender(position)
            for name, position in joint_positions.items()
        }
        candidates = []
        for bone in armature.data.bones:
            expected_head = expected_heads.get(bone.name)
            control_data = joint_controls.get(bone.name)
            if expected_head is None or control_data is None:
                continue
            imported_head = bone.head_local
            expected_distance = expected_head.length
            # A 25% mismatch is intentionally generous; this is not a
            # general rest-pose normalizer.  It only catches origin collapse.
            origin_tolerance = max(0.001, expected_distance * 0.0001)
            mismatch_tolerance = max(0.01, expected_distance * 0.25)
            if (
                expected_distance > 0.01
                and imported_head.length <= origin_tolerance
                and (imported_head - expected_head).length >= mismatch_tolerance
            ):
                candidates.append((bone.name, expected_head, control_data))

        if not candidates:
            continue

        bpy.ops.object.select_all(action="DESELECT")
        armature.select_set(True)
        context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        for bone_name, expected_head, control_data in candidates:
            edit_bone = armature.data.edit_bones.get(bone_name)
            if edit_bone is None:
                continue
            # The direct FK control carries the Maya-authored local basis:
            # local +X points along the source joint.  Use it only when an
            # expected direct child validates that basis, rather than guessing
            # a tail from Blender's already-corrupt hierarchy.
            control_world_matrix = _maya_controller_matrix_to_blender(control_data)
            if control_world_matrix is None:
                continue
            local_control_matrix = _maya_world_to_armature_rest(
                armature, control_world_matrix
            )
            # Part/twist bones often sit between an FK joint and the next
            # directly-authored FK joint. Walk that structural branch rather
            # than requiring an immediate child to have an FK controller.
            descendants = list(edit_bone.children)
            child_heads = []
            while descendants:
                child = descendants.pop()
                if (
                    child.name in expected_heads
                    and (expected_heads[child.name] - expected_head).length > 0.01
                ):
                    child_heads.append(expected_heads[child.name])
                descendants.extend(child.children)
            if not child_heads:
                continue
            joint_axis = local_control_matrix.to_3x3() @ Vector((1.0, 0.0, 0.0))
            if joint_axis.length < 0.0001:
                continue
            # AdvancedSkeleton adds parallel slider/partial children around
            # shoulders. Pick the declared child that agrees with the
            # authored direct-FK primary axis, not simply the nearest child.
            expected_tail = max(
                child_heads,
                key=lambda point: joint_axis.normalized().dot(
                    (point - expected_head).normalized()
                ),
            )
            child_axis = (expected_tail - expected_head).normalized()
            if joint_axis.normalized().dot(child_axis) < 0.95:
                continue

            # Blender bones are local +Y down the bone.  Maya's authored
            # direct-FK basis is +X down the joint, so apply one fixed basis
            # conversion: Blender (X,Y,Z) = Maya-control (Z,X,Y).
            control_basis = local_control_matrix.to_3x3()
            bone_basis = Matrix((
                control_basis @ Vector((0.0, 0.0, 1.0)),
                control_basis @ Vector((1.0, 0.0, 0.0)),
                control_basis @ Vector((0.0, 1.0, 0.0)),
            )).transposed()
            rest_matrix = bone_basis.to_4x4()
            rest_matrix.translation = expected_head
            edit_bone.matrix = rest_matrix
            edit_bone.length = (expected_tail - expected_head).length
            repaired.append(f"{armature.name}:{bone_name}")
        bpy.ops.object.mode_set(mode="OBJECT")

        # Blender imported a pose Action for the same corrupt mirrored bones.
        # Once their rest heads are repaired, those static pose keys become a
        # second, compensating transform (the yellow keyed values visible in
        # Pose Mode).  Remove only keys for bones we *actually* repaired;
        # normal FBX bones and intentional animation remain untouched.
        repaired_names = [
            item.split(":", 1)[1]
            for item in repaired
            if item.startswith(f"{armature.name}:")
        ]
        if repaired_names:
            animation_data = armature.animation_data
            action = animation_data.action if animation_data else None
            if action:
                paths = tuple(
                    f'pose.bones["{name}"]' for name in repaired_names
                )
                # Blender 5.2 stores F-curves in layered Action channel bags;
                # older Blender releases exposed ``action.fcurves`` directly.
                if hasattr(action, "fcurves"):
                    curve_groups = (action.fcurves,)
                else:
                    curve_groups = tuple(
                        bag.fcurves
                        for layer in action.layers
                        for strip in layer.strips
                        for bag in strip.channelbags
                    )
                for curves in curve_groups:
                    for fcurve in tuple(curves):
                        if any(path in fcurve.data_path for path in paths):
                            curves.remove(fcurve)
            for bone_name in repaired_names:
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone is None:
                    continue
                pose_bone.location = (0.0, 0.0, 0.0)
                pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                pose_bone.rotation_euler = (0.0, 0.0, 0.0)
                pose_bone.scale = (1.0, 1.0, 1.0)
    return repaired


def _generated_rig(scene):
    """Return the final deformation armature created for this import session."""
    name = scene.get("as_rig_armature", "")
    rig = bpy.data.objects.get(name)
    if rig and rig.type == "ARMATURE" and rig.get("advanced_skeleton_role") == "RIG":
        return rig
    return next(
        (
            obj for obj in bpy.data.objects
            if obj.type == "ARMATURE" and obj.get("advanced_skeleton_role") == "RIG"
        ),
        None,
    )


def _get_or_create_scene_collection(scene, name):
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
    if collection.name not in {child.name for child in scene.collection.children}:
        scene.collection.children.link(collection)
    return collection


def _remove_imported_empty_groups(scene):
    """Remove FBX hierarchy helpers without changing child world transforms."""
    empty_groups = [
        obj for obj in _current_import_objects(scene)
        if obj.type == "EMPTY"
    ]
    if not empty_groups:
        return 0

    # FBX Empty groups can be nested. First detach every direct child while
    # retaining its world matrix; then remove the now-safe helper objects.
    for empty in empty_groups:
        for child in tuple(empty.children):
            world_matrix = child.matrix_world.copy()
            child.parent = None
            child.matrix_world = world_matrix
    for empty in empty_groups:
        bpy.data.objects.remove(empty, do_unlink=True)
    return len(empty_groups)


def _organize_imported_geometry(scene):
    """Parent imported FBX meshes under a Maya-like Geometry Empty group."""
    meshes = [
        obj for obj in _current_import_objects(scene)
        if obj.type == "MESH"
    ]
    if not meshes:
        return 0

    # An Empty parent is Blender's closest direct equivalent to a Maya Group.
    # It is hierarchy-only, so keep its viewport marker effectively invisible:
    # it must never read as a leftover animator control at world origin.
    # Collections remain Blender's underlying ownership model, but do not need
    # to be used as animator-facing hierarchy nodes here.
    geometry_group = bpy.data.objects.get("Geometry")
    if geometry_group is None:
        geometry_group = bpy.data.objects.new("Geometry", None)
        geometry_group.empty_display_type = "PLAIN_AXES"
        geometry_group.empty_display_size = 0.001
        target_collection = next(
            (
                collection
                for mesh in meshes
                for collection in mesh.users_collection
                if collection.name != "Geometry"
            ),
            None,
        )
        if target_collection is None:
            target_collection = _get_or_create_scene_collection(scene, "Collection")
        target_collection.objects.link(geometry_group)

    geometry_group["advanced_skeleton_role"] = "GEOMETRY_GROUP"
    geometry_group["as_import_session_id"] = _current_import_session_id(scene)
    geometry_group.empty_display_size = 0.001

    target_collection = next(iter(geometry_group.users_collection), None)
    if target_collection is None:
        target_collection = _get_or_create_scene_collection(scene, "Collection")
        target_collection.objects.link(geometry_group)

    old_geometry_collection = bpy.data.collections.get("Geometry")
    for mesh in meshes:
        # FBX commonly parents meshes to the armature solely to preserve a
        # hierarchy. The Armature modifier already provides deformation, so
        # remove that redundant parenting and leave meshes listed only under
        # Geometry in the Outliner.
        world_matrix = mesh.matrix_world.copy()
        mesh.parent = geometry_group
        mesh.matrix_world = world_matrix
        if mesh.name not in target_collection.objects:
            target_collection.objects.link(mesh)
        for collection in tuple(mesh.users_collection):
            if collection != target_collection:
                collection.objects.unlink(mesh)
    if (
        old_geometry_collection is not None
        and old_geometry_collection != target_collection
        and not old_geometry_collection.objects
        and not old_geometry_collection.children
    ):
        bpy.data.collections.remove(old_geometry_collection)
    return len(meshes)


def _collapse_outliners(context):
    """Collapse visible Outliner trees after Build Rig creates new structure."""
    for area in context.screen.areas:
        if area.type != "OUTLINER":
            continue
        region = next((region for region in area.regions if region.type == "WINDOW"), None)
        if region is None:
            continue
        try:
            with context.temp_override(area=area, region=region):
                # Blender's operator collapses one hierarchy level at a time.
                # A bounded repeat produces the clean top-level view without
                # changing any actual collection or object data.
                for _ in range(16):
                    bpy.ops.outliner.show_one_level(open=False)
        except RuntimeError:
            # Outliner expansion is UI state only; a layout/context variation
            # must never make Build Rig fail.
            pass


def _collapse_outliners_after_ui_refresh():
    """Repeat collapse after Blender has registered new Outliner tree items."""
    window_manager = bpy.context.window_manager
    for window in window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type != "OUTLINER":
                continue
            region = next((region for region in area.regions if region.type == "WINDOW"), None)
            if region is None:
                continue
            try:
                with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
                    for _ in range(16):
                        bpy.ops.outliner.show_one_level(open=False)
            except RuntimeError:
                pass
    return None


def _set_animator_viewport_defaults(context, armature):
    """Apply non-destructive display defaults for the finished animator rig."""
    # Controls should be depth-tested with the character, not displayed through
    # the mesh. This is an Armature-object viewport setting, not rig logic.
    armature.show_in_front = False

    # Imported joints remain present and skinned, but animators should see the
    # controller layer rather than a forest of deformation bones.
    deformation = _find_bone_collection(armature.data, "DeformationSystem")
    if deformation is not None:
        deformation.is_visible = False

    # RootX is intentionally parented to Main at a different position. Its
    # relationship line is implementation clutter, so turn off the standard
    # viewport overlay without altering the hierarchy itself.
    for area in context.screen.areas:
        if area.type != "VIEW_3D":
            continue
        for space in area.spaces:
            if space.type == "VIEW_3D":
                space.overlay.show_relationship_lines = False


def _return_armature_to_build_pose(context, armature, select_main=True):
    """Use Blender's native clear-transform operation for the Armature pose."""
    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="POSE")
    # Custom Properties are animator channels too.  Blender's Clear
    # Transforms does not reset them, so return each authored property to its
    # UI default before restoring pose transforms.
    for pose_bone in armature.pose.bones:
        for name in tuple(pose_bone.keys()):
            if str(name).startswith("_"):
                continue
            try:
                default = pose_bone.id_properties_ui(name).as_dict().get("default")
            except (AttributeError, TypeError):
                default = None
            if default is not None:
                pose_bone[name] = default
    bpy.ops.pose.select_all(action="SELECT")
    bpy.ops.pose.transforms_clear()
    bpy.ops.pose.select_all(action="DESELECT")
    # Face ctrlBox range frames are intentionally non-animator scale helpers:
    # their stored scale maps a child control's local +/-1 travel to the
    # visible frame edge.  Restore that authored helper scale after Blender's
    # generic Clear Transforms command.
    for pose_bone in armature.pose.bones:
        range_scale = pose_bone.get("_as_face_range_scale")
        if isinstance(range_scale, (list, tuple)) and len(range_scale) == 3:
            pose_bone.scale = tuple(float(value) for value in range_scale)
    if select_main:
        main = armature.pose.bones.get("Main")
        if main is not None:
            armature.data.bones.active = main.bone
            main.select = True


def _find_bone_collection(armature, name):
    """Find a Bone Collection by name, including nested collections."""
    def walk(collection):
        if collection.name == name:
            return collection
        for child in collection.children:
            found = walk(child)
            if found is not None:
                return found
        return None

    for root in armature.collections:
        found = walk(root)
        if found is not None:
            return found
    return None


def _maya_point_to_blender(point):
    """Convert one Maya XYZ point to Blender's X-right/Y-depth/Z-up space."""
    values = list(point) if isinstance(point, (list, tuple)) else []
    maya = Vector(tuple(float(values[index]) if index < len(values) else 0.0 for index in range(3)))
    return Vector((maya.x, -maya.z, maya.y))


def _maya_controller_matrix_to_blender(control_data):
    """Convert an exported Maya controller matrix into Blender world space."""
    values = control_data.get("worldMatrix", []) if isinstance(control_data, dict) else []
    if not isinstance(values, list) or len(values) != 16:
        return None
    maya_row_matrix = Matrix(tuple(
        tuple(float(values[row * 4 + column]) for column in range(4))
        for row in range(4)
    ))
    maya_to_blender = Matrix((
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 0.0, -1.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    ))
    # Maya exports a row-major matrix while Blender uses column vectors.
    return maya_to_blender @ maya_row_matrix.transposed()


def _control_widget_rest_matrix(armature, bone):
    """Return the control's world rest matrix without user Character Scale.

    Controller CVs arrive in the FBX/Maya authoring scale.  The Armature
    object is then uniformly scaled by the user, and Blender applies that
    scale again when drawing a custom shape.  Baking the object scale into
    the CV conversion made a 10x character receive 0.1x controller shapes.
    Keep the importer orientation/translation, but normalize out scale here.
    """
    return armature.matrix_world.normalized() @ bone.matrix_local


def _maya_world_to_armature_rest(armature, value):
    """Convert an authored Maya/JSON world transform without Character Scale.

    JSON controller positions are authored at the FBX's native scale.  A user
    Character Scale belongs to the Armature object and must be applied later,
    when Blender evaluates the bone, rather than being divided out while the
    control rest transform is created.
    """
    return armature.matrix_world.normalized().inverted_safe() @ value


def _periodic_cvs_without_maya_overlap(cvs, degree):
    """Remove Maya's repeated final CVs from a periodic NURBS curve."""
    if len(cvs) <= degree:
        return cvs
    for index in range(degree):
        first = list(cvs[index].get("position", []))
        last = list(cvs[len(cvs) - degree + index].get("position", []))
        if len(first) < 3 or len(last) < 3 or any(
            abs(float(first[axis]) - float(last[axis])) > 0.00001
            for axis in range(3)
        ):
            return cvs
    return cvs[:-degree]


def _create_control_widget(scene, control_data, bone_name, bone_matrix=None):
    """Create the display-only custom shape object for one control bone."""
    widget_name = f"WGT_{bone_name}"
    existing = bpy.data.objects.get(widget_name)
    if existing is not None:
        # Build Rig is a real rebuild during development.  Reusing an existing
        # widget leaves its old baked CV coordinates in place, which means a
        # corrected controller-space conversion can never reach the viewport.
        existing_data = existing.data if existing.type == "CURVE" else None
        bpy.data.objects.remove(existing, do_unlink=True)
        if existing_data is not None and existing_data.users == 0:
            bpy.data.curves.remove(existing_data)

    curve_data = bpy.data.curves.new(widget_name, "CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 16
    curve_data.render_resolution_u = 16
    for shape_data in control_data.get("curveShapes", []):
        degree = max(int(shape_data.get("degree", 3)), 1)
        form = str(shape_data.get("form", "open")).lower()
        cvs = list(shape_data.get("cvs", []))
        if form == "periodic":
            cvs = _periodic_cvs_without_maya_overlap(cvs, degree)
        if len(cvs) < degree + 1:
            continue
        spline = curve_data.splines.new("NURBS")
        spline.points.add(len(cvs) - 1)
        spline.order_u = min(degree + 1, len(cvs))
        spline.use_endpoint_u = form == "open"
        spline.use_cyclic_u = form in {"closed", "periodic"}
        source_matrix = _maya_controller_matrix_to_blender(control_data)
        for point, cv_data in zip(spline.points, cvs):
            raw_position = cv_data.get("position", [])
            if source_matrix is not None and bone_matrix is not None:
                # This is the legacy builder's proven conversion: Maya CVs
                # are controller-local, so first transform them through the
                # exported controller world matrix, then into the Blender
                # control bone's rest-local space. The custom shape itself
                # therefore needs no corrective transform afterward.
                values = list(raw_position) if isinstance(raw_position, (list, tuple)) else []
                maya_point = Vector(tuple(
                    float(values[index]) if index < len(values) else 0.0
                    for index in range(3)
                ))
                position = bone_matrix.inverted_safe() @ source_matrix @ maya_point
            else:
                position = _maya_point_to_blender(raw_position)
            point.co = (*position, float(cv_data.get("weight", 1.0)))

    if not curve_data.splines:
        bpy.data.curves.remove(curve_data)
        return None

    widgets = _get_or_create_scene_collection(scene, "Widgets")
    # Shape objects are implementation data. Blender still draws them when
    # referenced as a Pose Bone custom shape, while the collection itself is
    # hidden from the ordinary viewport hierarchy.
    widgets.hide_viewport = True
    widget = bpy.data.objects.new(widget_name, curve_data)
    widget["advanced_skeleton_role"] = "WIDGET"
    widget["as_import_session_id"] = _current_import_session_id(scene)
    widgets.objects.link(widget)
    widget.hide_render = True
    widget.use_fake_user = True
    return widget


def _configure_control_display(pose_bone, widget, control_data):
    """Apply a JSON custom shape and color to an animator-facing Pose Bone."""
    pose_bone.custom_shape = widget
    pose_bone.use_custom_shape_bone_size = False
    pose_bone.custom_shape_wire_width = 3.0
    color = list(control_data.get("color", [0.0, 0.255, 0.6, 1.0]))
    pose_bone.color.palette = "CUSTOM"
    pose_bone.color.custom.normal = tuple(float(value) for value in color[:3])
    pose_bone.color.custom.select = tuple(float(value) for value in color[:3])
    pose_bone.color.custom.active = tuple(float(value) for value in color[:3])
    pose_bone.custom_shape_translation = (0.0, 0.0, 0.0)
    pose_bone.custom_shape_rotation_euler = (0.0, 0.0, 0.0)
    pose_bone.custom_shape_scale_xyz = (1.0, 1.0, 1.0)


def _create_face_outline_widget(scene, bone_name, half_width, half_height, *, diamond=False):
    """Create one display-only, closed rectangular widget for the Face box.

    The widget is deliberately a Curve object because it is only the custom
    shape source.  The animator transform remains the Pose Bone.
    """
    widget_name = f"WGT_{bone_name}"
    existing = bpy.data.objects.get(widget_name)
    if existing is not None:
        existing_data = existing.data if existing.type == "CURVE" else None
        bpy.data.objects.remove(existing, do_unlink=True)
        if existing_data is not None and existing_data.users == 0:
            bpy.data.curves.remove(existing_data)

    curve_data = bpy.data.curves.new(widget_name, "CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 1
    # Match Body Rig controller widgets: a pure Curve outline, with visual
    # wire width supplied by the Pose Bone custom-shape display settings.
    # A bevel would turn this into visible tube geometry.
    curve_data.bevel_depth = 0.0
    spline = curve_data.splines.new("POLY")
    spline.points.add(3)
    points = (
        ((0.0, -half_height, 0.0), (half_width, 0.0, 0.0),
         (0.0, half_height, 0.0), (-half_width, 0.0, 0.0))
        if diamond else
        ((-half_width, -half_height, 0.0), (half_width, -half_height, 0.0),
         (half_width, half_height, 0.0), (-half_width, half_height, 0.0))
    )
    for point, position in zip(spline.points, points):
        point.co = (*position, 1.0)
    spline.use_cyclic_u = True

    widgets = _get_or_create_scene_collection(scene, "Widgets")
    widgets.hide_viewport = True
    widget = bpy.data.objects.new(widget_name, curve_data)
    widget["advanced_skeleton_role"] = "WIDGET"
    widget["advanced_skeleton_face_widget"] = True
    widget["as_import_session_id"] = _current_import_session_id(scene)
    widgets.objects.link(widget)
    widget.hide_render = True
    widget.use_fake_user = True
    return widget


def _face_json_vector(value, default=(0.0, 0.0, 0.0)):
    """Return a safe Maya XYZ vector from optional Face JSON metadata."""
    if not isinstance(value, (list, tuple)):
        return Vector(default)
    return Vector(tuple(
        float(value[index]) if index < len(value) else float(default[index])
        for index in range(3)
    ))


def _face_zup_point_to_blender(point):
    """Convert Face JSON's exported Z-up/Unreal location to Blender space.

    Unlike joints and Body JSON data, the Face exporter intentionally writes
    ctrlBox metadata as [Maya X, Maya Z, Maya Y].  That is already Z-up, so
    only the forward sign differs for Blender.
    """
    value = _face_json_vector(point)
    return Vector((value.x, -value.y, value.z))


def _face_zup_euler_to_blender_matrix(rotation_degrees):
    """Convert Face JSON's Z-up rotation through Blender's forward flip."""
    rotation = Euler(
        tuple(radians(value) for value in _face_json_vector(rotation_degrees)), "XYZ"
    ).to_matrix().to_4x4()
    forward_flip = Matrix.Diagonal((1.0, -1.0, 1.0, 1.0))
    return forward_flip @ rotation @ forward_flip


def _face_maya_local_vector(value, default=(0.0, 0.0, 0.0)):
    """Keep ctrlBox child offsets in their authored Maya-local XYZ axes.

    ``controlOffsetLocation`` is written straight from a Maya transform,
    unlike the special ctrlBox world metadata which is exported as X/Z/Y.
    The ctrlBox rest matrix already converts its local Maya axes into the
    Blender scene, so converting this vector again would put Maya Y travel
    into Blender depth instead of the panel's vertical axis.
    """
    return _face_json_vector(value, default)


def _face_reference_bone(armature, face_data):
    """Resolve an explicitly exported face joint before using standard names."""
    rig = face_data.get("rig", {}) if isinstance(face_data, dict) else {}
    candidates = []
    for key in ("faceJoint", "faceJointName", "faceReferenceJoint"):
        value = rig.get(key) if isinstance(rig, dict) else None
        if value:
            candidates.append(str(value))
    candidates.extend(("FaceJoint_M", "Head_M", "FKHead_M"))
    return next((armature.pose.bones.get(name) for name in candidates if armature.pose.bones.get(name)), None)


def _remove_generated_face_controls(context, armature):
    """Remove the previous Face Control Box only, ready for a clean rebuild."""
    face_collection = _find_bone_collection(armature.data, "FaceMotionSystem")
    face_names = {"ctrlBoxAttach", "ctrlBoxOffset", "ctrlBox"}

    def collect(collection):
        if collection is None:
            return
        face_names.update(bone.name for bone in collection.bones)
        for child in collection.children:
            collect(child)

    collect(face_collection)
    for widget in tuple(bpy.data.objects):
        if (
            widget.get("advanced_skeleton_face_widget")
            or widget.name.removeprefix("WGT_") in face_names
        ):
            data = widget.data if widget.type == "CURVE" else None
            bpy.data.objects.remove(widget, do_unlink=True)
            if data is not None and data.users == 0:
                bpy.data.curves.remove(data)

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    for name in face_names:
        bone = armature.data.edit_bones.get(name)
        if bone is not None:
            armature.data.edit_bones.remove(bone)
    bpy.ops.object.mode_set(mode="OBJECT")


def _create_face_control_box(context, armature, face_data):
    """Build the initial, standalone 2D Face Control Box from Face JSON.

    This is intentionally only the animator-control layout.  It does not add
    on-face controls or any Face SDK solve logic.
    """
    rig_data = face_data.get("rig", {}) if isinstance(face_data, dict) else {}
    if not isinstance(rig_data, dict):
        rig_data = {}
    face_joint = _face_reference_bone(armature, face_data)
    if face_joint is None:
        raise RuntimeError("Face JSON needs FaceJoint_M (or an exported face reference joint) in the Armature.")

    # JSON is authored in the imported FBX's original Maya scale.  The
    # Armature object carries Blender's uniform Character Scale, so local rest
    # matrices must *not* divide the authored values by it.
    face_scaler = sum(abs(value) for value in armature.matrix_world.to_scale()) / 3.0
    if face_scaler <= 0.000001:
        face_scaler = 1.0
    offset_location = _face_zup_point_to_blender(rig_data.get("ctrlBoxOffsetWorldLocation", (0.0, 0.0, 0.0)))
    offset_rotation = _face_json_vector(rig_data.get("ctrlBoxOffsetWorldRotation"))
    offset_world = Matrix.Translation(offset_location) @ _face_zup_euler_to_blender_matrix(offset_rotation)
    offset_local = _maya_world_to_armature_rest(armature, offset_world)
    # One panel-space conversion for the complete control box hierarchy:
    # Maya's 2D control plane is local X/Y, while the imported box reference
    # initially presents local Z as up.  Rotate the *actual rest transform*
    # so local Y is up for ctrlBox and every descendant.  Widgets remain
    # unrotated and therefore match the same one shared bone orientation.
    panel_local = offset_local @ Matrix.Rotation(radians(90.0), 4, "X")

    # The Face JSON's driver list contains both 2D ctrlBox drivers and later
    # on-face SDK controls.  This initial build explicitly includes only the
    # authored ctrlBox branches; e.g. upperLip_M belongs to SDKupperLip_M and
    # must not appear here.
    drivers = [
        item for item in face_data.get("drivers", [])
        if isinstance(item, dict)
        and str(item.get("controlParent", "")).startswith("ctrlBox")
        and str(item.get("control", "")).startswith("ctrl")
    ]
    parent_names = sorted({str(item.get("controlParent", "")) for item in drivers if item.get("controlParent")})
    controls = {}
    for item in drivers:
        name = str(item.get("control", ""))
        if name:
            controls.setdefault(name, item)
    control_ranges = {}
    for item in drivers:
        control_name = str(item.get("control", ""))
        channel = str(item.get("mayaAttribute", "")).rsplit(".", 1)[-1].lower()
        axis = {"translatex": 0, "translatey": 1}.get(channel)
        if not control_name or axis is None:
            continue
        try:
            minimum = float(item.get("mayaDriverMin", -1.0))
            maximum = float(item.get("mayaDriverMax", 1.0))
        except (TypeError, ValueError):
            continue
        axis_ranges = control_ranges.setdefault(control_name, [None, None])
        current = axis_ranges[axis]
        if current is None:
            axis_ranges[axis] = [minimum, maximum]
        else:
            current[0] = min(current[0], minimum)
            current[1] = max(current[1], maximum)
    for control_name, axis_ranges in control_ranges.items():
        for axis, value in enumerate(axis_ranges):
            if value is None:
                axis_ranges[axis] = [-1.0, 1.0]

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    edit_bones = armature.data.edit_bones

    def ensure(name, matrix, parent=None, length=0.2):
        bone = edit_bones.get(name) or edit_bones.new(name)
        bone.matrix = matrix
        bone.length = max(float(length), 0.05)
        bone.parent = parent
        bone.use_connect = False
        bone.matrix = matrix  # parenting must preserve the authored matrix
        bone.use_deform = False
        return bone

    # Keep the attachment helper at Armature identity.  Its Copy Transforms
    # constraint supplies the evaluated FaceJoint matrix.  ctrlBoxOffset then
    # stores the authored *relative* FaceJoint -> box transform.  Previously
    # both helpers were authored at FaceJoint/world matrices, which caused
    # Blender to apply the face transform twice (especially visible on Blaze).
    # This is also robust when a Maya source used offsetParentMatrix: Blender
    # uses the evaluated imported FaceJoint rest matrix, never Maya channels.
    attach_matrix = Matrix.Identity(4)
    # The attach constraint follows the evaluated Pose Bone transform.  Use
    # that same evaluated matrix when deriving the initial inverse/offset;
    # using `bone.matrix_local` (the unposed rest transform) was wrong for
    # characters whose imported FaceJoint inherits a non-rest hierarchy.
    relative_panel = face_joint.matrix.inverted_safe() @ panel_local
    attach = ensure("ctrlBoxAttach", attach_matrix, length=0.2)
    offset = ensure("ctrlBoxOffset", relative_panel, parent=attach, length=0.2)
    box = ensure("ctrlBox", relative_panel, parent=offset, length=0.2)
    parent_bones = {}
    parent_matrices = {}
    for name in parent_names:
        first_child = next(data for data in controls.values() if str(data.get("controlParent", "")) == name)
        placement = _face_maya_local_vector(first_child.get("controlOffsetLocation", (0.0, 0.0, 0.0)))
        parent_matrix = relative_panel @ Matrix.Translation(placement)
        parent_matrices[name] = parent_matrix
        parent_bones[name] = ensure(name, parent_matrix, parent=box, length=0.12)
    for name, data in controls.items():
        parent = parent_bones.get(str(data.get("controlParent", "")), box)
        # The authored placement belongs to ctrlBox*; the animator-facing
        # diamond begins at zero in that range frame and supplies the 2D move.
        local_matrix = parent_matrices.get(str(data.get("controlParent", "")), relative_panel)
        scale = _face_json_vector(data.get("controlOffsetScale", (0.12, 0.12, 0.12)), (0.12, 0.12, 0.12))
        ensure(name, local_matrix, parent=parent, length=max(scale.x, scale.y, scale.z, 0.08))
    bpy.ops.object.mode_set(mode="OBJECT")

    face_collection = _find_bone_collection(armature.data, "FaceMotionSystem")
    controls_collection = _find_bone_collection(armature.data, "Controls")
    if face_collection is None:
        face_collection = armature.data.collections.new("FaceMotionSystem", parent=controls_collection)
    on_face_collection = _find_bone_collection(armature.data, "OnFacecontrols")
    if on_face_collection is None:
        on_face_collection = armature.data.collections.new("OnFacecontrols", parent=face_collection)
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    for name in ("ctrlBoxAttach", "ctrlBoxOffset"):
        bone = armature.data.bones.get(name)
        if bone is None:
            continue
        for collection in tuple(bone.collections):
            collection.unassign(bone)
        mechanism.assign(bone)
        bone.hide = True
    for name in ("ctrlBox", *parent_names, *controls):
        bone = armature.data.bones.get(name)
        if bone is None:
            continue
        for collection in tuple(bone.collections):
            collection.unassign(bone)
        face_collection.assign(bone)

    attach_pose = armature.pose.bones["ctrlBoxAttach"]
    for constraint in tuple(attach_pose.constraints):
        if constraint.name == "AS_Face_Attach":
            attach_pose.constraints.remove(constraint)
    # ctrlBoxAttach has no physical skeleton parent.  Copy Transforms gives
    # the required single, maintained rest relationship without Child Of's
    # inverse-space ambiguity on an imported FBX armature.
    constraint = attach_pose.constraints.new("COPY_TRANSFORMS")
    constraint.name = "AS_Face_Attach"
    constraint.target = armature
    constraint.subtarget = face_joint.name
    constraint.owner_space = "POSE"
    constraint.target_space = "POSE"
    constraint.mix_mode = "REPLACE"
    attach_pose["FaceScaler"] = float(face_scaler)
    attach_pose.id_properties_ui("FaceScaler").update(
        default=float(face_scaler), min=0.001,
        description="Imported character scale used by the Face Control Box",
    )

    # Build the outer box from the authored ctrlBox child layout.  The legacy
    # ctrlBoxShape metadata is useful as a fallback, but on current exports
    # it can describe an older, smaller layout and fail to enclose Brow/Face
    # frames.  These values are all in the same Maya-local X/Y panel space.
    layout_entries = []
    for name, data in controls.items():
        location = _face_maya_local_vector(data.get("controlOffsetLocation", (0.0, 0.0, 0.0)))
        scale = _face_json_vector(data.get("controlOffsetScale", (0.12, 0.12, 0.12)), (0.12, 0.12, 0.12))
        ranges = control_ranges.get(name, [[-1.0, 1.0], [-1.0, 1.0]])
        layout_entries.append((location, scale, ranges))
    if layout_entries:
        min_x = min(location.x + abs(scale.x) * ranges[0][0] for location, scale, ranges in layout_entries)
        max_x = max(location.x + abs(scale.x) * ranges[0][1] for location, scale, ranges in layout_entries)
        min_y = min(location.y + abs(scale.y) * ranges[1][0] for location, scale, ranges in layout_entries)
        max_y = max(location.y + abs(scale.y) * ranges[1][1] for location, scale, ranges in layout_entries)
        margin = max(0.04, max(max(abs(scale.x), abs(scale.y)) for _, scale, _ in layout_entries) * 0.25)
        shape_location = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, 0.0))
        shape_half_width = (max_x - min_x) * 0.5 + margin
        shape_half_height = (max_y - min_y) * 0.5 + margin
    else:
        shape_scale = _face_json_vector(rig_data.get("ctrlBoxShapeScale", (0.5, 0.5, 1.0)), (0.5, 0.5, 1.0))
        shape_location = _face_maya_local_vector(rig_data.get("ctrlBoxShapeLocation", (0.0, 0.0, 0.0)))
        shape_half_width = abs(shape_scale.x)
        shape_half_height = abs(shape_scale.y)
    widget = _create_face_outline_widget(context.scene, "ctrlBox", shape_half_width, shape_half_height)
    box_pose = armature.pose.bones["ctrlBox"]
    # Match the existing Body Rig `Fingers_R` controller color exactly.
    yellow = [1.0, 1.0, 0.0, 1.0]
    _configure_control_display(box_pose, widget, {"color": yellow})
    # Widgets are authored in their bones' local XY plane, which is now the
    # shared Maya-style panel plane for ctrlBox and all of its descendants.
    box_pose.custom_shape_translation = shape_location
    shared_shape_rotation = (0.0, 0.0, 0.0)
    box_pose.custom_shape_rotation_euler = shared_shape_rotation

    # The ctrlBox* nodes are non-pickable range frames.  Their child driver
    # controls are the small, selectable diamond shapes inside each frame.
    for parent_name in parent_names:
        children = [data for data in controls.values() if str(data.get("controlParent", "")) == parent_name]
        child_names = [name for name, data in controls.items() if str(data.get("controlParent", "")) == parent_name]
        scales = [_face_json_vector(data.get("controlOffsetScale", (0.12, 0.12, 0.12)), (0.12, 0.12, 0.12)) for data in children]
        ranges = [control_ranges.get(name, [[-1.0, 1.0], [-1.0, 1.0]]) for name in child_names]
        if scales:
            # The visible frame is normalized to +/-1. Its non-selectable
            # bone carries the authored Maya offset scale, so an animator
            # moving the diamond to local X/Y = 1 reaches that frame edge.
            range_scale = Vector((
                max(max(abs(scale.x), 0.04) for scale in scales),
                max(max(abs(scale.y), 0.04) for scale in scales),
                1.0,
            ))
            minimum_x = min(value[0][0] for value in ranges)
            maximum_x = max(value[0][1] for value in ranges)
            minimum_y = min(value[1][0] for value in ranges)
            maximum_y = max(value[1][1] for value in ranges)
        else:
            range_scale = Vector((0.1, 0.1, 1.0))
            minimum_x = minimum_y = -1.0
            maximum_x = maximum_y = 1.0
        parent_pose = armature.pose.bones[parent_name]
        parent_pose.scale = range_scale
        parent_pose["_as_face_range_scale"] = list(range_scale)
        parent_widget = _create_face_outline_widget(
            context.scene,
            parent_name,
            (maximum_x - minimum_x) * 0.5,
            (maximum_y - minimum_y) * 0.5,
        )
        _configure_control_display(parent_pose, parent_widget, {"color": yellow})
        parent_pose.custom_shape_translation = (
            (minimum_x + maximum_x) * 0.5,
            (minimum_y + maximum_y) * 0.5,
            0.0,
        )
        parent_pose.custom_shape_rotation_euler = shared_shape_rotation
        parent_bone = armature.data.bones[parent_name]
        if hasattr(parent_bone, "hide_select"):
            parent_bone.hide_select = True

    # Small diamond widgets keep every existing 2D driver visible and
    # selectable. Their local location remains authored from JSON.
    for name, data in controls.items():
        bone = armature.data.bones.get(name)
        pose = armature.pose.bones.get(name)
        if bone is None or pose is None:
            continue
        scale = _face_json_vector(data.get("controlOffsetScale", (0.12, 0.12, 0.12)), (0.12, 0.12, 0.12))
        control_widget = _create_face_outline_widget(
            context.scene,
            name,
            0.25,
            0.25,
            diamond=True,
        )
        _configure_control_display(pose, control_widget, {"color": yellow})
        pose.custom_shape_rotation_euler = shared_shape_rotation
        # Animator-facing 2D controls work in the Maya-like local X/Y panel
        # plane. Z is never an animator channel.  Do not use a visual-only
        # range clamp: Blender can otherwise leave the animated value beyond
        # the displayed shape and snap only the pivot back, which is deeply
        # confusing for an animator.
        pose.lock_location[2] = True
        for constraint in tuple(pose.constraints):
            if constraint.name == "AS_Face_Range":
                pose.constraints.remove(constraint)

    return 1 + len(controls)


def _create_face_on_face_widget(scene, bone_name, radius, *, half_circle=False):
    """Create a light Curve widget for an animator-facing on-face control.

    The widget is deliberately independent of the control bone's transform.
    Blender displays it through ``PoseBone.custom_shape``; its placement can
    therefore sit slightly outside the face without changing animation input.
    """
    widget_name = f"WGT_{bone_name}"
    existing = bpy.data.objects.get(widget_name)
    if existing is not None:
        data = existing.data if existing.type == "CURVE" else None
        bpy.data.objects.remove(existing, do_unlink=True)
        if data is not None and data.users == 0:
            bpy.data.curves.remove(data)

    curve = bpy.data.curves.new(widget_name, "CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 1
    spline = curve.splines.new("POLY")
    steps = 12 if half_circle else 16
    spline.points.add(steps - 1)
    # The Maya half-circle controls are a relaxed open arc rather than a
    # literal 180-degree semicircle.  The shared Face control frame uses
    # local X for left/right and local Y for up/down, so centre the arch on
    # local +Y (not +X).  The previous +X centre was the visible 90-degree
    # display offset reported for all half-circle widgets.
    angle_span = radians(145.0) if half_circle else 6.283185307179586
    for index, point in enumerate(spline.points):
        fraction = index / (steps - 1 if half_circle else steps)
        angle = (
            radians(90.0) - angle_span * 0.5 + angle_span * fraction
            if half_circle else angle_span * fraction
        )
        point.co = (radius * cos(angle), radius * sin(angle), 0.0, 1.0)
    spline.use_cyclic_u = not half_circle

    widgets = _get_or_create_scene_collection(scene, "Widgets")
    widgets.hide_viewport = True
    widget = bpy.data.objects.new(widget_name, curve)
    widget["advanced_skeleton_role"] = "WIDGET"
    widget["advanced_skeleton_face_widget"] = True
    widget["as_import_session_id"] = _current_import_session_id(scene)
    widgets.objects.link(widget)
    widget.hide_render = True
    widget.use_fake_user = True
    return widget


def _face_on_face_specs(armature, face_data):
    """Return the deliberately supported first on-face controller subset.

    JSON control records supply authored transforms and display offsets.  The
    semantic adapters below only state the published AdvancedSkeleton mapping
    where an on-face control intentionally reuses another SDK driver's data.
    """
    records = {
        str(item.get("name")): item
        for item in face_data.get("controls", [])
        if isinstance(item, dict) and item.get("type") == "OnFace"
    }

    def middle_lid_joint(prefix, side):
        matches = sorted(
            bone.name for bone in armature.pose.bones
            if re.fullmatch(rf"{prefix}Main\\d+_{side}", bone.name)
        )
        return matches[len(matches) // 2] if matches else None

    known = {
        "Jaw_M": ("ChinCreaseJoint_M", "half"),
        "SmilePull_R": ("cornerLipJoint_R", "circle"),
        "SmilePull_L": ("cornerLipJoint_L", "circle"),
        "upperLip_M": ("upperLipJoint0_M", "half"),
        "lowerLip_M": ("lowerLipJoint0_M", "half"),
        "upperLid_R": (middle_lid_joint("upperLid", "R"), "half"),
        "upperLid_L": (middle_lid_joint("upperLid", "L"), "half"),
        "lowerLid_R": (middle_lid_joint("lowerLid", "R"), "half"),
        "lowerLid_L": (middle_lid_joint("lowerLid", "L"), "half"),
    }
    return [
        (name, records[name], follow, shape)
        for name, (follow, shape) in known.items()
        if name in records and follow and follow in armature.pose.bones
    ]


def _clone_face_driver(source, control, maya_attribute):
    """Copy a JSON SDK source while redirecting it to a generated control."""
    clone = dict(source)
    clone["control"] = control
    clone["mayaAttribute"] = f"{control}.{maya_attribute}"
    return clone


def _create_face_on_face_controls(context, armature, face_data):
    """Create the first self-contained, Pose-Bone on-face control layer.

    Every visible control is a non-deforming Pose Bone.  A Mechanism helper
    follows its facial reference bone through Copy Transforms, while the
    child control stores its Maya-authored rest transform relative to that
    helper.  This is the Blender equivalent of the Unreal follow-null setup:
    no control is parented directly under a deformation bone.
    """
    specs = _face_on_face_specs(armature, face_data)
    if not specs:
        return set(), []

    rig_data = face_data.get("rig", {}) if isinstance(face_data, dict) else {}
    on_face_controls_scale = _face_json_vector(
        rig_data.get("onFaceControlsScale", (1.0, 1.0, 1.0)),
        (1.0, 1.0, 1.0),
    )
    face_scaler = sum(abs(value) for value in armature.matrix_world.to_scale()) / 3.0
    if face_scaler <= 0.000001:
        face_scaler = 1.0

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    edit_bones = armature.data.edit_bones

    def ensure(name, matrix, parent=None):
        bone = edit_bones.get(name) or edit_bones.new(name)
        bone.matrix = matrix
        bone.length = 0.08
        bone.parent = parent
        bone.use_connect = False
        bone.matrix = matrix
        bone.use_deform = False
        return bone

    controls = set()
    helper_targets = {}
    rest_matrices = {}
    source_worlds = {}
    for name, data, _follow_joint, _shape in specs:
        source_world = _maya_controller_matrix_to_blender(data)
        if source_world is None:
            source_world = Matrix.Translation(_maya_point_to_blender(data.get("positionWorld", (0.0, 0.0, 0.0))))
        source_worlds[name] = source_world

    # Maya's right SmilePull is authored below a SideReverse_R hierarchy.
    # Exported world matrices do not retain that negative-scale parent as a
    # safe Blender Pose-Bone parent.  Mirror the complete local frame once,
    # rather than introducing a -X parent scale (which reverses Blender's
    # local transform gizmo and produces the reported world-space feeling).
    if "SmilePull_R" in source_worlds and "SmilePull_L" in source_worlds:
        mirror_x = Matrix.Diagonal((-1.0, 1.0, 1.0, 1.0))
        source_worlds["SmilePull_R"] = (
            mirror_x @ source_worlds["SmilePull_L"] @ mirror_x
        )

    for name, data, follow_joint, _shape in specs:
        source_world = source_worlds[name]
        source_rest = _maya_world_to_armature_rest(armature, source_world)
        target_matrix = armature.pose.bones[follow_joint].matrix.copy()
        helper_name = f"OnFaceFollow_{name}"
        helper = ensure(helper_name, Matrix.Identity(4))
        control = ensure(name, target_matrix.inverted_safe() @ source_rest, parent=helper)
        controls.add(name)
        helper_targets[helper_name] = follow_joint
        rest_matrices[name] = source_rest
    bpy.ops.object.mode_set(mode="OBJECT")

    face_collection = _find_bone_collection(armature.data, "FaceMotionSystem")
    on_face_collection = _find_bone_collection(armature.data, "OnFacecontrols")
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    yellow = [1.0, 1.0, 0.0, 1.0]
    green = [0.0, 1.0, 0.0, 1.0]
    for helper_name, target_name in helper_targets.items():
        bone = armature.data.bones[helper_name]
        for collection in tuple(bone.collections):
            collection.unassign(bone)
        mechanism.assign(bone)
        bone.hide = True
        pose = armature.pose.bones[helper_name]
        # This is Blender's equivalent of Maya's scaled OnFacecontrols group:
        # it makes a one-unit animator move travel the authored physical
        # distance while the SDK reads the raw local value unchanged.  Do not
        # invert this scale into the SDK multiplier.
        pose.scale = tuple(abs(value) for value in on_face_controls_scale)
        location = pose.constraints.new("COPY_LOCATION")
        location.name = "AS_OnFace_Follow_Location"
        location.target = armature
        location.subtarget = target_name
        location.owner_space = "POSE"
        location.target_space = "POSE"
        rotation = pose.constraints.new("COPY_ROTATION")
        rotation.name = "AS_OnFace_Follow_Rotation"
        rotation.target = armature
        rotation.subtarget = target_name
        rotation.owner_space = "POSE"
        rotation.target_space = "POSE"
        # Copy Location/Rotation intentionally leave this helper's authored
        # scale intact; a Copy Transforms constraint would overwrite it.

    for name, data, _follow_joint, shape_kind in specs:
        bone = armature.data.bones[name]
        for collection in tuple(bone.collections):
            collection.unassign(bone)
        on_face_collection.assign(bone)
        pose = armature.pose.bones[name]
        radius = max(float(data.get("diameter", 0.2)) * 0.5, 0.04)
        widget = _create_face_on_face_widget(
            context.scene, name, radius, half_circle=(shape_kind == "half"),
        )
        _configure_control_display(pose, widget, {"color": yellow if shape_kind == "circle" else green})

        # The controller transform stays at the authored location.  Only the
        # custom-shape translation receives the authored surface/pick offset.
        # Because this is a *relative* vector, uniform Armature scaling keeps
        # the offset correct without changing animator input travel.
        shape_world = _maya_point_to_blender(data.get("shapePositionWorld", data.get("positionWorld", (0.0, 0.0, 0.0))))
        shape_rest = _maya_world_to_armature_rest(armature, Matrix.Translation(shape_world)).translation
        # Maya's on-face world matrix carries the authored controller scale.
        # Blender EditBone.matrix preserves its position/orientation but not
        # that matrix scale.  Compute the display offset in that *normalized*
        # basis too; otherwise dividing by the Maya control scale makes the
        # visible shape appear several times farther from the face.
        shape_offset = rest_matrices[name].normalized().inverted_safe() @ shape_rest
        # `onFaceControlsScale` intentionally reduces a control's physical
        # travel.  Custom-shape size and the authored pick/surface offset must
        # remain visual values, however, so compensate exactly for that
        # inherited helper scale.  This restores the original readable widget
        # size without changing any animator channel or SDK value.
        display_inverse_scale = Vector((
            1.0 / max(abs(on_face_controls_scale.x), 0.000001),
            1.0 / max(abs(on_face_controls_scale.y), 0.000001),
            1.0 / max(abs(on_face_controls_scale.z), 0.000001),
        ))
        pose.custom_shape_translation = tuple(
            shape_offset[index] * display_inverse_scale[index]
            for index in range(3)
        )
        pose.custom_shape_scale_xyz = tuple(display_inverse_scale)
        # Half-circle widgets are authored in their own local XY plane.  The
        # exported convention flips the *upper* controls 180Â° around local X;
        # it is display-only and never changes a controller's transform axes.
        pose.custom_shape_rotation_euler = (
            (radians(180.0), 0.0, 0.0)
            if shape_kind == "half" and name.startswith("upper")
            else (0.0, 0.0, 0.0)
        )
        pose["FaceScaler"] = float(face_scaler)
        pose.id_properties_ui("FaceScaler").update(default=float(face_scaler), min=0.001)

    # Reuse the exported SDK curves through deliberate semantic adapters.
    # Generic direct entries (lids/lips) stay unchanged; the specialised
    # Maya controls explicitly borrow their documented source curves.
    sources = []
    all_sources = [item for item in face_data.get("drivers", []) if isinstance(item, dict)]
    by_control = {}
    for item in all_sources:
        by_control.setdefault(str(item.get("control", "")), []).append(item)
    for name in controls:
        if name in {"upperLip_M", "lowerLip_M", "upperLid_R", "lowerLid_R"}:
            sources.extend(by_control.get(name, []))
        elif name in {"upperLid_L", "lowerLid_L"}:
            for item in by_control.get(name.replace("_L", "_R"), []):
                clone = _clone_face_driver(item, name, str(item.get("mayaAttribute", "")).rsplit(".", 1)[-1])
                clone["driven"] = [
                    dict(driven, bone=str(driven.get("bone", "")).replace("_R", "_L"))
                    for driven in item.get("driven", []) if isinstance(driven, dict)
                ]
                sources.append(clone)
        elif name.startswith("SmilePull_"):
            side = name.rsplit("_", 1)[-1]
            for item in by_control.get(f"ctrlMouthCorner_{side}", []):
                attribute = str(item.get("mayaAttribute", "")).rsplit(".", 1)[-1]
                sources.append(_clone_face_driver(item, name, attribute))
        elif name == "Jaw_M":
            mapping = {"Value.Y": "translateY", "jawSide": "translateX", "jawForward": "translateZ"}
            for item in by_control.get("ctrlMouth_M", []):
                attribute = mapping.get(str(item.get("channel", "")))
                if attribute:
                    sources.append(_clone_face_driver(item, name, attribute))
    # `onFaceControlsScale` belongs to the helper hierarchy above, not to the
    # SDK value.  The central solver must receive the raw Pose-Bone transform
    # channel, exactly like the Unreal control solver.
    return controls, sources


def _create_main_control(context, armature, main_data):
    """Create the first animator-facing Main pose bone and its custom shape."""
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    main = armature.data.edit_bones.get("Main")
    if main is None:
        root_bones = [bone for bone in armature.data.edit_bones if bone.parent is None]
        main = armature.data.edit_bones.new("Main")
        main.head = (0.0, 0.0, 0.0)
        main.tail = (0.0, 0.0, 0.5)
        main.use_deform = False
        for root in root_bones:
            root.parent = main
            root.use_connect = False
    bpy.ops.object.mode_set(mode="OBJECT")

    main_bone = armature.data.bones["Main"]
    main_bone.use_deform = False
    main_collection = _find_bone_collection(armature.data, "MainSystem")
    for collection in tuple(main_bone.collections):
        collection.unassign(main_bone)
    main_collection.assign(main_bone)

    # JSON controller matrices are Blender *world*-space after conversion.
    # Bake against the control's unscaled world rest matrix: the Armature's
    # user Character Scale is applied by Blender while drawing the shape.
    widget = _create_control_widget(
        context.scene,
        main_data,
        "Main",
        _control_widget_rest_matrix(armature, main_bone),
    )
    if widget is None:
        raise RuntimeError("Main has no usable curveShapes in the selected Body JSON.")

    pose_bone = armature.pose.bones["Main"]
    _configure_control_display(pose_bone, widget, main_data)

    bpy.ops.object.mode_set(mode="POSE")
    bpy.ops.pose.select_all(action="DESELECT")
    armature.data.bones.active = main_bone
    pose_bone.select = True
    return pose_bone


def _set_main_advanced_skeleton_version(armature, body_data):
    """Expose Maya and Blender build versions on the Main control.

    Maya stores this as the non-keyable ``Main.version`` float.  Blender pose
    bones use custom properties for animator-facing channels, so we mirror the
    name and make it constant with a native driver. ``pluginVersion`` records
    the Blender extension version used to build this .blend; it is a string
    because semantic versions such as ``1.0.1`` cannot be floats.
    """
    if not isinstance(body_data, dict):
        return False
    raw_value = body_data.get(
        "advancedSkeletonVersion",
        body_data.get("rig", {}).get("advancedSkeletonVersion"),
    )
    try:
        version = float(raw_value)
    except (TypeError, ValueError):
        return False

    main = armature.pose.bones.get("Main")
    if main is None:
        return False
    property_name = "version"
    main[property_name] = version
    main.id_properties_ui(property_name).update(
        default=version,
        min=version,
        max=version,
        soft_min=version,
        soft_max=version,
        description="AdvancedSkeleton Maya version used to build this rig (read-only).",
    )
    try:
        main.driver_remove(f'["{property_name}"]')
    except (TypeError, ValueError):
        pass
    driver = main.driver_add(f'["{property_name}"]').driver
    driver.type = "SCRIPTED"
    driver.expression = repr(version)
    main["pluginVersion"] = ADDON_VERSION
    main.id_properties_ui("pluginVersion").update(
        default=ADDON_VERSION,
        description="AdvancedSkeleton Blender version used to build this rig.",
    )
    return True


def _create_root_x_control(context, armature, root_x_data):
    """Create the world-space RootX control and place deformation roots below it."""
    deformation = _find_bone_collection(armature.data, "DeformationSystem")
    deformation_names = {
        bone.name for bone in deformation.bones
    } if deformation is not None else set()

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    main = armature.data.edit_bones.get("Main")
    if main is None:
        raise RuntimeError("RootX_M requires the Main control bone.")
    root_x = armature.data.edit_bones.get("RootX_M")
    if root_x is None:
        root_x = armature.data.edit_bones.new("RootX_M")
        # The imported Root_M head is the authoritative Blender-space location.
        # Using the JSON world position here would reintroduce the FBX/Maya
        # axis-conversion ambiguity that this native Armature builder avoids.
        root_joint = armature.data.edit_bones.get(root_x_data.get("joint", "Root_M"))
        root_x.head = root_joint.head.copy() if root_joint is not None else Vector((0.0, 0.0, 0.0))
        root_x.tail = root_x.head + Vector((0.0, 0.0, 0.5))
        root_x.use_deform = False

    # RootMotion is an isolated export/reference transform, not the parent of
    # the character. RootX owns the actual deformation hierarchy. This makes
    # FKRootMotion move exactly RootMotion and nothing else, while RootX stays
    # the top-level character control. The identity is derived from the
    # JSON-authoritative Root joint rather than hard-coding RootMotion_M.
    root_joint_name = str(root_x_data.get("joint", "Root_M"))
    root_joint = armature.data.edit_bones.get(root_joint_name)
    stored_motion_name = str(armature.data.get("_as_root_motion_bone", ""))
    motion_root = armature.data.edit_bones.get(stored_motion_name)
    if motion_root is None and root_joint is not None:
        candidate = root_joint.parent
        if candidate is not None and candidate.name in deformation_names:
            motion_root = candidate
            armature.data["_as_root_motion_bone"] = candidate.name

    root_x_matrix = root_x.matrix.copy()
    root_x.parent = main
    root_x.use_connect = False
    root_x.matrix = root_x_matrix
    if motion_root is not None:
        motion_matrix = motion_root.matrix.copy()
        motion_root.parent = main
        motion_root.use_connect = False
        motion_root.matrix = motion_matrix
        # Direct children of RootMotion are the actual character roots. Keep
        # their rest transforms, but place them below RootX instead.
        for child in tuple(motion_root.children):
            if child.name not in deformation_names:
                continue
            child_matrix = child.matrix.copy()
            child.parent = root_x
            child.use_connect = False
            child.matrix = child_matrix
    bpy.ops.object.mode_set(mode="OBJECT")

    root_x_bone = armature.data.bones["RootX_M"]
    root_x_bone.use_deform = False
    root_system = _find_bone_collection(armature.data, "RootSystem")
    for collection in tuple(root_x_bone.collections):
        collection.unassign(root_x_bone)
    root_system.assign(root_x_bone)

    widget = _create_control_widget(
        context.scene,
        root_x_data,
        "RootX_M",
        _control_widget_rest_matrix(armature, root_x_bone),
    )
    if widget is None:
        raise RuntimeError("RootX_M has no usable curveShapes in the selected Body JSON.")
    pose_bone = armature.pose.bones["RootX_M"]
    _configure_control_display(pose_bone, widget, root_x_data)
    return pose_bone


def _fk_control_definitions(json_data):
    """Return animator FK controls, excluding the separate FK/IK switch controls."""
    return [
        control for control in json_data["rig"]["controls"]
        if isinstance(control, dict)
        and str(control.get("name", "")).startswith("FK")
        and not str(control.get("name", "")).startswith("FKIK")
        and isinstance(control.get("joint"), str)
        and control.get("joint")
    ]


def _fit_attribute_integer(control_data, name):
    """Read one integer Fit Attribute without relying on controller names."""
    for attribute in control_data.get("fitAttributes", []):
        if not isinstance(attribute, dict) or attribute.get("name") != name:
            continue
        try:
            return int(float(attribute.get("value", 0)))
        except (TypeError, ValueError):
            return 0
    return 0


def _standard_twist_components(armature, fk_controls):
    """Find authored AdvancedSkeleton twist chains without name guessing.

    ``twistJoints`` describes a chain of Part joints after an ordinary joint.
    Joining adjacent chains gives the two established AdvancedSkeleton cases:
    the first chain distributes its *down* twist; a following chain receives
    the endpoint's *up* twist.  This is the same topology rule used by the
    previous builder, now applied to native pose bones.
    """
    chain_map = {}
    for control_data in fk_controls:
        root_name = str(control_data.get("joint", ""))
        count = _fit_attribute_integer(control_data, "twistJoints")
        match = re.fullmatch(r"(.+)_([LRM])", root_name)
        if count < 1 or match is None or "Part" in root_name:
            continue
        stem, side = match.groups()
        parts = [f"{stem}Part{index}_{side}" for index in range(1, count + 1)]
        expected_parent = root_name
        for part_name in parts:
            part = armature.data.bones.get(part_name)
            if part is None or part.parent is None or part.parent.name != expected_parent:
                break
            expected_parent = part_name
        else:
            part_end = armature.data.bones.get(parts[-1])
            endpoints = [
                child.name for child in part_end.children
                if "Partial" not in child.name and "Slider" not in child.name
            ] if part_end else []
            if len(endpoints) == 1:
                chain_map[root_name] = (parts, endpoints[0])

    child_roots = {endpoint for _parts, endpoint in chain_map.values() if endpoint in chain_map}
    components = []
    visited = set()
    for root_name in chain_map:
        if root_name in child_roots or root_name in visited:
            continue
        component = []
        current = root_name
        while current in chain_map and current not in visited:
            component.append((current, *chain_map[current]))
            visited.add(current)
            current = chain_map[current][1]
        components.append(component)
    for root_name, (parts, endpoint) in chain_map.items():
        if root_name not in visited:
            components.append([(root_name, parts, endpoint)])
    return components


def _twist_source_joints(components):
    """Return only the joints that contribute axial twist to a component."""
    sources = set()
    for component in components:
        if component:
            sources.add(component[0][0])  # Down twist from the component root.
            sources.update(endpoint for _root, _parts, endpoint in component[1:])
    return sources


def _create_fk_controls(
    context, armature, fk_controls, root_x_joint="", ik_end_joints=(),
    ik_joint_sets=(), spline_joint_sets=(),
):
    """Create Blender-native FKOffset -> FK -> FKX control chains.

    ``FKOffset`` and ``FKX`` are hidden mechanism bones.  They are the
    Armature equivalent of the proven Maya-style helper transforms from the
    former builder: the visible FK bone remains clean at zero in its own
    offset space, while the deform bone follows the matching FKX helper.
    """
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    created = []
    control_by_joint = {
        control_data["joint"]: control_data
        for control_data in fk_controls
    }
    inbetween_owners = {
        control_data["joint"]: _fit_attribute_integer(control_data, "inbetweenJoints")
        for control_data in fk_controls
        if _fit_attribute_integer(control_data, "inbetweenJoints") > 0
    }
    global_owners = {
        control_data["joint"]: control_data
        for control_data in fk_controls
        if any(
            isinstance(attribute, dict) and attribute.get("name") == "global"
            for attribute in control_data.get("fitAttributes", [])
        )
    }
    ik_end_joints = set(ik_end_joints)
    ik_joint_sets = [set(joints) for joints in ik_joint_sets if joints]
    spline_joint_sets = [set(joints) for joints in spline_joint_sets if joints]
    attachment_bones = {}

    # First create all three bones at the imported joint's exact rest matrix.
    # Parenting is deliberately done afterwards, so the source rest matrices
    # are never recalculated from an inferred child direction.
    for control_data in fk_controls:
        name = control_data["name"]
        joint = armature.data.edit_bones.get(control_data["joint"])
        if joint is None:
            continue
        control = armature.data.edit_bones.get(name)
        if control is None:
            control = armature.data.edit_bones.new(name)
            # A control's rest transform must start from its corresponding
            # imported joint. This keeps it at the correct Blender-space
            # location/orientation without re-solving Maya axes per control.
            control.matrix = joint.matrix.copy()
            control.length = max(joint.length, 0.25)
            control.use_deform = False
            created.append(name)

        for helper_name in (
            "FKOffset" + control_data["joint"],
            "FKX" + control_data["joint"],
        ):
            helper = armature.data.edit_bones.get(helper_name)
            if helper is None:
                helper = armature.data.edit_bones.new(helper_name)
            helper.matrix = joint.matrix.copy()
            helper.length = max(joint.length, 0.25)
            helper.use_deform = False
        if control_data["joint"] in global_owners:
            global_helper = armature.data.edit_bones.get("FKGlobal" + control_data["joint"])
            if global_helper is None:
                global_helper = armature.data.edit_bones.new("FKGlobal" + control_data["joint"])
            global_helper.matrix = joint.matrix.copy()
            global_helper.length = max(joint.length, 0.25)
            global_helper.parent = armature.data.edit_bones.get("Main")
            global_helper.use_connect = False
            global_helper.matrix = joint.matrix.copy()
            global_helper.use_deform = False

    # Every FK branch immediately after an IK system needs an attachment in
    # final deformation space.  The JSON declaration, rather than controller
    # names, determines the boundary: a controlled joint is "first after IK"
    # when its direct deform parent belongs to a declared IK chain but the
    # controlled joint does not belong to that same chain.  This covers normal
    # endpoints (fingers below a wrist, Scapula below Chest) and branches from
    # inside a spline system (Cody's Tail below the Spline IK Root).
    for control_data in fk_controls:
        joint_name = control_data["joint"]
        joint = armature.data.edit_bones.get(joint_name)
        deform_parent = joint.parent if joint is not None else None
        if deform_parent is None:
            continue
        if any(
            deform_parent.name in ik_joints and joint_name not in ik_joints
            for ik_joints in ik_joint_sets
        ):
            ik_end_joints.add(deform_parent.name)

    for end_joint in ik_end_joints:
        deform_end = armature.data.edit_bones.get(end_joint)
        if deform_end is None:
            continue
        attachment_name = "FKParentConstraintTo" + end_joint
        attachment = armature.data.edit_bones.get(attachment_name)
        if attachment is None:
            attachment = armature.data.edit_bones.new(attachment_name)
        attachment.parent = deform_end
        attachment.use_connect = False
        attachment.matrix = deform_end.matrix.copy()
        attachment.length = max(deform_end.length, 0.25)
        # First-after-IK attachments need the solved parent position and
        # rotation.  Only Spline IK requires scale isolation: its animator
        # controls can scale individual spine segments and that local scale
        # must not leak into external branches.  Ordinary RP IK boundaries
        # retain normal scale inheritance, matching conventional FK/IK limbs.
        attachment.inherit_scale = (
            "NONE"
            if any(end_joint in joints for joints in spline_joint_sets)
            else "FULL"
        )
        attachment.use_deform = False
        attachment_bones[end_joint] = attachment_name

    # Rebuild the exact helper hierarchy.  Each control has a clean offset;
    # normal FKX bones are children of their visible controls.  An inbetween
    # owner is the one intentional exception: its FKX sits beside the visible
    # control below the offset, allowing the owner's rotation to be shared
    # over the owner and its Part continuation instead of inherited at 100%.
    for control_data in fk_controls:
        joint_name = control_data["joint"]
        control = armature.data.edit_bones.get(control_data["name"])
        offset = armature.data.edit_bones.get("FKOffset" + joint_name)
        helper = armature.data.edit_bones.get("FKX" + joint_name)
        if control is None or offset is None or helper is None:
            continue

        # The deformation hierarchy is authoritative for continuation through
        # Part joints.  JSON display parents deliberately skip those Parts;
        # for example FKChest_M lists FKSpine1_M even though Chest_M is below
        # Spine1Part2_M in the actual skeleton.
        deform_parent = armature.data.edit_bones.get(joint_name).parent
        parent_joint = (
            deform_parent.name
            if deform_parent is not None and deform_parent.name in control_by_joint
            else ""
        )
        parent_name = str(control_data.get("parent", ""))
        parent_control = armature.data.edit_bones.get(parent_name)
        if not parent_joint:
            parent_joint = next(
                (
                    item["joint"] for item in fk_controls
                    if item.get("name") == parent_name
                ),
                "",
            )
        # Parent child FK offsets below the previous FKX.  Top-level FK
        # controls such as FKRoot_M parent below RootX_M directly.
        # Root lock: real limb branches immediately below the Root joint use
        # RootX_M as their attachment base.  FKRoot_M can still distribute a
        # pleasing fraction into the spine continuation, but rotating it does
        # not swing the hips along as ordinary hierarchy children.  This is
        # discovered from the skeleton (non-Part direct children of Root), not
        # from Hip/Leg controller names.
        is_root_branch = (
            deform_parent is not None
            and deform_parent.name == root_x_joint
            and joint_name != root_x_joint
            and "Part" not in joint_name
        )
        # RootMotion_M (or another imported skeleton root) is reparented
        # below RootX_M by the native build.  Its FK control must use that
        # same attachment, otherwise its Pose-space constraint overrides the
        # RootX hierarchy and leaves the entire character behind.
        is_root_x_child = (
            deform_parent is not None and deform_parent.name == "RootX_M"
        )
        # The imported skeleton's top root (normally RootMotion_M) is a
        # deformation-only transform.  Its FK controller may drive that one
        # bone, but animator control branches below it attach to RootX rather
        # than following FKRootMotion_M.
        is_import_root_child = (
            deform_parent is not None
            and deform_parent.parent is not None
            and deform_parent.parent.name == "RootX_M"
        )
        # A declared IK-boundary attachment takes precedence over Root's
        # ordinary leg-lock branch rule.  RootX is a stable world/control
        # space, but when Root itself is moved by a Spline IK start control,
        # its external children must inherit that *deformation* movement.
        parent = (
            armature.data.edit_bones.get(attachment_bones[deform_parent.name])
            if deform_parent is not None and deform_parent.name in attachment_bones
            else (
                armature.data.edit_bones.get("RootX_M")
                if is_root_branch or is_root_x_child or is_import_root_child
                else (
                    armature.data.edit_bones.get("FKX" + parent_joint)
                    if parent_joint else parent_control
                )
            )
        )
        offset.parent = parent
        offset.use_connect = False
        control.parent = offset
        control.use_connect = False
        helper.parent = offset if joint_name in inbetween_owners else control
        helper.use_connect = False

        # The matrices must be reset after assigning parents, otherwise a
        # repeated Build Rig can retain parent-space values from its previous
        # build rather than the imported deformation rest pose.
        joint = armature.data.edit_bones.get(joint_name)
        if joint is not None:
            offset.matrix = joint.matrix.copy()
            control.matrix = joint.matrix.copy()
            helper.matrix = joint.matrix.copy()

    bpy.ops.object.mode_set(mode="OBJECT")

    fk_system = _find_bone_collection(armature.data, "FKSystem")
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    # A first-after-Spline attachment deliberately blocks its parent
    # Spline-control scale: an IKSpine control must not resize the arm, leg,
    # tail, etc. branch below it.  ``inherit_scale = NONE`` also blocks the
    # legitimate uniform scale from Main, however.  Put that one scale back
    # explicitly so Main remains a true whole-character scale control.
    #
    # This is intentionally attached only to JSON-resolved Spline boundaries,
    # not every FK attachment.  Ordinary FK/RP-IK hierarchy continues to use
    # Blender's normal inherited scale.
    spline_attachment_names = {
        attachment_bones[end_joint]
        for end_joint in attachment_bones
        if any(end_joint in joints for joints in spline_joint_sets)
    }
    for attachment_name in attachment_bones.values():
        attachment_bone = armature.data.bones.get(attachment_name)
        if attachment_bone is None:
            continue
        attachment_bone.use_deform = False
        attachment_bone.hide = True
        for collection in tuple(attachment_bone.collections):
            collection.unassign(attachment_bone)
        mechanism.assign(attachment_bone)
        attachment_pose = armature.pose.bones.get(attachment_name)
        if attachment_pose is None:
            continue
        existing = attachment_pose.constraints.get("AS_Main_Scale")
        if existing is not None:
            attachment_pose.constraints.remove(existing)
        if attachment_name in spline_attachment_names:
            main_scale = attachment_pose.constraints.new("COPY_SCALE")
            main_scale.name = "AS_Main_Scale"
            main_scale.target = armature
            main_scale.subtarget = "Main"
            main_scale.owner_space = "LOCAL"
            main_scale.target_space = "LOCAL"
            main_scale.use_offset = True
    for control_data in fk_controls:
        name = control_data["name"]
        joint_name = control_data["joint"]
        control_bone = armature.data.bones.get(name)
        if control_bone is None:
            continue
        control_bone.use_deform = False
        for collection in tuple(control_bone.collections):
            collection.unassign(control_bone)
        fk_system.assign(control_bone)

        # Offset/FKX are implementation bones, not animator controls.
        for helper_name in ("FKOffset" + joint_name, "FKX" + joint_name):
            helper_bone = armature.data.bones.get(helper_name)
            if helper_bone is None:
                continue
            helper_bone.use_deform = False
            helper_bone.hide = True
            for collection in tuple(helper_bone.collections):
                collection.unassign(helper_bone)
            mechanism.assign(helper_bone)

        if joint_name in global_owners:
            global_helper = armature.data.bones.get("FKGlobal" + joint_name)
            if global_helper is not None:
                global_helper.use_deform = False
                global_helper.hide = True
                for collection in tuple(global_helper.collections):
                    collection.unassign(global_helper)
                mechanism.assign(global_helper)

        widget = _create_control_widget(
            context.scene,
            control_data,
            name,
            _control_widget_rest_matrix(armature, control_bone),
        )
        if widget is not None:
            _configure_control_display(armature.pose.bones[name], widget, control_data)

        if joint_name in global_owners:
            pose_control = armature.pose.bones.get(name)
            offset_pose = armature.pose.bones.get("FKOffset" + joint_name)
            if pose_control is not None and offset_pose is not None:
                default = max(0.0, min(1.0, _control_attribute_value(control_data, "Global") / 10.0))
                pose_control["Global"] = default
                pose_control.id_properties_ui("Global").update(
                    default=default, min=0.0, max=1.0, soft_min=0.0, soft_max=1.0,
                    description="Blend this control's orientation from local FK to Main-relative",
                )
                existing = offset_pose.constraints.get("AS_Global_Orientation")
                if existing is not None:
                    offset_pose.constraints.remove(existing)
                global_constraint = offset_pose.constraints.new("COPY_ROTATION")
                global_constraint.name = "AS_Global_Orientation"
                global_constraint.target = armature
                global_constraint.subtarget = "FKGlobal" + joint_name
                global_constraint.owner_space = "WORLD"
                global_constraint.target_space = "WORLD"
                global_constraint.mix_mode = "REPLACE"
                _add_bone_property_driver(
                    global_constraint, "influence", None, armature,
                    name, "Global", "value",
                )

    # Add native Copy Rotation sharing for inbetween chains.  Every offset in
    # the consecutive Part chain receives one equal local fraction.  Since
    # each offset is parented below the previous FKX, the fractions accumulate
    # exactly as the former FKX object setup did (30/30/30 for two Parts).
    for owner_joint, count in inbetween_owners.items():
        owner_data = control_by_joint.get(owner_joint)
        if owner_data is None:
            continue
        chain = []
        current = owner_joint
        for _ in range(count):
            current_bone = armature.data.bones.get(current)
            candidates = [
                child.name for child in current_bone.children
                if child.name in control_by_joint and "Part" in child.name
            ] if current_bone is not None else []
            if not candidates:
                chain = []
                break
            current = sorted(candidates)[0]
            chain.append(current)
        if len(chain) != count:
            continue

        share = 1.0 / (count + 1)
        target_name = owner_data["name"]
        receiver_names = ["FKX" + owner_joint]
        receiver_names.extend("FKOffset" + part_joint for part_joint in chain)
        for receiver_name in receiver_names:
            receiver = armature.pose.bones.get(receiver_name)
            if receiver is None:
                continue
            existing = receiver.constraints.get("AS_Inbetween_Rotation")
            if existing is not None:
                receiver.constraints.remove(existing)
            constraint = receiver.constraints.new("COPY_ROTATION")
            constraint.name = "AS_Inbetween_Rotation"
            constraint.target = armature
            constraint.subtarget = target_name
            constraint.owner_space = "LOCAL"
            constraint.target_space = "LOCAL"
            constraint.mix_mode = "BEFORE"
            constraint.influence = share

        # ``inbetweenVis`` belongs on the owner control. It controls only the
        # optional Part controller shapes; their bones remain normally
        # selectable when visible because no viewport hide/select restriction
        # is used.
        owner_pose = armature.pose.bones.get(target_name)
        if owner_pose is not None:
            owner_pose["inbetweenVis"] = False
            owner_pose.id_properties_ui("inbetweenVis").update(
                default=False,
                description="Show the intermediate Part controls for this FK chain",
            )
            for part_joint in chain:
                part_pose = armature.pose.bones.get(control_by_joint[part_joint]["name"])
                if part_pose is not None:
                    _drive_inbetween_shape_visibility(part_pose, armature, target_name)

    return len(created)


def _connect_fk_controls_to_deformation(armature, fk_controls):
    """Drive each deformation bone from its matching FKX mechanism bone."""
    connected = 0
    for control_data in fk_controls:
        joint_name = control_data["joint"]
        helper_name = "FKX" + joint_name
        control = armature.pose.bones.get(helper_name)
        joint = armature.pose.bones.get(joint_name)
        if control is None or joint is None:
            continue

        existing = joint.constraints.get("AS_FK_Control")
        if existing is not None:
            joint.constraints.remove(existing)
        constraint = joint.constraints.new("COPY_TRANSFORMS")
        constraint.name = "AS_FK_Control"
        constraint.target = armature
        constraint.subtarget = helper_name
        constraint.owner_space = "POSE"
        constraint.target_space = "POSE"
        constraint.mix_mode = "REPLACE"
        connected += 1
    return connected


def _add_twist_mix_driver(constraint, armature, switch_name, expression):
    """Drive a twist-mix constraint from the limb's normalized FK/IK blend."""
    if switch_name:
        _add_property_influence_driver(constraint, armature, switch_name, expression)
    else:
        constraint.influence = 1.0 if expression == "1.0" else 0.0


def _create_twist_system(context, armature, json_data, fk_controls):
    """Create native local-X twist distribution for authored ``twistJoints``.

    The visible FK controller is deliberately *not* the driver.  Each hidden
    ``FKIKMix`` bone receives the same FKX/IKX orientation blend that drives
    its deformation joint.  A matching ``FKTwistDelta`` extracts only the
    Blender local-X swing/twist component.  This keeps the twist system local
    to the limb and ready for FK/IK blending without exposing helpers to an
    animator.
    """
    components = _standard_twist_components(armature, fk_controls)
    source_joints = _twist_source_joints(components)
    if not source_joints:
        return 0, 0

    switches_by_joint = {}
    for switch, _ik_control, _pole_control, names, _ik_data in _ik_limb_specs(json_data):
        for joint_name in names:
            switches_by_joint[joint_name] = str(switch.get("name", ""))

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    main = armature.data.edit_bones.get("Main")
    created = []
    for joint_name in sorted(source_joints):
        deform = armature.data.edit_bones.get(joint_name)
        if deform is None:
            continue
        for prefix in ("FKIKMix", "FKTwistDelta"):
            helper_name = prefix + joint_name
            helper = armature.data.edit_bones.get(helper_name)
            if helper is None:
                helper = armature.data.edit_bones.new(helper_name)
                created.append(helper_name)
            helper.matrix = deform.matrix.copy()
            helper.length = max(deform.length, 0.25)
            helper.parent = main
            helper.use_connect = False
            helper.matrix = deform.matrix.copy()
            helper.use_deform = False
    bpy.ops.object.mode_set(mode="OBJECT")

    twist_collection = _find_bone_collection(armature.data, "TwistSystem")
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    usable_sources = set()
    for joint_name in source_joints:
        mix_name = "FKIKMix" + joint_name
        delta_name = "FKTwistDelta" + joint_name
        mix = armature.pose.bones.get(mix_name)
        delta = armature.pose.bones.get(delta_name)
        if mix is None or delta is None:
            continue
        fk_source = "FKX" + joint_name if armature.pose.bones.get("FKX" + joint_name) else ""
        ik_source = "IKX" + joint_name if armature.pose.bones.get("IKX" + joint_name) else ""
        if not fk_source and not ik_source:
            continue
        usable_sources.add(joint_name)
        for constraint in list(mix.constraints):
            if constraint.name.startswith("AS_Twist_Mix"):
                mix.constraints.remove(constraint)
        switch_name = switches_by_joint.get(joint_name, "")
        if fk_source:
            constraint = mix.constraints.new("COPY_ROTATION")
            constraint.name = "AS_Twist_Mix_FK"
            constraint.target = armature
            constraint.subtarget = fk_source
            constraint.owner_space = "POSE"
            constraint.target_space = "POSE"
            constraint.mix_mode = "REPLACE"
            _add_twist_mix_driver(
                constraint, armature, switch_name,
                "1.0 - fkik" if ik_source and switch_name else "1.0",
            )
        if ik_source:
            constraint = mix.constraints.new("COPY_ROTATION")
            constraint.name = "AS_Twist_Mix_IK"
            constraint.target = armature
            constraint.subtarget = ik_source
            constraint.owner_space = "POSE"
            constraint.target_space = "POSE"
            constraint.mix_mode = "REPLACE"
            _add_twist_mix_driver(
                constraint, armature, switch_name,
                "fkik" if fk_source and switch_name else "1.0",
            )

        # Blender exposes the mathematically correct axial component directly
        # through a Transform driver with Swing/Twist X decomposition.  The
        # extracted scalar feeds a rest-aligned mechanism bone, so every
        # subsequent Copy Rotation remains in the same local axis space.
        mix["twist"] = 0.0
        try:
            mix.driver_remove('["twist"]')
        except (TypeError, ValueError):
            pass
        fcurve = mix.driver_add('["twist"]')
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        variable = driver.variables.new()
        variable.name = "value"
        variable.type = "TRANSFORMS"
        target = variable.targets[0]
        target.id = armature
        target.bone_target = mix_name
        target.transform_type = "ROT_X"
        target.transform_space = "LOCAL_SPACE"
        target.rotation_mode = "SWING_TWIST_X"
        driver.expression = "value"
        delta.rotation_mode = "XYZ"
        try:
            delta.driver_remove("rotation_euler", 0)
        except (TypeError, ValueError):
            pass
        fcurve = delta.driver_add("rotation_euler", 0)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        variable = driver.variables.new()
        variable.name = "twist"
        variable.type = "SINGLE_PROP"
        variable.targets[0].id = armature
        variable.targets[0].data_path = f'pose.bones["{mix_name}"]["twist"]'
        driver.expression = "twist"

        for helper_name in (mix_name, delta_name):
            bone = armature.data.bones.get(helper_name)
            if bone is None:
                continue
            bone.use_deform = False
            bone.hide = True
            for collection in tuple(bone.collections):
                collection.unassign(bone)
            mechanism.assign(bone)

    added = 0
    def add_copy(target_name, source_name, influence, name, invert=False):
        nonlocal added
        if source_name not in usable_sources:
            return
        target = armature.pose.bones.get(target_name)
        if target is None:
            return
        old = target.constraints.get(name)
        if old is not None:
            target.constraints.remove(old)
        constraint = target.constraints.new("COPY_ROTATION")
        constraint.name = name
        constraint.target = armature
        constraint.subtarget = "FKTwistDelta" + source_name
        constraint.use_x = True
        constraint.use_y = False
        constraint.use_z = False
        constraint.invert_x = invert
        constraint.owner_space = "LOCAL"
        constraint.target_space = "LOCAL"
        constraint.mix_mode = "ADD"
        constraint.influence = influence
        added += 1

    for component in components:
        if not component:
            continue
        root_name, root_parts, _endpoint = component[0]
        share = 1.0 / float(len(root_parts) + 1)
        add_copy(root_name, root_name, 1.0 - share, "AS_Down_Twist_Root", invert=True)
        for index, part_name in enumerate(root_parts, 1):
            add_copy(part_name, root_name, share, f"AS_Down_Twist_Part_{index}")
        for _root_name, parts, endpoint_name in component[1:]:
            share = 1.0 / float(len(parts) + 1)
            for index, part_name in enumerate(parts, 1):
                add_copy(part_name, endpoint_name, share, f"AS_Up_Twist_Part_{index}")
    return len(created), added


def _control_attribute_value(control_data, name, default=0.0):
    """Read one exported animator property."""
    for attribute in control_data.get("controlAttributes", []):
        if isinstance(attribute, dict) and attribute.get("name") == name:
            try:
                return float(attribute.get("value", default))
            except (TypeError, ValueError):
                return default
    return default


def _has_control_attribute(control_data, name):
    return any(
        isinstance(attribute, dict) and attribute.get("name") == name
        for attribute in control_data.get("controlAttributes", [])
    )


def _add_property_influence_driver(constraint, armature, switch_name, expression):
    """Drive a constraint influence from an FKIK control-bone property."""
    try:
        constraint.driver_remove("influence")
    except (TypeError, ValueError):
        pass
    driver = constraint.driver_add("influence").driver
    driver.type = "SCRIPTED"
    variable = driver.variables.new()
    variable.name = "fkik"
    variable.type = "SINGLE_PROP"
    target = variable.targets[0]
    target.id = armature
    target.data_path = f'pose.bones["{switch_name}"]["FKIKBlend"]'
    driver.expression = expression


def _add_bone_property_driver(owner, data_path, index, armature, bone_name, property_name, expression):
    """Drive one native rig channel from an animator Pose Bone property."""
    try:
        owner.driver_remove(data_path, index)
    except (TypeError, ValueError):
        pass
    fcurve = owner.driver_add(data_path, index) if index is not None else owner.driver_add(data_path)
    driver = fcurve.driver
    driver.type = "SCRIPTED"
    variable = driver.variables.new()
    variable.name = "value"
    variable.type = "SINGLE_PROP"
    variable.targets[0].id = armature
    variable.targets[0].data_path = f'pose.bones["{bone_name}"]["{property_name}"]'
    driver.expression = expression


def _drive_inbetween_shape_visibility(pose_bone, armature, owner_name):
    """Show an optional Part control without changing its selectability."""
    for axis in range(3):
        _add_bone_property_driver(
            pose_bone, "custom_shape_scale_xyz", axis, armature,
            owner_name, "inbetweenVis", "1.0 if value else 0.0",
        )


def _finalize_inbetween_visibility(armature, fk_controls):
    """Apply Part-control visibility after FK/IK display drivers are built.

    FK/IK construction can also install custom-shape scale drivers.  A Pose
    Bone property accepts only one driver per component, so this final pass
    deliberately makes the animator's inbetweenVis switch authoritative for
    optional Part control shapes.
    """
    control_by_joint = {
        str(control.get("joint", "")): control
        for control in fk_controls
        if isinstance(control, dict) and control.get("joint") and control.get("name")
    }
    applied = 0
    for owner_joint, owner_data in control_by_joint.items():
        count = _fit_attribute_integer(owner_data, "inbetweenJoints")
        if count < 1:
            continue
        owner_name = str(owner_data["name"])
        owner_pose = armature.pose.bones.get(owner_name)
        if owner_pose is None:
            continue
        owner_pose["inbetweenVis"] = False
        current = owner_joint
        for _index in range(count):
            bone = armature.data.bones.get(current)
            candidates = [
                child.name for child in bone.children
                if child.name in control_by_joint and "Part" in child.name
            ] if bone is not None else []
            if not candidates:
                break
            current = sorted(candidates)[0]
            part_data = control_by_joint.get(current)
            part_pose = armature.pose.bones.get(str(part_data.get("name", ""))) if part_data else None
            if part_pose is not None:
                _drive_inbetween_shape_visibility(part_pose, armature, owner_name)
                applied += 1
    return applied


def _add_roll_rotation_driver(pose_bone, armature, ik_control_name, expression):
    """Drive one reverse-foot roller's local X rotation from IK ``roll``."""
    pose_bone.rotation_mode = "XYZ"
    try:
        pose_bone.driver_remove("rotation_euler", 0)
    except (TypeError, ValueError):
        pass
    driver = pose_bone.driver_add("rotation_euler", 0).driver
    driver.type = "SCRIPTED"
    variable = driver.variables.new()
    variable.name = "roll"
    variable.type = "SINGLE_PROP"
    variable.targets[0].id = armature
    variable.targets[0].data_path = f'pose.bones["{ik_control_name}"]["roll"]'
    driver.expression = expression


def _add_spline_start_twist_driver(helper_bone, armature, start_control_name):
    """Feed a Maya-style control's longitudinal twist into Spline IK.

    Blender Spline IK deliberately does not use curve tilt for roll.  Its
    native roll control is local +Y rotation on a bone in the solved chain.
    Our imported AdvancedSkeleton controls retain Maya's longitudinal local
    +X axis, so this is one fixed, explicit space conversion: control X to
    Spline helper Y.  Applying it to the first helper makes the twist flow
    naturally through the full Spline IK chain.
    """
    if helper_bone is None or not start_control_name:
        return
    helper_bone.rotation_mode = "XYZ"
    start_control = armature.pose.bones.get(start_control_name)
    if start_control is not None:
        start_control.rotation_mode = "XYZ"
    try:
        helper_bone.driver_remove("rotation_euler", 1)
    except (TypeError, ValueError):
        pass
    driver = helper_bone.driver_add("rotation_euler", 1).driver
    driver.type = "SCRIPTED"
    variable = driver.variables.new()
    variable.name = "start_twist"
    variable.type = "SINGLE_PROP"
    variable.targets[0].id = armature
    variable.targets[0].data_path = (
        f'pose.bones["{start_control_name}"].rotation_euler[0]'
    )
    driver.expression = "start_twist"


def _add_spline_scale_driver(
    pose_bone, axis, armature, switch_name, controls_data, weights,
):
    """Drive one spline deform-scale component from its nearby IK controls.

    This deliberately writes the final local scale once, rather than stacking
    Copy Scale constraints.  A spline deform hierarchy would otherwise pass
    Start scale through every child before a later control has an opportunity
    to attenuate it.  ``weights`` are normalized linear falloff weights.
    """
    try:
        pose_bone.driver_remove("scale", axis)
    except (TypeError, ValueError):
        pass
    driver = pose_bone.driver_add("scale", axis).driver
    driver.type = "SCRIPTED"

    main = driver.variables.new()
    main.name = "main_scale"
    main.type = "TRANSFORMS"
    main_target = main.targets[0]
    main_target.id = armature
    main_target.bone_target = "Main"
    main_target.transform_type = "SCALE_X"
    # Character Scale lives on the Armature object; Main's local scale is the
    # animator's additional whole-character scale.  Reading world scale here
    # would include Character Scale a second time and make a scale-2 import
    # drive the Spline deformation chain to scale 4.
    main_target.transform_space = "LOCAL_SPACE"

    blend = driver.variables.new()
    blend.name = "fkik"
    blend.type = "SINGLE_PROP"
    blend.targets[0].id = armature
    blend.targets[0].data_path = f'pose.bones["{switch_name}"]["FKIKBlend"]'

    axis_name = ("X", "Y", "Z")[axis]
    terms = []
    for index, (control_data, weight) in enumerate(zip(controls_data, weights)):
        if weight <= 0.00001:
            continue
        variable = driver.variables.new()
        variable.name = f"control_{index}"
        variable.type = "TRANSFORMS"
        target = variable.targets[0]
        target.id = armature
        target.bone_target = str(control_data.get("name", ""))
        target.transform_type = "SCALE_" + axis_name
        target.transform_space = "LOCAL_SPACE"
        terms.append(f"{weight!r}*{variable.name}")
    weighted_scale = "(" + "+".join(terms) + ")" if terms else "1.0"
    # Main is always the character's scale. The spline-control contribution
    # blends in only in IK so ordinary FK scale remains under FK controls.
    driver.expression = f"main_scale * (1.0 + fkik * ({weighted_scale} - 1.0))"


def _driving_system_channel(attribute):
    """Map exported Maya channel labels to Blender Pose Bone channels."""
    channels = {
        "rotateX": ("rotation_euler", 0, True),
        "rotateY": ("rotation_euler", 1, True),
        "rotateZ": ("rotation_euler", 2, True),
        "translateX": ("location", 0, False),
        "translateY": ("location", 1, False),
        "translateZ": ("location", 2, False),
    }
    return channels.get(str(attribute))


def _add_driving_system_relationship(armature, controller_name, system, relationship):
    """Create one native Blender Driver F-Curve from exported SDK data."""
    source_property = str(system.get("name", ""))
    target = armature.pose.bones.get(str(relationship.get("target", "")))
    channel = _driving_system_channel(relationship.get("attribute", ""))
    if not source_property or target is None or channel is None:
        return False
    data_path, index, is_rotation = channel
    target.rotation_mode = "XYZ"
    try:
        target.driver_remove(data_path, index)
    except (TypeError, ValueError):
        pass
    fcurve = target.driver_add(data_path, index)
    while fcurve.keyframe_points:
        fcurve.keyframe_points.remove(fcurve.keyframe_points[0])
    driver = fcurve.driver
    driver.type = "AVERAGE"
    variable = driver.variables.new()
    variable.name = "driver_value"
    variable.type = "SINGLE_PROP"
    variable.targets[0].id = armature
    variable.targets[0].data_path = f'pose.bones["{controller_name}"]["{source_property}"]'

    minimum = float(system.get("driverMin", 0.0))
    maximum = float(system.get("driverMax", 10.0))
    multiplier = float(relationship.get("multiplier", 0.0))
    scale = radians(multiplier) if is_rotation else multiplier
    fcurve.extrapolation = "LINEAR"
    for value in (minimum, 0.0, maximum):
        point = fcurve.keyframe_points.insert(value, value * scale)
        point.interpolation = "LINEAR"
        point.handle_left_type = "VECTOR"
        point.handle_right_type = "VECTOR"
    fcurve.update()
    return True


def _create_driving_system_controls(context, armature, json_data):
    """Build JSON DrivingSystems as normal Pose Bone controls and Drivers."""
    controls = [
        control for control in json_data.get("rig", {}).get("controls", [])
        if isinstance(control, dict) and isinstance(control.get("drivingSystem"), list)
        and control.get("drivingSystem")
    ]
    if not controls:
        return 0, 0

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")
    created_names = []
    for control_data in controls:
        name = str(control_data.get("name", ""))
        joint_name = str(control_data.get("joint", ""))
        world_matrix = _maya_controller_matrix_to_blender(control_data)
        joint = armature.data.edit_bones.get(joint_name)
        if not name or world_matrix is None or joint is None:
            continue
        local_matrix = _maya_world_to_armature_rest(armature, world_matrix)
        offset_name = "DrivingOffset" + name
        offset = armature.data.edit_bones.get(offset_name)
        if offset is None:
            offset = armature.data.edit_bones.new(offset_name)
        offset.matrix = local_matrix
        offset.length = max(joint.length, 0.25)
        offset.parent = joint
        offset.use_connect = False
        offset.matrix = local_matrix
        offset.use_deform = False

        control = armature.data.edit_bones.get(name)
        if control is None:
            control = armature.data.edit_bones.new(name)
            created_names.append(name)
        control.matrix = local_matrix
        control.length = max(joint.length, 0.25)
        control.parent = offset
        control.use_connect = False
        control.matrix = local_matrix
        control.use_deform = False

    bpy.ops.object.mode_set(mode="OBJECT")
    driving_collection = _find_bone_collection(armature.data, "DrivingSystem")
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    created_relationships = 0
    for control_data in controls:
        name = str(control_data.get("name", ""))
        control_bone = armature.data.bones.get(name)
        pose_control = armature.pose.bones.get(name)
        if control_bone is None or pose_control is None:
            continue
        for collection in tuple(control_bone.collections):
            collection.unassign(control_bone)
        driving_collection.assign(control_bone)
        offset_bone = armature.data.bones.get("DrivingOffset" + name)
        if offset_bone is not None:
            offset_bone.hide = True
            for collection in tuple(offset_bone.collections):
                collection.unassign(offset_bone)
            mechanism.assign(offset_bone)
        widget = _create_control_widget(
            context.scene, control_data, name,
            _control_widget_rest_matrix(armature, control_bone),
        )
        if widget is not None:
            _configure_control_display(pose_control, widget, control_data)
        for system in control_data.get("drivingSystem", []):
            if not isinstance(system, dict) or not str(system.get("name", "")):
                continue
            property_name = str(system["name"])
            minimum = float(system.get("driverMin", 0.0))
            maximum = float(system.get("driverMax", 10.0))
            default = _control_attribute_value(control_data, property_name)
            pose_control[property_name] = default
            pose_control.id_properties_ui(property_name).update(
                default=default, min=minimum, max=maximum,
                soft_min=minimum, soft_max=maximum,
                description="AdvancedSkeleton DrivingSystem input",
            )
            for relationship in system.get("relationships", []):
                if isinstance(relationship, dict) and _add_driving_system_relationship(
                    armature, name, system, relationship,
                ):
                    created_relationships += 1
    return len(created_names), created_relationships


def _configure_ik_stretch(
    armature, helper_names, ik_control_name, switch_name, deform_names, primary_axis,
):
    """Add extension-only stretch without leaking helper scale into all axes.

    The solved helper chain uses Blender's native IK stretch.  Deformation
    bones keep their ordinary location/rotation constraints, while a single
    local scale axis receives the evaluated helper length scale.  This keeps
    the rigid IK result completely scale-free until the animator explicitly
    enables ``stretchy`` and moves the target past its build length.
    """
    if len(helper_names) != 3 or len(deform_names) != 3:
        return
    # Keep the reference only for the deform-bone scale driver below.  Do not
    # feed solved-bone distance back into ``ik_stretch``: that makes Blender's
    # dependency graph evaluate the IK chain as both input and output.
    rest_world_scale = sum(abs(value) for value in armature.matrix_world.to_scale()) / 3.0
    rest_world_scale = max(rest_world_scale, 0.00001)
    # Main is the animator-facing uniform character scale.  Both the measured
    # IK distance and the helper's world scale inherit it, so it must be part
    # of the reference length/ratio as well.  Without this, scaling Main made
    # a perfectly normal limb look over-extended to the stretch drivers.
    main_pose = armature.pose.bones.get("Main")

    def add_main_scale_variable(driver):
        if main_pose is None:
            return "1.0"
        variable = driver.variables.new()
        variable.name = "main_scale"
        variable.type = "TRANSFORMS"
        target = variable.targets[0]
        target.id = armature
        target.bone_target = main_pose.name
        target.transform_type = "SCALE_X"
        # Keep imported Character Scale out of the animator-scale ratio.  The
        # reference already contains Armature world scale; this variable is
        # only the extra scale keyed on Main itself.
        target.transform_space = "LOCAL_SPACE"
        return "max(abs(main_scale), 0.00001)"

    # Native IK itself already stretches only when its target is beyond the
    # reachable chain.  The animator Bool is therefore the only input needed
    # here.  In particular, do not add a LOC_DIFF variable using an IK helper:
    # that creates a self-dependency through the solved chain.
    for helper_name in helper_names[:2]:
        helper_pose = armature.pose.bones.get(helper_name)
        if helper_pose is None:
            continue
        try:
            helper_pose.driver_remove("ik_stretch")
        except (TypeError, ValueError):
            pass
        driver = helper_pose.driver_add("ik_stretch").driver
        driver.type = "SCRIPTED"
        enabled = driver.variables.new()
        enabled.name = "stretchy"
        enabled.type = "SINGLE_PROP"
        enabled.targets[0].id = armature
        enabled.targets[0].data_path = f'pose.bones["{ik_control_name}"]["stretchy"]'
        driver.expression = "1.0 if stretchy else 0.0"

    try:
        axis_index = max(range(3), key=lambda axis: abs(float(primary_axis[axis])))
    except (IndexError, TypeError, ValueError):
        axis_index = 0
    # Start and middle are the only deform segments that may lengthen.
    for deform_name, helper_name in zip(deform_names[:2], helper_names[:2]):
        deform_pose = armature.pose.bones.get(deform_name)
        if deform_pose is None:
            continue
        try:
            deform_pose.driver_remove("scale", axis_index)
        except (TypeError, ValueError):
            pass
        driver = deform_pose.driver_add("scale", axis_index).driver
        driver.type = "SCRIPTED"
        helper_scale = driver.variables.new()
        helper_scale.name = "helper_scale"
        helper_scale.type = "TRANSFORMS"
        helper_target = helper_scale.targets[0]
        helper_target.id = armature
        helper_target.bone_target = helper_name
        helper_target.transform_type = "SCALE_Y"
        helper_target.transform_space = "WORLD_SPACE"
        blend = driver.variables.new()
        blend.name = "fkik"
        blend.type = "SINGLE_PROP"
        blend.targets[0].id = armature
        blend.targets[0].data_path = f'pose.bones["{switch_name}"]["FKIKBlend"]'
        enabled = driver.variables.new()
        enabled.name = "stretchy"
        enabled.type = "SINGLE_PROP"
        enabled.targets[0].id = armature
        enabled.targets[0].data_path = f'pose.bones["{ik_control_name}"]["stretchy"]'
        main_scale = add_main_scale_variable(driver)
        driver.expression = (
            f"1.0 + ((helper_scale / ({rest_world_scale!r} * {main_scale})) - 1.0) * fkik * stretchy"
        )


def _drive_control_shape_visibility(pose_bone, armature, switch_name, side):
    """Drive custom-shape scale, keeping hidden controls non-destructive.

    Unlike object or collection viewport hiding, a zero-sized custom shape
    does not change Blender selection restrictions.  This keeps the animator
    able to reveal and select a side again with FKVis/IKVis.
    """
    visible_property = "FKVis" if side == "FK" else "IKVis"
    auto_test = "fkik < 0.999" if side == "FK" else "fkik > 0.001"
    expression = f"1.0 if ({visible_property.lower()} and ((not autovis) or ({auto_test}))) else 0.0"
    for axis in range(3):
        try:
            pose_bone.driver_remove("custom_shape_scale_xyz", axis)
        except (TypeError, ValueError):
            pass
        driver = pose_bone.driver_add("custom_shape_scale_xyz", axis).driver
        driver.type = "SCRIPTED"
        for variable_name, property_name in (
            ("fkik", "FKIKBlend"),
            (visible_property.lower(), visible_property),
            ("autovis", "autoVis"),
        ):
            variable = driver.variables.new()
            variable.name = variable_name
            variable.type = "SINGLE_PROP"
            target = variable.targets[0]
            target.id = armature
            target.data_path = f'pose.bones["{switch_name}"]["{property_name}"]'
        driver.expression = expression


def _ik_limb_specs(json_data):
    """Resolve exported FKIK switches into native two-bone IK limb specs."""
    controls = [item for item in json_data["rig"]["controls"] if isinstance(item, dict)]
    by_name = {str(item.get("name", "")): item for item in controls}
    specs = []
    for switch in controls:
        switch_name = str(switch.get("name", ""))
        ik_data = switch.get("ik")
        if not switch_name.startswith("FKIK") or not isinstance(ik_data, dict):
            continue
        if str(ik_data.get("solver", "")) != "ikRPsolver":
            continue
        names = tuple(str(ik_data.get(key, "")) for key in (
            "startJoint", "middleJoint", "endJoint",
        ))
        pole_name = str(ik_data.get("poleControl", ""))
        if not all(names) or not pole_name:
            continue
        ik_control = next(
            (
                item for item in controls
                if str(item.get("name", "")).startswith("IK")
                and not str(item.get("name", "")).startswith("FKIK")
                and item.get("ik", {}).get("endJoint") == names[2]
            ),
            None,
        )
        pole_control = by_name.get(pole_name)
        if ik_control is None or pole_control is None:
            continue
        specs.append((switch, ik_control, pole_control, names, ik_data))
    return specs


def _spline_ik_specs(json_data):
    """Return JSON-authored Spline IK systems without inferring names.

    AdvancedSkeleton's exporter already tells us the exact ordered chain and
    its controls.  A Blender build must honour that declaration rather than
    guessing that a joint called ``Spine`` or ``Tail`` is spline driven.
    """
    rig = json_data.get("rig", {}) if isinstance(json_data, dict) else {}
    systems = rig.get("ikSystems", []) if isinstance(rig, dict) else []
    controls = rig.get("controls", []) if isinstance(rig, dict) else []
    if not isinstance(systems, list) or not isinstance(controls, list):
        return []
    controls_by_name = {
        str(control.get("name", "")): control
        for control in controls if isinstance(control, dict)
    }
    specs = []
    for system in systems:
        if not isinstance(system, dict) or system.get("solver") != "ikSplineSolver":
            continue
        joints = [str(name) for name in system.get("joints", []) if name]
        control_names = [str(name) for name in system.get("controls", []) if name]
        control_data = [controls_by_name.get(name) for name in control_names]
        if len(joints) < 2 or len(control_data) < 2 or any(item is None for item in control_data):
            continue
        specs.append((system, joints, control_data))
    return specs


def _create_spline_curve(scene, armature, system_name, control_positions, control_names):
    """Create the hidden native curve driven by the Spline IK pose controls.

    The curve is mechanism data, not an animator controller.  It has five
    NURBS CVs for the usual three-control spine: two hooked to the start,
    one to the middle, and two to the end.  Other systems use the same
    endpoint duplication rule and distribute their remaining CVs over their
    JSON-declared controls.
    """
    curve_name = "MCH_SplineCurve_" + system_name
    existing = bpy.data.objects.get(curve_name)
    if existing is not None:
        existing_data = existing.data if existing.type == "CURVE" else None
        bpy.data.objects.remove(existing, do_unlink=True)
        if existing_data is not None and existing_data.users == 0:
            bpy.data.curves.remove(existing_data)

    curve_data = bpy.data.curves.new(curve_name, "CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 16
    spline = curve_data.splines.new("NURBS")
    # Two endpoint CVs plus one CV for every declared animator control is
    # the exported AdvancedSkeleton convention.  The duplicated *ownership*
    # of start/end CVs must not mean duplicated positions.
    point_count = len(control_names) + 2
    spline.points.add(point_count - 1)
    spline.order_u = min(3, point_count)
    spline.use_endpoint_u = True

    control_names = [str(name) for name in control_names]
    # Blender Hook modifiers use vertex indices.  NURBS points are curve
    # vertices, so the mapping directly captures the Maya-style CV grouping.
    control_indices = []
    for index in range(point_count):
        if index < 2:
            control_indices.append(0)
        elif index >= point_count - 2:
            control_indices.append(len(control_names) - 1)
        else:
            # Middle controls map one-for-one across the interior CVs.
            # CV 2 belongs to the first middle control (control index 1),
            # not the second middle control.  The two start-owned CVs occupy
            # indices 0 and 1, hence the interior mapping starts at index 2.
            interior_index = min(index - 2, len(control_names) - 2)
            control_indices.append(interior_index + 1)

    if len(control_positions) == 2:
        # A two-control tail has no authored middle control: spread its four
        # CVs uniformly across the endpoint line.
        start, end = control_positions
        point_positions = [start.lerp(end, index / (point_count - 1)) for index in range(point_count)]
    else:
        # For a normal three-control spine this becomes:
        # start, halfway(start/middle), middle, halfway(middle/end), end.
        # More middle controls retain one CV at each authored control and
        # receive the same smooth endpoint handle placement.
        point_positions = [control_positions[0]]
        point_positions.append(control_positions[0].lerp(control_positions[1], 0.5))
        point_positions.extend(control_positions[1:-1])
        point_positions.append(control_positions[-2].lerp(control_positions[-1], 0.5))
        point_positions.append(control_positions[-1])

    for index, point in enumerate(spline.points):
        position = point_positions[index]
        point.co = (position.x, position.y, position.z, 1.0)

    # Spline curves are inspectable rig mechanism data, not controller widget
    # sources.  Keep them in their own hidden collection so a developer can
    # reveal only the actual solve curve without exposing every WGT_* object.
    mechanism_objects = _get_or_create_scene_collection(scene, "SplineIK Debug")
    mechanism_objects.hide_viewport = True
    curve_object = bpy.data.objects.new(curve_name, curve_data)
    mechanism_objects.objects.link(curve_object)
    curve_object.parent = armature
    # Curve CVs are authored in Armature-local coordinates.  Give the curve
    # the Armature world transform so both its rest geometry and the Spline IK
    # helper chain use precisely the same Z-up-converted space.
    curve_object.matrix_parent_inverse = Matrix.Identity(4)
    curve_object.matrix_world = armature.matrix_world.copy()
    curve_object.hide_render = True
    curve_object.hide_set(True)
    curve_object["advanced_skeleton_role"] = "SPLINE_IK_CURVE"
    curve_object["as_import_session_id"] = _current_import_session_id(scene)

    for control_index, control_name in enumerate(control_names):
        indices = [
            index for index, mapped in enumerate(control_indices)
            if mapped == control_index
        ]
        if not indices:
            continue
        hook = curve_object.modifiers.new("AS_SplineCV_" + control_name, "HOOK")
        hook.object = armature
        hook.subtarget = control_name
        hook.vertex_indices_set(indices)
        # Hook's inverse is the control bone's evaluated rest world matrix.
        # Without this, Blender applies the control's rest transform *again*
        # to an already Armature-local CV and the unposed spline flies away.
        pose_bone = armature.pose.bones.get(control_name)
        if pose_bone is not None:
            target_world = armature.matrix_world @ pose_bone.matrix
            hook.matrix_inverse = target_world.inverted_safe() @ curve_object.matrix_world
    return curve_object


def _create_spline_ik_controls(context, armature, json_data):
    """Build Blender-native Spline IK controls and helper chains.

    Animator controls are normal Pose Bones with exported custom shapes.
    Blender's curve and +Y Spline IK helper chain are hidden mechanism data;
    ``SplineIKX*`` adapters preserve the imported deformation-bone spaces.
    """
    specs = _spline_ik_specs(json_data)
    if not specs:
        return 0

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    root_x = armature.data.edit_bones.get("RootX_M")
    main = armature.data.edit_bones.get("Main")
    all_controls = {
        str(control.get("name", "")): control
        for control in json_data.get("rig", {}).get("controls", [])
        if isinstance(control, dict)
    }
    created_controls = []
    prepared = []
    for system, joint_names, controls_data in specs:
        deform_chain = [armature.data.edit_bones.get(name) for name in joint_names]
        if any(bone is None for bone in deform_chain):
            continue
        # Spline control scale is solved explicitly below.  Do not let scale
        # pass down the imported deform hierarchy first: that would make a
        # Start scale grow stronger toward the end instead of falling off.
        # Main's uniform scale is included in every final scale driver.
        for deform_bone in deform_chain:
            deform_bone.inherit_scale = "NONE"
        # A spline system that branches from another IK system needs one
        # shared base in final deformation space.  For example, Cody's tail
        # begins below Root, which is inside the spine Spline IK chain.  Its
        # start/middle/end controls and FKIK switch must all inherit Root's
        # solved transform, not remain frozen below RootX_M.  The attachment
        # exists only for a JSON-resolved "first after IK" boundary, so the
        # primary spine still uses RootX/Main as its world base.
        system_parent = root_x or main
        first_parent = deform_chain[0].parent
        if first_parent is not None:
            attachment = armature.data.edit_bones.get(
                "FKParentConstraintTo" + first_parent.name
            )
            if attachment is not None:
                system_parent = attachment
        controls = []

        # Spline switches are not RP-limb switches, so they deliberately do
        # not pass through _create_ik_and_fkik_controls.  Create their native
        # FKIK Pose Bone here from the exported declaration instead.
        switch_data = all_controls.get(str(system.get("switchControl", "")))
        if switch_data is not None:
            switch_name = str(switch_data.get("name", ""))
            switch_joint = armature.data.edit_bones.get(str(switch_data.get("joint", "")))
            switch_bone = armature.data.edit_bones.get(switch_name)
            if switch_bone is None and switch_name and switch_joint is not None:
                switch_bone = armature.data.edit_bones.new(switch_name)
                created_controls.append(switch_name)
            if switch_bone is not None and switch_joint is not None:
                switch_bone.matrix = switch_joint.matrix.copy()
                switch_bone.length = max(switch_joint.length, 0.25)
                switch_bone.parent = system_parent
                switch_bone.use_connect = False
                switch_bone.matrix = switch_joint.matrix.copy()
                switch_bone.use_deform = False

        for control_data in controls_data:
            name = str(control_data.get("name", ""))
            joint = armature.data.edit_bones.get(str(control_data.get("joint", "")))
            if not name or joint is None:
                controls = []
                break
            control = armature.data.edit_bones.get(name)
            if control is None:
                control = armature.data.edit_bones.new(name)
                created_controls.append(name)
            control.matrix = joint.matrix.copy()
            control.length = max(joint.length, 0.25)
            control.parent = system_parent
            control.use_connect = False
            control.matrix = joint.matrix.copy()
            control.use_deform = False
            controls.append(control)
        if not controls:
            continue

        # EditBone RNA must never be retained beyond this Edit Mode phase.
        # Capture immutable Armature-local values used by the curve builder.
        control_positions = [control.head.copy() for control in controls]

        # A three-control spine has the familiar AdvancedSkeleton midpoint:
        # it follows the averaged start/end space, but the animator can still
        # translate/rotate it locally to shape the spline.  Blender's native
        # Armature constraint is the multi-target parent-constraint analogue.
        midpoint_helper_name = "MCH_SplineMid_" + str(system.get("name", "Spline"))
        if len(controls) == 3:
            midpoint_helper = armature.data.edit_bones.get(midpoint_helper_name)
            if midpoint_helper is None:
                midpoint_helper = armature.data.edit_bones.new(midpoint_helper_name)
            midpoint_helper.matrix = controls[1].matrix.copy()
            midpoint_helper.length = max(controls[1].length, 0.25)
            # This helper is defined entirely by the averaged start/end
            # controls below.  Parenting it under Main as well would apply
            # Main once through the parent and a second time through both
            # constraint targets, making the middle controller double move.
            midpoint_helper.parent = None
            midpoint_helper.use_connect = False
            midpoint_helper.matrix = controls[1].matrix.copy()
            midpoint_helper.use_deform = False
            controls[1].parent = midpoint_helper
            controls[1].use_connect = False
            controls[1].matrix = armature.data.edit_bones.get(
                str(controls_data[1].get("joint", ""))
            ).matrix.copy()

        helpers = []
        previous = None
        for index, deform in enumerate(deform_chain):
            helper_name = "SplineIK" + deform.name
            helper = armature.data.edit_bones.get(helper_name)
            if helper is None:
                helper = armature.data.edit_bones.new(helper_name)
            helper.head = deform.head.copy()
            helper.tail = (
                deform_chain[index + 1].head.copy()
                if index < len(deform_chain) - 1 else deform.tail.copy()
            )
            if (helper.tail - helper.head).length < 0.00001:
                helper.tail.y += 0.01
            helper.parent = previous if previous is not None else deform.parent
            helper.use_connect = previous is not None
            helper.use_deform = False
            previous = helper
            helpers.append(helper)

            adapter_name = "SplineIKX" + deform.name
            adapter = armature.data.edit_bones.get(adapter_name)
            if adapter is None:
                adapter = armature.data.edit_bones.new(adapter_name)
            adapter.matrix = deform.matrix.copy()
            adapter.length = max(deform.length, 0.25)
            adapter.parent = helper
            adapter.use_connect = False
            adapter.matrix = deform.matrix.copy()
            adapter.use_deform = False
        prepared.append((system, joint_names, controls_data, control_positions, helpers))

    bpy.ops.object.mode_set(mode="OBJECT")
    ik_collection = _find_bone_collection(armature.data, "IKSystem")
    fkik_collection = _find_bone_collection(armature.data, "FKIKSystem")
    mechanism = _find_bone_collection(armature.data, "Mechanism")
    created = 0
    for system, joint_names, controls_data, control_positions, helpers in prepared:
        switch_data = all_controls.get(str(system.get("switchControl", "")))
        if switch_data is not None:
            switch_bone = armature.data.bones.get(str(switch_data.get("name", "")))
            if switch_bone is not None:
                for old_collection in tuple(switch_bone.collections):
                    old_collection.unassign(switch_bone)
                fkik_collection.assign(switch_bone)
                switch_widget = _create_control_widget(
                    context.scene, switch_data, switch_bone.name,
                    _control_widget_rest_matrix(armature, switch_bone),
                )
                if switch_widget is not None:
                    _configure_control_display(
                        armature.pose.bones[switch_bone.name], switch_widget, switch_data,
                    )
        for control_data in controls_data:
            # Do not round-trip through EditBone.name here.  Blender can
            # briefly expose a stale RNA string during repeated edit/object
            # mode rebuilding; the JSON control name is the authoritative,
            # stable identifier for this lookup.
            control_name = str(control_data.get("name", ""))
            bone = armature.data.bones.get(control_name)
            if bone is None:
                continue
            for old_collection in tuple(bone.collections):
                old_collection.unassign(bone)
            ik_collection.assign(bone)
            widget = _create_control_widget(
                context.scene, control_data, bone.name,
                _control_widget_rest_matrix(armature, bone),
            )
            if widget is not None:
                _configure_control_display(armature.pose.bones[bone.name], widget, control_data)
            created += 1

        curve = _create_spline_curve(
            context.scene,
            armature,
            str(system.get("name", "Spline")),
            control_positions,
            [str(control.get("name", "")) for control in controls_data],
        )
        if curve is None:
            continue
        for joint_name in joint_names:
            helper_name = "SplineIK" + joint_name
            helper_bone = armature.data.bones.get(helper_name)
            adapter_bone = armature.data.bones.get("SplineIKX" + joint_name)
            for bone in (helper_bone, adapter_bone):
                if bone is None:
                    continue
                bone.use_deform = False
                bone.hide = True
                for old_collection in tuple(bone.collections):
                    old_collection.unassign(bone)
                mechanism.assign(bone)

        if len(control_positions) == 3:
            midpoint_helper = armature.pose.bones.get(
                "MCH_SplineMid_" + str(system.get("name", "Spline"))
            )
            if midpoint_helper is not None:
                for old in list(midpoint_helper.constraints):
                    if old.name == "AS_Spline_Mid_Follow":
                        midpoint_helper.constraints.remove(old)
                follow = midpoint_helper.constraints.new("ARMATURE")
                follow.name = "AS_Spline_Mid_Follow"
                for control_index in (0, -1):
                    target = follow.targets.new()
                    target.target = armature
                    target.subtarget = str(controls_data[control_index].get("name", ""))
                    target.weight = 0.5
                helper_bone = armature.data.bones.get(midpoint_helper.name)
                if helper_bone is not None:
                    helper_bone.hide = True
                    for old_collection in tuple(helper_bone.collections):
                        old_collection.unassign(helper_bone)
                    mechanism.assign(helper_bone)

        # Blender Spline IK evaluates through the *tail* of its final bone.
        # The exported final spline control lives at the end joint's head.
        # Therefore solve through the penultimate joint and let the declared
        # final control place/orient the final joint itself.  This keeps the
        # curve endpoint and solved-chain endpoint identical.
        solve_helper = armature.pose.bones.get("SplineIK" + joint_names[-2])
        if solve_helper is None:
            continue
        existing = solve_helper.constraints.get("AS_Spline_IK")
        if existing is not None:
            solve_helper.constraints.remove(existing)
        solve = solve_helper.constraints.new("SPLINE_IK")
        solve.name = "AS_Spline_IK"
        solve.target = curve
        solve.chain_count = len(helpers) - 1
        solve.use_curve_radius = False
        solve.y_scale_mode = "FIT_CURVE"

        # Native Spline IK roll is carried by local +Y on the helper chain.
        # The first animator control owns the start of the chain, so its
        # Maya-local X twist drives the first helper's Blender-local Y twist.
        _add_spline_start_twist_driver(
            armature.pose.bones.get("SplineIK" + joint_names[0]),
            armature,
            str(controls_data[0].get("name", "")),
        )

        # The spline system's switch is still a normal FKIK Pose Bone.  The
        # exporter default is in Maya's 0..10 range; Blender exposes 0..1.
        switch_name = str(system.get("switchControl", ""))
        switch = armature.pose.bones.get(switch_name)
        if switch is not None:
            default_ik = float(system.get("defaultIK", 0))
            switch["FKIKBlend"] = max(0.0, min(1.0, default_ik))
            switch.id_properties_ui("FKIKBlend").update(
                default=switch["FKIKBlend"], min=0.0, max=1.0,
                soft_min=0.0, soft_max=1.0,
                description="Blend this spline system from FK (0) to IK (1)",
            )
            switch["autoVis"] = True
            switch.id_properties_ui("autoVis").update(
                default=True,
                description="Automatically show the active FK or IK controls",
            )
            for property_name, description in (
                ("FKVis", "Show FK controls"),
                ("IKVis", "Show IK controls"),
            ):
                value = _has_control_attribute(switch_data or {}, property_name)
                # These are normal visibility switches even if an older JSON
                # omitted them on the spline switch.
                switch[property_name] = value or True
                switch.id_properties_ui(property_name).update(
                    default=True, description=description,
                )

        end_control_name = str(controls_data[-1].get("name", ""))
        for joint_index, joint_name in enumerate(joint_names):
            deform = armature.pose.bones.get(joint_name)
            if deform is None:
                continue
            for constraint_name in ("AS_Spline_IK_Location", "AS_Spline_IK_Rotation"):
                old = deform.constraints.get(constraint_name)
                if old is not None:
                    deform.constraints.remove(old)
            # Upgrade cleanup for the short-lived Copy Scale implementation.
            # A clean rebuild normally removes the generated rig anyway, but
            # this keeps an in-place upgrade deterministic as well.
            for old in tuple(deform.constraints):
                if old.name.startswith("AS_Spline_IK_Scale_") or old.name == "AS_Spline_IK_End_Scale":
                    deform.constraints.remove(old)
            for constraint_type, constraint_name in (
                ("COPY_LOCATION", "AS_Spline_IK_Location"),
                ("COPY_ROTATION", "AS_Spline_IK_Rotation"),
            ):
                constraint = deform.constraints.new(constraint_type)
                constraint.name = constraint_name
                constraint.target = armature
                constraint.subtarget = (
                    end_control_name
                    if joint_index == len(joint_names) - 1
                    else "SplineIKX" + joint_name
                )
                constraint.owner_space = "POSE"
                constraint.target_space = "POSE"
                if constraint_type == "COPY_ROTATION":
                    constraint.mix_mode = "REPLACE"
                if switch is not None:
                    _add_property_influence_driver(constraint, armature, switch_name, "fkik")
            fk_follow = deform.constraints.get("AS_FK_Control")
            if fk_follow is not None and switch is not None:
                _add_property_influence_driver(fk_follow, armature, switch_name, "1.0 - fkik")

        # Scale is not part of Blender's Spline IK solve.  Each control
        # contributes to nearby joints with linear falloff: an end control
        # fades to zero at its neighbour; an interior control fades both ways.
        # The direct drivers below are intentionally hierarchy-independent.
        control_count = len(controls_data)
        joint_count = len(joint_names)
        if switch is not None and control_count > 1 and joint_count > 1:
            for joint_index, joint_name in enumerate(joint_names):
                deform = armature.pose.bones.get(joint_name)
                if deform is None:
                    continue
                joint_t = joint_index / float(joint_count - 1)
                weights = []
                for control_index, control_data in enumerate(controls_data):
                    control_t = control_index / float(control_count - 1)
                    width = 1.0 / float(control_count - 1)
                    weight = max(0.0, 1.0 - abs(joint_t - control_t) / width)
                    weights.append(weight)
                for axis in range(3):
                    _add_spline_scale_driver(
                        deform, axis, armature, switch_name, controls_data, weights,
                    )

        if switch is not None:
            # Spline IK controls use the same animator-facing visibility
            # semantics as arm/leg IK.  FK controls are resolved from their
            # declared deformation joints, never from controller names.
            for control_data in json_data.get("rig", {}).get("controls", []):
                if not isinstance(control_data, dict):
                    continue
                control_name = str(control_data.get("name", ""))
                pose_control = armature.pose.bones.get(control_name)
                if pose_control is None:
                    continue
                if (
                    str(control_data.get("joint", "")) in joint_names
                    and control_name.startswith("FK")
                    and not control_name.startswith("FKIK")
                ):
                    _drive_control_shape_visibility(pose_control, armature, switch_name, "FK")
            for control_data in controls_data:
                pose_control = armature.pose.bones.get(str(control_data.get("name", "")))
                if pose_control is not None:
                    _drive_control_shape_visibility(pose_control, armature, switch_name, "IK")

        # Stretch is explicitly animator-facing only when exported on the end
        # spline control.  A native Spline IK chain uses FIT_CURVE when on and
        # NONE when off; the driver keeps this self-contained in the .blend.
        end_control_data = controls_data[-1]
        end_pose = armature.pose.bones.get(str(end_control_data.get("name", "")))
        if end_pose is not None and _has_control_attribute(end_control_data, "stretchy"):
            default = _control_attribute_value(end_control_data, "stretchy") >= 0.5
            end_pose["stretchy"] = default
            end_pose.id_properties_ui("stretchy").update(
                default=default, description="Allow this spline chain to stretch",
            )
            try:
                solve.driver_remove("y_scale_mode")
            except (TypeError, ValueError):
                pass
            # Enum properties cannot use a numeric driver.  The standard
            # Blender constraint setting remains FIT_CURVE for this first
            # native pass; the animator property is retained for the later
            # stretch UI/driver pass rather than faking a non-native scale.

    return created


def _reverse_foot_specs(json_data):
    """Return the explicit, JSON-authored reverse-foot descriptions.

    A reverse foot is never inferred from a joint name.  AdvancedSkeleton's
    exporter declares its IK controller, ordered pivot controls, and the one
    pivot which is the leg solver target.
    """
    rig = json_data.get("rig", {}) if isinstance(json_data, dict) else {}
    controls = rig.get("controls", []) if isinstance(rig, dict) else []
    systems = rig.get("reverseFootSystems", []) if isinstance(rig, dict) else []
    if not isinstance(controls, list) or not isinstance(systems, list):
        return []
    by_name = {
        str(control.get("name", "")): control
        for control in controls if isinstance(control, dict)
    }
    limb_by_ik_control = {
        str(ik_control.get("name", "")): switch
        for switch, ik_control, _pole, _names, _ik in _ik_limb_specs(json_data)
    }
    specs = []
    for system in systems:
        if not isinstance(system, dict):
            continue
        ik_control_name = str(system.get("ikControl", ""))
        target_parent = str(system.get("targetParent", ""))
        ordered_names = system.get("controls", [])
        if (
            ik_control_name not in limb_by_ik_control
            or target_parent not in by_name
            or not isinstance(ordered_names, list)
        ):
            continue
        control_data = [by_name.get(str(name)) for name in ordered_names]
        if not control_data or any(control is None for control in control_data):
            continue
        specs.append((
            system,
            limb_by_ik_control[ik_control_name],
            by_name[ik_control_name],
            control_data,
        ))
    return specs


def _create_reverse_foot_controls(context, armature, json_data):
    """Port AdvancedSkeleton's stable reverse-pivot topology to Pose Bones.

    The main leg solver targets the JSON-declared final roll pivot.  IKToes is
    deliberately a sibling of that final pivot, as in the prior stable object
    rig, so it only drives the toe branch and can never lift the ankle.
    """
    specs = _reverse_foot_specs(json_data)
    if not specs:
        return 0

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    created_names = []
    reverse_handles = []
    foot_rotation_spaces = []
    roll_rollers = []
    for _system, switch, ik_control, control_data in specs:
        for control in control_data:
            control_name = str(control.get("name", ""))
            world_matrix = _maya_controller_matrix_to_blender(control)
            if not control_name or world_matrix is None:
                continue
            bone = armature.data.edit_bones.get(control_name)
            if bone is None:
                bone = armature.data.edit_bones.new(control_name)
            local_matrix = _maya_world_to_armature_rest(armature, world_matrix)
            bone.matrix = local_matrix
            bone.length = max(bone.length, 0.25)
            parent_name = str(control.get("parent", ""))
            parent = armature.data.edit_bones.get(parent_name)
            if parent is not None and parent != bone:
                bone.parent = parent
                bone.use_connect = False
                # Preserve the imported controller's rest/world placement
                # while changing hierarchy, exactly like a Maya offset group.
                bone.matrix = local_matrix
            bone.use_deform = False
            created_names.append(control_name)

        # A reverse-foot pivot must not itself become the leg IK endpoint.
        # Create the equivalent of Maya's IKLegHandle: it sits at the imported
        # ankle position, inherits the final reverse pivot, and therefore keeps
        # the build pose intact while the pivots can move the leg target.
        target_parent_name = str(_system.get("targetParent", ""))
        end_name = str((switch.get("ik", {}) if isinstance(switch, dict) else {}).get("endJoint", ""))
        target_parent = armature.data.edit_bones.get(target_parent_name)
        end_bone = armature.data.edit_bones.get(end_name)
        ik_control_name = str(ik_control.get("name", ""))
        if target_parent is not None and end_bone is not None and ik_control_name:
            stem, separator, side = ik_control_name.rpartition("_")
            handle_name = f"{stem}Handle_{side}" if separator else f"{ik_control_name}Handle"
            handle = armature.data.edit_bones.get(handle_name)
            if handle is None:
                handle = armature.data.edit_bones.new(handle_name)
            end_matrix = end_bone.matrix.copy()
            handle.matrix = end_matrix
            handle.length = max(end_bone.length, 0.25)
            handle.parent = target_parent
            handle.use_connect = False
            # Parent assignment changes an EditBone's local space. Restore the
            # armature-space rest transform so this remains an ankle handle.
            handle.matrix = end_matrix
            handle.use_deform = False
            reverse_handles.append(handle_name)

            # The reverse pivots have their own axes.  This adapter preserves
            # the imported ankle axes at rest, then inherits the pivot motion.
            # It is the rotation target for the deform ankle; copying directly
            # from RollToes would introduce that pivot's local-axis offset.
            space_name = "IKXFootSpace" + end_name
            foot_space = armature.data.edit_bones.get(space_name)
            if foot_space is None:
                foot_space = armature.data.edit_bones.new(space_name)
            foot_space.matrix = end_matrix
            foot_space.length = max(end_bone.length, 0.25)
            foot_space.parent = target_parent
            foot_space.use_connect = False
            foot_space.matrix = end_matrix
            foot_space.use_deform = False
            foot_rotation_spaces.append(space_name)

        # Insert one hidden roller above each driven reverse pivot.  The pivot
        # itself keeps clean animator channels; the roller receives the native
        # Blender driver from IKLeg.roll, matching AdvancedSkeleton's Maya
        # RollRoller transform pattern.
        control_by_name = {
            str(control.get("name", "")): control for control in control_data
        }
        pivot_names = [
            name for name, control in control_by_name.items()
            if str(control.get("type", "")) == "ReverseFoot"
        ]
        if _has_control_attribute(ik_control, "roll") and len(pivot_names) >= 3:
            for pivot_name, role in (
                (pivot_names[0], "heel"),
                (pivot_names[-2], "toes_end"),
                (pivot_names[-1], "toes"),
            ):
                pivot = armature.data.edit_bones.get(pivot_name)
                if pivot is None:
                    continue
                roller_name = "RollRoller" + pivot_name.removeprefix("Roll")
                roller = armature.data.edit_bones.get(roller_name)
                if roller is None:
                    roller = armature.data.edit_bones.new(roller_name)
                pivot_matrix = pivot.matrix.copy()
                pivot_parent = pivot.parent
                if pivot_parent is not None and pivot_parent.name == roller_name:
                    # Rebuild safety: the roller was already inserted on a
                    # previous Build Rig, so retain its real upstream parent.
                    pivot_parent = roller.parent
                roller.matrix = pivot_matrix
                roller.length = max(pivot.length, 0.25)
                roller.parent = pivot_parent
                roller.use_connect = False
                roller.matrix = pivot_matrix
                roller.use_deform = False
                pivot.parent = roller
                pivot.use_connect = False
                pivot.matrix = pivot_matrix
                roll_rollers.append((roller_name, role, ik_control_name))

    bpy.ops.object.mode_set(mode="OBJECT")
    ik_collection = _find_bone_collection(armature.data, "IKSystem")
    mechanism_collection = _find_bone_collection(armature.data, "Mechanism")
    for mechanism_name in (*reverse_handles, *foot_rotation_spaces, *(name for name, _role, _control in roll_rollers)):
        mechanism_bone = armature.data.bones.get(mechanism_name)
        if mechanism_bone is None:
            continue
        mechanism_bone.use_deform = False
        mechanism_bone.hide = True
        for old_collection in tuple(mechanism_bone.collections):
            old_collection.unassign(mechanism_bone)
        if mechanism_collection is not None:
            mechanism_collection.assign(mechanism_bone)
    for roller_name, role, ik_control_name in roll_rollers:
        roller = armature.pose.bones.get(roller_name)
        ik_pose = armature.pose.bones.get(ik_control_name)
        if roller is None or ik_pose is None:
            continue
        if "roll" not in ik_pose:
            default = _control_attribute_value(
                next((control for _system, _switch, control, _data in specs if str(control.get("name", "")) == ik_control_name), {}),
                "roll",
            )
            ik_pose["roll"] = default
            ik_pose.id_properties_ui("roll").update(
                default=default, min=-10.0, max=10.0, soft_min=-2.0, soft_max=2.0,
                description="Foot roll (1.0 equals 30 degrees)",
            )
        roll_start = _control_attribute_value(
            next((control for _system, _switch, control, _data in specs if str(control.get("name", "")) == ik_control_name), {}),
            "rollStartAngle", 30.0,
        )
        roll_end = _control_attribute_value(
            next((control for _system, _switch, control, _data in specs if str(control.get("name", "")) == ik_control_name), {}),
            "rollEndAngle", 60.0,
        )
        roll_end = max(roll_end, roll_start + 0.001)
        radians = "0.017453292519943295"
        degrees = "(roll * 30.0)"
        if role == "heel":
            expression = f"min({degrees}, 0.0) * {radians}"
        elif role == "toes":
            expression = (
                f"{degrees} * min(max({degrees} / {roll_start!r}, 0.0), 1.0) * "
                f"(1.0 - min(max(({degrees} - {roll_start!r}) / {(roll_end - roll_start)!r}, 0.0), 1.0)) * {radians}"
            )
        else:
            expression = (
                f"{degrees} * min(max(({degrees} - {roll_start!r}) / {(roll_end - roll_start)!r}, 0.0), 1.0) * {radians}"
            )
        _add_roll_rotation_driver(roller, armature, ik_control_name, expression)
    created = 0
    for _system, switch, ik_control, control_data in specs:
        switch_name = str(switch.get("name", ""))
        target_parent_name = str(_system.get("targetParent", ""))
        target_parent = armature.pose.bones.get(target_parent_name)
        if target_parent is None:
            continue

        for control in control_data:
            control_name = str(control.get("name", ""))
            bone = armature.data.bones.get(control_name)
            pose_bone = armature.pose.bones.get(control_name)
            if bone is None or pose_bone is None:
                continue
            bone.use_deform = False
            for old_collection in tuple(bone.collections):
                old_collection.unassign(bone)
            ik_collection.assign(bone)
            widget = _create_control_widget(
                context.scene,
                control,
                control_name,
                _control_widget_rest_matrix(armature, bone),
            )
            if widget is not None:
                _configure_control_display(pose_bone, widget, control)
            _drive_control_shape_visibility(pose_bone, armature, switch_name, "IK")
            created += 1

        # The existing RP solver targets the hidden ankle-positioned handle,
        # which is parented below the heel -> toe-end -> toe-roll hierarchy.
        names = switch.get("ik", {}) if isinstance(switch, dict) else {}
        middle_name = str(names.get("middleJoint", ""))
        solve = armature.pose.bones.get("IK" + middle_name)
        if solve is not None:
            constraint = solve.constraints.get("AS_IK_Solve")
            if constraint is not None:
                ik_control_name = str(ik_control.get("name", ""))
                stem, separator, side = ik_control_name.rpartition("_")
                handle_name = f"{stem}Handle_{side}" if separator else f"{ik_control_name}Handle"
                constraint.subtarget = handle_name

        # The ankle gets its animator-facing orientation from the final pivot,
        # not directly from IKLeg. Its location remains the solved IKX result.
        end_name = str(names.get("endJoint", ""))
        end_pose = armature.pose.bones.get(end_name)
        if end_pose is not None:
            rotation = end_pose.constraints.get("AS_IK_End_Rotation")
            if rotation is not None:
                rotation.subtarget = "IKXFootSpace" + end_name
        end_adapter = armature.pose.bones.get("IKX" + end_name)
        if end_adapter is not None:
            rotation = end_adapter.constraints.get("AS_IKX_End_Rotation")
            if rotation is not None:
                rotation.subtarget = "IKXFootSpace" + end_name

        # IKToes is a separate child branch below RollToesEnd.  It drives only
        # its declared toe deform joint; no second ankle/toe IK solver exists.
        for control in control_data:
            if str(control.get("type", "")) != "ReverseFootToe":
                continue
            toe_joint = str(control.get("joint", ""))
            toe_deform = armature.pose.bones.get(toe_joint)
            if toe_deform is None:
                continue
            existing = toe_deform.constraints.get("AS_ReverseFoot_Toe")
            if existing is not None:
                toe_deform.constraints.remove(existing)
            # The leg solver owns the ankle's location. Copying the toe
            # control's location would pull this branch past a non-stretching
            # leg target, so this reverse-foot link is orientation-only.
            follow = toe_deform.constraints.new("COPY_ROTATION")
            follow.name = "AS_ReverseFoot_Toe"
            follow.target = armature
            follow.subtarget = str(control.get("name", ""))
            follow.owner_space = "POSE"
            follow.target_space = "POSE"
            follow.mix_mode = "REPLACE"
            _add_property_influence_driver(follow, armature, switch_name, "fkik")
            fk_follow = toe_deform.constraints.get("AS_FK_Control")
            if fk_follow is not None:
                _add_property_influence_driver(fk_follow, armature, switch_name, "1.0 - fkik")
            # Toes are part of the leg's IK result.  Their FK controller is
            # visible only on the FK side of that same FKIK switch.
            for candidate in json_data.get("rig", {}).get("controls", []):
                if (
                    isinstance(candidate, dict)
                    and str(candidate.get("joint", "")) == toe_joint
                    and str(candidate.get("name", "")).startswith("FK")
                    and not str(candidate.get("name", "")).startswith("FKIK")
                ):
                    fk_toe = armature.pose.bones.get(str(candidate.get("name", "")))
                    if fk_toe is not None:
                        _drive_control_shape_visibility(fk_toe, armature, switch_name, "FK")

    return created


def _create_ik_and_fkik_controls(context, armature, json_data):
    """Build native RP IK helpers plus animator IK/FKIK control bones.

    This deliberately ports only the stable limb core from the previous
    builder: a Start/Middle/End helper chain, one RP IK constraint, and native
    FK/IK constraint blending.  Reverse foot and stretch stay separate phases.
    """
    specs = _ik_limb_specs(json_data)
    if not specs:
        return 0, 0

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode="EDIT")

    main = armature.data.edit_bones.get("Main")
    if main is None:
        bpy.ops.object.mode_set(mode="OBJECT")
        return 0, 0

    created_ik = 0
    created_switches = 0
    helper_names = {}
    leg_pole_offsets = []
    for switch, ik_control, pole_control, names, ik_data in specs:
        start, middle, end = (
            armature.data.edit_bones.get(name) for name in names
        )
        if not all((start, middle, end)):
            continue

        # Solver bones must not inherit scale from their deform parent.  In
        # particular, an IK spine control must never leak its local scale into
        # a leg merely because Hip is below Root in the imported hierarchy.
        # Main is restored explicitly below as the *only* character-scale
        # source for these bones.
        for deform_bone in (start, middle, end):
            deform_bone.inherit_scale = "NONE"

        # Animator controls use the imported target joint as their rest
        # transform; their JSON curve shape is then baked into that exact
        # space.  This avoids reintroducing a Maya/Blender world-axis guess.
        for control_data, fallback, collection_name in (
            (switch, start, "FKIKSystem"),
            (ik_control, end, "IKSystem"),
            (pole_control, None, "IKSystem"),
        ):
            control_name = str(control_data.get("name", ""))
            control = armature.data.edit_bones.get(control_name)
            if control is None:
                control = armature.data.edit_bones.new(control_name)
                if collection_name == "FKIKSystem":
                    created_switches += 1
                else:
                    created_ik += 1
            if fallback is not None:
                control.matrix = fallback.matrix.copy()
                control.length = max(fallback.length, 0.25)
            else:
                world_matrix = _maya_controller_matrix_to_blender(control_data)
                if world_matrix is None:
                    continue
                control.matrix = _maya_world_to_armature_rest(armature, world_matrix)
                control.length = 0.35
            # For an FKIK switch, ``parent`` is AdvancedSkeleton's logical
            # control-system parent (often Main). Its physical attachment is
            # the declared joint: FKIKArm_R follows Shoulder_R, for example,
            # regardless of whether that limb currently uses FK or IK.
            parent = main
            if collection_name == "FKIKSystem":
                attachment_joint = armature.data.edit_bones.get(
                    str(control_data.get("joint", ""))
                )
                if attachment_joint is not None and attachment_joint != control:
                    parent = attachment_joint
            control.parent = parent
            control.use_connect = False
            if fallback is not None:
                control.matrix = fallback.matrix.copy()
            else:
                control.matrix = _maya_world_to_armature_rest(armature, world_matrix)
            control.use_deform = False

        # A leg pole lives in IKLeg space with its authored world-space
        # offset preserved.  Represent that offset explicitly as a hidden
        # mechanism bone rather than a Child Of inverse; this is deterministic
        # on every rebuild and has the same animator-facing behaviour as a
        # maintained-offset parent constraint.
        ik_control_name = str(ik_control.get("name", ""))
        pole_control_name = str(pole_control.get("name", ""))
        if ik_control_name.startswith("IKLeg"):
            ik_edit = armature.data.edit_bones.get(ik_control_name)
            pole_edit = armature.data.edit_bones.get(pole_control_name)
            if ik_edit is not None and pole_edit is not None:
                offset_name = "PoleOffset" + pole_control_name.removeprefix("Pole")
                offset = armature.data.edit_bones.get(offset_name)
                if offset is None:
                    offset = armature.data.edit_bones.new(offset_name)
                pole_matrix = pole_edit.matrix.copy()
                offset.matrix = pole_matrix
                offset.length = max(pole_edit.length, 0.25)
                offset.parent = ik_edit
                offset.use_connect = False
                offset.matrix = pole_matrix
                offset.use_deform = False
                pole_edit.parent = offset
                pole_edit.use_connect = False
                pole_edit.matrix = pole_matrix
                leg_pole_offsets.append(offset_name)

        # A clean native chain always uses Blender +Y head-to-tail.  Preserve
        # the imported bend direction; it prevents a straight-chain pole flip
        # without changing the imported deformation bones themselves.
        positions = [start.head.copy(), middle.head.copy(), end.head.copy()]
        pole_world = _maya_controller_matrix_to_blender(pole_control)
        pole_local = (
            _maya_world_to_armature_rest(armature, pole_world.translation)
            if pole_world is not None else positions[1] + Vector((0.0, 1.0, 0.0))
        )
        previous = None
        helpers = []
        source_bones = (start, middle, end)
        for index, source_bone in enumerate(source_bones):
            helper_name = "IK" + source_bone.name
            helper = armature.data.edit_bones.get(helper_name)
            if helper is None:
                helper = armature.data.edit_bones.new(helper_name)
            helper.head = positions[index]
            helper.tail = positions[index + 1] if index < 2 else source_bone.tail.copy()
            if (helper.tail - helper.head).length < 0.00001:
                helper.tail.y += 0.01
            y_axis = (helper.tail - helper.head).normalized()
            x_axis = pole_local - helper.head
            x_axis -= y_axis * x_axis.dot(y_axis)
            if x_axis.length < 0.00001:
                x_axis = y_axis.orthogonal()
            else:
                x_axis.normalize()
            z_axis = x_axis.cross(y_axis).normalized()
            matrix = Matrix((x_axis, y_axis, z_axis)).transposed().to_4x4()
            matrix.translation = helper.head
            length = helper.length
            helper.matrix = matrix
            helper.length = length
            helper.parent = previous if previous is not None else start.parent
            helper.use_connect = False
            helper.use_deform = False
            # IK helpers must not inherit a Spline IK control's local scale
            # through the imported deform parent.  That changes their native
            # length and falsely triggers Blender's stretch solver on legs.
            helper.inherit_scale = "NONE"
            previous = helper
            helpers.append(helper_name)

        # IKX is the deformation-space adapter.  It inherits the solved IK
        # helper motion, but its rest axes are copied exactly from the target
        # deformation joint.  This is the native-bone equivalent of the old
        # IKX transform group and avoids applying a helper's +Y chain basis
        # directly to a Maya-oriented deform joint.
        for index, (source_bone, helper_name) in enumerate(zip(source_bones, helpers)):
            adapter_name = "IKX" + source_bone.name
            adapter = armature.data.edit_bones.get(adapter_name)
            if adapter is None:
                adapter = armature.data.edit_bones.new(adapter_name)
            adapter.matrix = source_bone.matrix.copy()
            adapter.length = max(source_bone.length, 0.25)
            # All three adapters follow the solved chain.  In particular, the
            # end adapter must *not* be parented directly to the animator IK
            # target: that would pull the ankle/wrist past an unstretched
            # limb's reach and bypass Blender's IK distance limit.
            adapter.parent = armature.data.edit_bones.get(helper_name)
            adapter.use_connect = False
            adapter.use_deform = False
            # Parenting changes the adapter's local space. Restore its world
            # rest matrix afterwards so its axes remain exactly those of the
            # deformation joint rather than those of the +Y IK helper.
            adapter.matrix = source_bone.matrix.copy()
        helper_names[str(switch.get("name", ""))] = helpers

    bpy.ops.object.mode_set(mode="OBJECT")
    fkik_collection = _find_bone_collection(armature.data, "FKIKSystem")
    ik_collection = _find_bone_collection(armature.data, "IKSystem")
    mechanism = _find_bone_collection(armature.data, "Mechanism")

    for offset_name in leg_pole_offsets:
        bone = armature.data.bones.get(offset_name)
        if bone is None:
            continue
        bone.use_deform = False
        bone.hide = True
        for old_collection in tuple(bone.collections):
            old_collection.unassign(bone)
        mechanism.assign(bone)
    # Migration cleanup for the short-lived Child Of implementation.  Its
    # inverse could be evaluated from a previously constrained pose, so it
    # must never survive into the stable offset-bone hierarchy.
    for _switch, ik_control, pole_control, _names, _ik_data in specs:
        if not str(ik_control.get("name", "")).startswith("IKLeg"):
            continue
        pole_pose = armature.pose.bones.get(str(pole_control.get("name", "")))
        if pole_pose is not None:
            constraint = pole_pose.constraints.get("AS_Leg_Pole_Follow")
            if constraint is not None:
                pole_pose.constraints.remove(constraint)

    for switch, ik_control, pole_control, names, ik_data in specs:
        for control_data, collection in (
            (switch, fkik_collection),
            (ik_control, ik_collection),
            (pole_control, ik_collection),
        ):
            bone = armature.data.bones.get(str(control_data.get("name", "")))
            if bone is None:
                continue
            bone.use_deform = False
            if str(control_data.get("name", "")).startswith("FKIK"):
                # This is ordinary Pose Bone hierarchy, not a constraint.
                # Make inherited parent transforms explicit for switch bones.
                bone.use_inherit_rotation = True
                bone.use_local_location = True
            for old_collection in tuple(bone.collections):
                old_collection.unassign(bone)
            collection.assign(bone)
            widget = _create_control_widget(
                context.scene,
                control_data,
                bone.name,
                _control_widget_rest_matrix(armature, bone),
            )
            if widget is not None:
                _configure_control_display(armature.pose.bones[bone.name], widget, control_data)

        switch_pose = armature.pose.bones.get(str(switch.get("name", "")))
        if switch_pose is not None:
            blend = max(0.0, min(1.0, _control_attribute_value(switch, "FKIKBlend") / 10.0))
            switch_pose["FKIKBlend"] = blend
            switch_pose.id_properties_ui("FKIKBlend").update(
                default=blend, min=0.0, max=1.0, soft_min=0.0, soft_max=1.0,
                description="Blend this limb from FK (0) to IK (1)",
            )
            auto_vis = True
            switch_pose["autoVis"] = auto_vis
            switch_pose.id_properties_ui("autoVis").update(
                default=auto_vis,
                description="Automatically show the active FK or IK controls",
            )
            for property_name, description in (
                ("FKVis", "Show FK controls"),
                ("IKVis", "Show IK controls"),
            ):
                if _has_control_attribute(switch, property_name):
                    value = _control_attribute_value(switch, property_name) >= 0.5
                    switch_pose[property_name] = value
                    switch_pose.id_properties_ui(property_name).update(
                        default=value, description=description,
                    )

        ik_pose = armature.pose.bones.get(str(ik_control.get("name", "")))
        has_stretchy = ik_pose is not None and _has_control_attribute(ik_control, "stretchy")
        if has_stretchy:
            stretchy = _control_attribute_value(ik_control, "stretchy") >= 0.5
            ik_pose["stretchy"] = stretchy
            ik_pose.id_properties_ui("stretchy").update(
                default=stretchy,
                description="Allow this IK limb to extend past its build length",
            )
        elif ik_pose is not None and "stretchy" in ik_pose:
            del ik_pose["stretchy"]

        helpers = helper_names.get(str(switch.get("name", "")), [])
        if len(helpers) != 3:
            continue

        # Native Blender IK measures the length of this hidden +Y helper
        # chain.  The animator-facing IK target already inherits Main, so the
        # helper chain must inherit that *same* uniform scale or Main=0.5 makes
        # the target appear half a limb-length away and the solver bends the
        # limb to compensate.  Keep the first helper isolated from its deform
        # parent (which may be inside another solver), then let the remaining
        # helpers inherit that one uniform scale down the chain.  Do not add a
        # Copy Scale constraint to every helper: that would multiply Main once
        # per segment.
        for helper_index, helper_name in enumerate(helpers):
            helper_bone = armature.data.bones.get(helper_name)
            helper_pose = armature.pose.bones.get(helper_name)
            if helper_bone is None or helper_pose is None:
                continue
            helper_bone.inherit_scale = "NONE" if helper_index == 0 else "FULL"
            existing_main_scale = helper_pose.constraints.get("AS_IK_Helper_Main_Scale")
            if existing_main_scale is not None:
                helper_pose.constraints.remove(existing_main_scale)
            if helper_index == 0:
                helper_main_scale = helper_pose.constraints.new("COPY_SCALE")
                helper_main_scale.name = "AS_IK_Helper_Main_Scale"
                helper_main_scale.target = armature
                helper_main_scale.subtarget = "Main"
                helper_main_scale.owner_space = "LOCAL"
                helper_main_scale.target_space = "LOCAL"

        for helper_name in helpers:
            for mechanism_name in (helper_name, "IKX" + helper_name.removeprefix("IK")):
                bone = armature.data.bones.get(mechanism_name)
                if bone is None:
                    continue
                bone.use_deform = False
                bone.hide = True
                for old_collection in tuple(bone.collections):
                    old_collection.unassign(bone)
                mechanism.assign(bone)

        middle_helper = armature.pose.bones[helpers[1]]
        existing = middle_helper.constraints.get("AS_IK_Solve")
        if existing is not None:
            middle_helper.constraints.remove(existing)
        solve = middle_helper.constraints.new("IK")
        solve.name = "AS_IK_Solve"
        solve.target = armature
        solve.subtarget = str(ik_control.get("name", ""))
        solve.pole_target = armature
        solve.pole_subtarget = str(pole_control.get("name", ""))
        solve.chain_count = 2
        solve.use_tail = True
        solve.use_stretch = has_stretchy
        if has_stretchy:
            _configure_ik_stretch(
                armature,
                helpers,
                ik_pose.name,
                str(switch.get("name", "")),
                names,
                ik_data.get("primaryAxis", (1.0, 0.0, 0.0)),
            )

        # The end helper is already a child of the solved middle helper.  Do
        # not add a target constraint here: it would make the end joint follow
        # IKLeg/IKArm directly even when the chain cannot reach the target.
        end_helper = armature.pose.bones[helpers[2]]
        existing = end_helper.constraints.get("AS_IK_End_Target")
        if existing is not None:
            end_helper.constraints.remove(existing)

        # IKX is also the source used by FKIKMix / TwistSystem.  The solved
        # chain supplies its end position, but its orientation alone does not
        # include the animator's wrist/foot roll.  Mirror the endpoint's
        # rotation source onto IKX so UpTwist is driven identically in FK and
        # IK.  Reverse-foot construction may redirect this one constraint to
        # its final foot-space pivot below.
        end_joint_name = names[2]
        end_adapter = armature.pose.bones.get("IKX" + end_joint_name)
        if end_adapter is not None:
            existing = end_adapter.constraints.get("AS_IKX_End_Rotation")
            if existing is not None:
                end_adapter.constraints.remove(existing)
            adapter_rotation = end_adapter.constraints.new("COPY_ROTATION")
            adapter_rotation.name = "AS_IKX_End_Rotation"
            adapter_rotation.target = armature
            adapter_rotation.subtarget = str(ik_control.get("name", ""))
            adapter_rotation.owner_space = "POSE"
            adapter_rotation.target_space = "POSE"
            adapter_rotation.mix_mode = "REPLACE"

        for index, (joint_name, helper_name) in enumerate(zip(names, helpers)):
            deform = armature.pose.bones.get(joint_name)
            if deform is None:
                continue
            for constraint_name in (
                "AS_IK_Control", "AS_IK_Location", "AS_IK_End_Location", "AS_IK_End_Rotation",
                "AS_IK_End_Scale", "AS_Main_Scale",
            ):
                existing = deform.constraints.get(constraint_name)
                if existing is not None:
                    deform.constraints.remove(existing)

            # Restore only the intended uniform character scale.  This is
            # deliberately independent of the imported deform hierarchy, so
            # spline-control scale cannot make an IK limb fat or bent.
            main_scale = deform.constraints.new("COPY_SCALE")
            main_scale.name = "AS_Main_Scale"
            main_scale.target = armature
            main_scale.subtarget = "Main"
            main_scale.owner_space = "LOCAL"
            main_scale.target_space = "LOCAL"
            main_scale.use_offset = True
            # FKX already inherits Main through the normal control hierarchy.
            # Applying this explicit scale on the FK side as well multiplies
            # Main twice (for example Main=2 produced a 4x FK limb).  The
            # constraint exists exclusively to restore Main scale for the
            # isolated native IK solve, so blend it in with the IK side.
            _add_property_influence_driver(
                main_scale, armature, str(switch.get("name", "")), "fkik",
            )

            if index < 2:
                # Start and middle inherit the solved position/orientation,
                # but not the helper's scale. Stretch is handled explicitly
                # on the one intended local axis below.
                ik_location = deform.constraints.new("COPY_LOCATION")
                ik_location.name = "AS_IK_Location"
                ik_location.target = armature
                ik_location.subtarget = "IKX" + joint_name
                ik_location.owner_space = "POSE"
                ik_location.target_space = "POSE"
                _add_property_influence_driver(
                    ik_location, armature, str(switch.get("name", "")), "fkik",
                )
                ik_follow = deform.constraints.new("COPY_ROTATION")
                ik_follow.name = "AS_IK_Control"
                ik_follow.target = armature
                ik_follow.subtarget = "IKX" + joint_name
                ik_follow.owner_space = "POSE"
                ik_follow.target_space = "POSE"
                _add_property_influence_driver(
                    ik_follow, armature, str(switch.get("name", "")), "fkik",
                )
            else:
                # The limb endpoint has two intentionally separate jobs:
                # the solved IKX chain supplies its capped location, while
                # the animator-facing IK controller supplies hand/foot roll.
                ik_location = deform.constraints.new("COPY_LOCATION")
                ik_location.name = "AS_IK_End_Location"
                ik_location.target = armature
                ik_location.subtarget = "IKX" + joint_name
                ik_location.owner_space = "POSE"
                ik_location.target_space = "POSE"
                _add_property_influence_driver(
                    ik_location, armature, str(switch.get("name", "")), "fkik",
                )

                ik_rotation = deform.constraints.new("COPY_ROTATION")
                ik_rotation.name = "AS_IK_End_Rotation"
                ik_rotation.target = armature
                ik_rotation.subtarget = str(ik_control.get("name", ""))
                ik_rotation.owner_space = "POSE"
                ik_rotation.target_space = "POSE"
                ik_rotation.mix_mode = "REPLACE"
                _add_property_influence_driver(
                    ik_rotation, armature, str(switch.get("name", "")), "fkik",
                )

                # Match the ordinary FK behaviour: scaling FKWrist/FKAnkle
                # scales the limb endpoint.  In IK the animator instead
                # scales IKArm/IKLeg, so pass that local scale to the same
                # endpoint only on the IK side of the switch.  Location and
                # rotation remain separate above; this does not make an
                # unstretched limb chase an out-of-reach IK target.
                ik_scale = deform.constraints.new("COPY_SCALE")
                ik_scale.name = "AS_IK_End_Scale"
                ik_scale.target = armature
                ik_scale.subtarget = str(ik_control.get("name", ""))
                ik_scale.owner_space = "LOCAL"
                ik_scale.target_space = "LOCAL"
                ik_scale.use_offset = True
                _add_property_influence_driver(
                    ik_scale, armature, str(switch.get("name", "")), "fkik",
                )
            fk_follow = deform.constraints.get("AS_FK_Control")
            if fk_follow is not None:
                _add_property_influence_driver(
                    fk_follow, armature, str(switch.get("name", "")), "1.0 - fkik",
                )

        # FKVis / IKVis are visual-only animator switches.  Use shape scale
        # instead of hide_viewport so they cannot accidentally make a control
        # unselectable when it is shown again.
        switch_name = str(switch.get("name", ""))
        for control_data in json_data["rig"]["controls"]:
            control_name = str(control_data.get("name", ""))
            if (
                control_data.get("joint") in names
                and control_name.startswith("FK")
                and not control_name.startswith("FKIK")
            ):
                pose_bone = armature.pose.bones.get(control_name)
                if pose_bone is not None:
                    _drive_control_shape_visibility(
                        pose_bone, armature, switch_name, "FK",
                    )
        for control_name in (
            str(ik_control.get("name", "")),
            str(pole_control.get("name", "")),
        ):
            pose_bone = armature.pose.bones.get(control_name)
            if pose_bone is not None:
                _drive_control_shape_visibility(
                    pose_bone, armature, switch_name, "IK",
                )
    return created_ik, created_switches


def _create_system_bone_collections(rig):
    """Create AdvancedSkeleton's familiar systems as Blender Bone Collections.

    These are intentionally collections, not placeholder bones. They organize
    the eventual CTRL and MCH bones without introducing fake transforms into
    the rig.
    """
    armature = rig.data
    deformation = _find_bone_collection(armature, "DeformationSystem")
    if deformation is None:
        deformation = armature.collections.new("DeformationSystem")

    motion = _find_bone_collection(armature, "MotionSystem")
    if motion is None:
        motion = armature.collections.new("MotionSystem")
    controls = _find_bone_collection(armature, "Controls")
    if controls is None:
        controls = armature.collections.new("Controls", parent=motion)
    for name in (
        "MainSystem",
        "FKSystem",
        "IKSystem",
        "FKIKSystem",
        "BendSystem",
        "AimSystem",
        "RootSystem",
        "TwistSystem",
        "DrivingSystem",
    ):
        collection = _find_bone_collection(armature, name)
        if collection is None:
            armature.collections.new(name, parent=controls)
        elif collection.parent != controls:
            # Builds made before the Controls parent existed are upgraded in
            # place. Bone collections retain their members while reparented.
            collection.parent = controls

    # Hidden implementation bones follow Blender's usual MCH pattern.  They
    # are not animator controls and therefore do not belong in the visible
    # Controls hierarchy.
    mechanism = _find_bone_collection(armature, "Mechanism")
    if mechanism is None:
        mechanism = armature.collections.new("Mechanism", parent=motion)
    elif mechanism.parent != motion:
        mechanism.parent = motion
    mechanism.is_visible = False

    # Build calls this before adding any CTRL/MCH bones.  Therefore every bone
    # that exists at this point came from the FBX and belongs to the imported
    # deformation skeleton.  Do not rely on Bone.use_deform here: FBX import
    # does not reliably preserve that Blender-specific flag.
    # Control/mechanism bones are assigned separately after their creation.
    for bone in armature.bones:
        for collection in tuple(bone.collections):
            collection.unassign(bone)
        deformation.assign(bone)


def _normalize_main_scale_inheritance(armature, json_data):
    """Let non-solver deform branches inherit Main's uniform character scale.

    The three direct bones of each native RP/Spline solver retain the FBX
    inheritance modes Blender imported: changing those modes alters the IK
    solve and, in turn, the FK/IK-independent twist mix.  Everything outside
    those solver chains (including face and Twist Part branches) should use
    ordinary Blender FULL inheritance so Main's character scale propagates
    once through the deformation hierarchy.
    """
    solver_joints = set()
    for _switch, _ik, _pole, names, _data in _ik_limb_specs(json_data):
        solver_joints.update(names)
    for _system, joints, _controls in _spline_ik_specs(json_data):
        solver_joints.update(joints)
    updated = 0
    for bone in armature.data.bones:
        if bone.name in solver_joints:
            continue
        if bone.inherit_scale != "FULL":
            bone.inherit_scale = "FULL"
            updated += 1
    return updated


def _remove_generated_rig(scene, source):
    """Remove the generated deformation armature and restore the raw import."""
    rig = _generated_rig(scene)
    if rig is None:
        return
    for obj in scene.objects:
        if obj.type != "MESH":
            continue
        for modifier in obj.modifiers:
            if modifier.type == "ARMATURE" and modifier.object == rig:
                modifier.object = source
    rig_data = rig.data
    bpy.data.objects.remove(rig, do_unlink=True)
    if rig_data.users == 0:
        bpy.data.armatures.remove(rig_data)
    if "as_rig_armature" in scene:
        del scene["as_rig_armature"]


class ADVANCEDSKELETON_OT_import_fbx(bpy.types.Operator, ImportHelper):
    """Import an AdvancedSkeleton FBX skeleton and geometry export."""

    bl_idname = "advanced_skeleton.import_fbx"
    bl_label = "Import FBX"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".fbx"
    filter_glob: bpy.props.StringProperty(default="*.fbx", options={"HIDDEN"})

    def execute(self, context):
        return _import_fbx_into_scene(self, context, self.filepath)


def _import_fbx_into_scene(operator, context, filepath):
    """Import an FBX and record it as the current AdvancedSkeleton session."""
    if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode="OBJECT")

    before = set(bpy.data.objects)
    try:
        _import_fbx(filepath)
    except Exception as error:
        message = f"FBX import failed: {error}"
        _set_status(context.scene, message)
        operator.report({"ERROR"}, message)
        return {"CANCELLED"}

    imported = set(bpy.data.objects) - before
    armatures = sorted(
        (obj for obj in imported if obj.type == "ARMATURE"), key=lambda obj: obj.name
    )
    generation = int(context.scene.get("as_import_generation", 0)) + 1
    session_id = f"AS_IMPORT_{generation}"
    for obj in imported:
        obj["as_import_session_id"] = session_id
    for armature in armatures:
        armature["advanced_skeleton_role"] = "IMPORTED_SKELETON"
        armature["advanced_skeleton_fbx_path"] = filepath

    # OPM Maya rigs may arrive as a broken FBX rest skeleton plus a constant,
    # baked pose action which restores the correct joint placement. Convert
    # only that proven static-compensation case with Blender's native rest-pose
    # operation. This is intentionally JSON-independent and never touches
    # ordinary animated FBXs.
    baked_static_pose_armatures = _bake_static_import_pose_to_rest(context, armatures)

    context.scene["as_import_fbx_path"] = filepath
    context.scene["as_import_generation"] = generation
    context.scene["as_import_session_id"] = session_id
    context.scene["as_import_armatures"] = [armature.name for armature in armatures]
    context.scene["as_import_object_count"] = len(imported)
    context.scene["as_import_body_json_loaded"] = False
    # Always apply the current Character Scale. A reload keeps the value
    # selected by the user rather than resetting it.
    _apply_character_scale(context.scene)
    if armatures:
        message = f"Imported FBX: {len(armatures)} skeleton(s), {len(imported)} object(s)."
    else:
        message = f"Imported FBX: {len(imported)} object(s); no armature was found."
    if "as_import_repaired_bones" in context.scene:
        del context.scene["as_import_repaired_bones"]
    if baked_static_pose_armatures:
        message += (
            f" Baked {len(baked_static_pose_armatures)} static FBX pose "
            "action(s) into the rest pose."
        )
    _set_status(context.scene, message)
    operator.report({"INFO"}, message)
    return {"FINISHED"}


class ADVANCEDSKELETON_OT_reload_fbx(bpy.types.Operator):
    """Replace the current import and generated deformation rig using its FBX."""

    bl_idname = "advanced_skeleton.reload_fbx"
    bl_label = "Reload FBX"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _has_current_import(context.scene) and bool(
            context.scene.get("as_import_fbx_path", "")
        )

    def draw(self, _context):
        self.layout.label(text="This will remove the current FBX import and generated rig.")
        self.layout.label(text="Character Scale and selected JSON files will be retained.")

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self,
            event,
            title="Reload FBX?",
            message="Replace the current FBX import and generated rig?",
            confirm_text="Reload FBX",
        )

    def execute(self, context):
        filepath = context.scene.get("as_import_fbx_path", "")
        if not filepath:
            self.report({"ERROR"}, "No previous FBX path is available to reload.")
            return {"CANCELLED"}
        _clear_current_import(context.scene)
        return _import_fbx_into_scene(self, context, filepath)


class ADVANCEDSKELETON_OT_load_body_json(bpy.types.Operator):
    """Validate the selected Body JSON against the imported skeleton."""

    bl_idname = "advanced_skeleton.load_body_json"
    bl_label = "Read Body JSON"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        data, error = _load_body_json(context.scene.advanced_skeleton_body_json_path)
        if error:
            _set_status(context.scene, error)
            self.report({"ERROR"}, error)
            return {"CANCELLED"}

        controls = data["rig"]["controls"]
        declared_joints = {
            control.get("joint")
            for control in controls
            if isinstance(control, dict) and isinstance(control.get("joint"), str)
        }
        declared_joints.discard("")
        imported_bones = {
            bone.name
            for armature in _armatures_from_scene(context.scene)
            for bone in armature.data.bones
        }
        matched = len(declared_joints & imported_bones)
        repaired_bones = _repair_zeroed_fbx_bone_heads(
            context, _armatures_from_scene(context.scene), data
        )

        # Persist only small session metadata. The external JSON remains
        # authoritative until a future compatibility importer normalizes it
        # into a native Blender Fit Skeleton definition.
        context.scene["as_import_body_json_path"] = context.scene.advanced_skeleton_body_json_path
        context.scene["as_import_control_count"] = len(controls)
        context.scene["as_import_declared_joint_count"] = len(declared_joints)
        context.scene["as_import_matched_joint_count"] = matched
        context.scene["as_import_body_json_loaded"] = True
        message = (
            f"Read Body JSON: {len(controls)} controls; "
            f"{matched}/{len(declared_joints)} declared joints match the imported FBX."
        )
        if repaired_bones:
            message += f" Repaired {len(repaired_bones)} zeroed FBX bone head(s)."
            context.scene["as_import_repaired_bones"] = repaired_bones
        _set_status(context.scene, message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_set_character_scale(bpy.types.Operator):
    """Apply the requested display scale to the imported skeleton."""

    bl_idname = "advanced_skeleton.set_character_scale"
    bl_label = "Set Scale"
    bl_options = {"REGISTER", "UNDO"}

    def draw(self, _context):
        self.layout.label(text="This will remove the current rig and reload the FBX.")
        self.layout.label(text="The selected Character Scale and Body JSON will be retained.")

    def invoke(self, context, event):
        if _generated_rig(context.scene) is not None:
            return context.window_manager.invoke_confirm(
                self,
                event,
                title="Set Scale and Reload FBX?",
                message="The current rig will be removed and the FBX reloaded.",
                confirm_text="Reload FBX",
            )
        return self.execute(context)

    def execute(self, context):
        armatures = _armatures_from_scene(context.scene)
        if not armatures:
            message = "Import an FBX skeleton before setting character scale."
            _set_status(context.scene, message)
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        if _generated_rig(context.scene) is not None:
            filepath = context.scene.get("as_import_fbx_path", "")
            if not filepath:
                message = "No previous FBX path is available to reload at the new scale."
                _set_status(context.scene, message)
                self.report({"ERROR"}, message)
                return {"CANCELLED"}
            _clear_current_import(context.scene)
            # _import_fbx_into_scene applies the current Character Scale.
            return _import_fbx_into_scene(self, context, filepath)
        message = _apply_character_scale(context.scene)
        _set_status(context.scene, message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_build_rig(bpy.types.Operator):
    """Create the native Blender body rig from the imported skeleton."""

    bl_idname = "advanced_skeleton.build_rig"
    bl_label = "Build Body Rig"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode="OBJECT")

        json_data, json_error = _load_body_json(
            context.scene.advanced_skeleton_body_json_path
        )
        if json_error:
            _set_status(context.scene, json_error)
            self.report({"ERROR"}, json_error)
            return {"CANCELLED"}
        main_data = next(
            (
                control for control in json_data["rig"]["controls"]
                if control.get("name") == "Main"
            ),
            None,
        )
        if main_data is None:
            message = "Body JSON has no Main control."
            _set_status(context.scene, message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        root_x_data = next(
            (
                control for control in json_data["rig"]["controls"]
                if control.get("name") == "RootX_M"
            ),
            None,
        )
        if root_x_data is None:
            message = "Body JSON has no RootX_M control."
            _set_status(context.scene, message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        fk_controls = _fk_control_definitions(json_data)
        ik_end_joints = {
            names[2] for _switch, _ik, _pole, names, _data
            in _ik_limb_specs(json_data)
        }
        # A Spline IK endpoint is equally an IK boundary.  FK branches that
        # start immediately below it (for example Scapula below Chest) must
        # attach to the final deformation joint, not to an FK helper, so they
        # continue following whether the upstream spline uses FK or IK.
        ik_end_joints.update(
            joints[-1]
            for _system, joints, _controls in _spline_ik_specs(json_data)
            if joints
        )
        # Preserve each system's full declared joint membership as well.  FK
        # branch attachment uses it to find any direct child that exits an IK
        # chain; a spline root may have such a child long before the spline
        # endpoint (for example, Cody's tail below Root).
        ik_joint_sets = [
            set(joints)
            for _switch, _ik, _pole, joints, _data in _ik_limb_specs(json_data)
        ]
        spline_joint_sets = [
            set(joints)
            for _system, joints, _controls in _spline_ik_specs(json_data)
        ]
        ik_joint_sets.extend(
            set(joints)
            for _system, joints, _controls in _spline_ik_specs(json_data)
        )

        sources = _armatures_from_scene(context.scene)
        if len(sources) != 1:
            message = "Build Rig currently requires exactly one imported FBX armature."
            _set_status(context.scene, message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        source = sources[0]

        # The Body JSON may have been selected after the FBX was imported.
        # Run the narrowly-scoped import repair again here so Build Rig never
        # starts from an origin-collapsed rest bone plus compensating pose
        # keys. A healthy import is a no-op.
        repaired_on_build = _repair_zeroed_fbx_bone_heads(context, sources, json_data)

        # The body rebuild changes the armature's rest/control structure.
        # Remove the separately-built Face solver first; Build Face Rig can
        # cleanly add it back after this body build completes.
        _remove_embedded_face_solver()

        # A repeated Build Rig updates this initial foundation in place. Clear
        # any animator pose first, so rebuilding never bakes a temporary pose
        # into the native hierarchy or its controller display setup.
        if _generated_rig(context.scene) is not None:
            _return_armature_to_build_pose(context, source, select_main=False)
            bpy.ops.object.mode_set(mode="OBJECT")

        # One-armature architecture: the imported armature itself becomes the
        # final Armature. Build adds Blender Bone Collections and later adds
        # CTRL/MCH bones directly here; it does not make a duplicate skeleton.
        legacy_rig = _generated_rig(context.scene)
        if legacy_rig is not None and legacy_rig != source:
            _remove_generated_rig(context.scene, source)
        source.name = "Armature"
        source.data.name = "Armature Data"
        source["advanced_skeleton_role"] = "RIG"
        context.scene["as_import_armatures"] = [source.name]
        source["as_import_session_id"] = _current_import_session_id(context.scene)
        _create_system_bone_collections(source)
        _normalize_main_scale_inheritance(source, json_data)

        removed_empty_groups = _remove_imported_empty_groups(context.scene)
        organized_meshes = _organize_imported_geometry(context.scene)
        source.hide_set(False)
        source.hide_render = False
        context.scene["as_rig_armature"] = source.name
        _create_main_control(context, source, main_data)
        _set_main_advanced_skeleton_version(source, json_data)
        _create_root_x_control(context, source, root_x_data)
        created_fk = _create_fk_controls(
            context,
            source,
            fk_controls,
            root_x_data.get("joint", ""),
            ik_end_joints,
            ik_joint_sets,
            spline_joint_sets,
        )
        connected_fk = _connect_fk_controls_to_deformation(source, fk_controls)
        created_spline = _create_spline_ik_controls(
            context, source, json_data,
        )
        created_ik, created_fkik = _create_ik_and_fkik_controls(
            context, source, json_data,
        )
        created_reverse_foot = _create_reverse_foot_controls(
            context, source, json_data,
        )
        created_twist, twist_links = _create_twist_system(
            context, source, json_data, fk_controls,
        )
        created_driving, driving_relationships = _create_driving_system_controls(
            context, source, json_data,
        )
        _finalize_inbetween_visibility(source, fk_controls)
        _configure_main_control_visibility(source)
        _configure_main_geometry_visibility(source)
        _ensure_embedded_rig_ui(source)
        bpy.ops.object.mode_set(mode="POSE")
        bpy.ops.pose.select_all(action="DESELECT")
        main_bone = source.data.bones.get("Main")
        if main_bone is not None:
            source.data.bones.active = main_bone
            source.pose.bones["Main"].select = True
        _set_animator_viewport_defaults(context, source)
        _collapse_outliners(context)
        bpy.app.timers.register(_collapse_outliners_after_ui_refresh, first_interval=0.1)

        deformation = _find_bone_collection(source.data, "DeformationSystem")
        deformation_count = len(deformation.bones) if deformation is not None else 0
        message = (
            f"Built Armature: Main + RootX_M + {deformation_count} deformation bones, "
            f"{created_fk} FK control bone(s), {created_ik + created_spline} IK control bone(s), "
            f"{created_fkik} FKIK switch bone(s), {created_reverse_foot} reverse-foot control bone(s), "
            f"{created_twist} TwistSystem helper bone(s), {twist_links} twist link(s), "
            f"{created_driving} DrivingSystem control bone(s), {driving_relationships} native driver(s), "
            f"{connected_fk} FK rotation link(s), "
            f"9 MotionSystem collections, "
            f"no duplicate armature created, "
            f"{removed_empty_groups} FBX Empty group(s) removed, "
            f"{organized_meshes} mesh(es) placed in Geometry."
        )
        if repaired_on_build:
            message += f" Repaired {len(repaired_on_build)} FBX bone(s) before build."
        _set_status(context.scene, message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_build_face_rig(bpy.types.Operator):
    """Build the initial Face Control Box layout from the Face JSON."""

    bl_idname = "advanced_skeleton.build_face_rig"
    bl_label = "Build Face Rig"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _generated_rig(context.scene) is not None

    def execute(self, context):
        face_data, face_error = _load_face_json(
            context.scene.advanced_skeleton_face_json_path
        )
        if face_error:
            _set_status(context.scene, face_error)
            self.report({"ERROR"}, face_error)
            return {"CANCELLED"}
        source = _generated_rig(context.scene)
        if source is None:
            self.report({"ERROR"}, "Build the Body Rig before building the Face Rig.")
            return {"CANCELLED"}
        if context.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode="OBJECT")
        # Rebuild the self-contained aggregated Face SDK solver after the
        # native ctrlBox controls have been recreated.
        _remove_embedded_face_solver()
        _remove_generated_face_controls(context, source)
        control_count = _create_face_control_box(context, source, face_data)
        face_controls = {
            str(item.get("control", ""))
            for item in face_data.get("drivers", [])
            if isinstance(item, dict)
            and str(item.get("controlParent", "")).startswith("ctrlBox")
            and str(item.get("control", "")).startswith("ctrl")
        }
        # On-face controls are deliberately shelved for now.  Their follow
        # and display-offset work is not allowed to alter the proven ctrlBox
        # SDK solve, particularly ctrlMouth_M's Jaw relationship.  The face
        # rebuild cleanup above removes any previously generated on-face
        # controls/widgets before rebuilding this stable Control Box layer.
        solver_data = face_data
        all_face_controls = face_controls
        _add_face_control_properties(source, solver_data, all_face_controls)
        sdk_rows = _ensure_embedded_face_solver(
            context, source, solver_data, controls=all_face_controls,
        )
        _ensure_embedded_rig_ui(source)
        bpy.ops.object.mode_set(mode="POSE")
        bpy.ops.pose.select_all(action="DESELECT")
        box_bone = source.data.bones.get("ctrlBox")
        if box_bone is not None:
            source.data.bones.active = box_bone
            source.pose.bones["ctrlBox"].select = True
        _set_status(
            context.scene,
            f"Built Face Rig: ctrlBox + {control_count - 1} 2D Face controls, "
            f"{sdk_rows} SDK channel(s).",
        )
        self.report({"INFO"}, "Built Face Rig")
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_go_to_build_pose(bpy.types.Operator):
    """Return the rig to its Blender rest/build pose using native pose tools."""

    bl_idname = "advanced_skeleton.go_to_build_pose"
    bl_label = "Go to Build Pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _generated_rig(context.scene) is not None

    def execute(self, context):
        armature = _generated_rig(context.scene)
        # This is Blender's native Pose > Clear Transform command. It resets
        # location, rotation, and scale offsets back to the bones' rest values.
        _return_armature_to_build_pose(context, armature)
        self.report({"INFO"}, "Returned to Build Pose")
        return {"FINISHED"}


def _reload_addon_after_operator_finishes():
    """Reload after Blender has finished executing the UI operator.

    Unregistering a panel while Blender is drawing it can crash Blender.  A
    timer defers the work until the current UI event is complete.
    """
    module_name = __package__ or __name__
    addon_module = sys.modules.get(module_name)
    if addon_module is None:
        return None
    try:
        addon_module.unregister()
    except (AttributeError, RuntimeError):
        # A freshly installed Extension can already have had its UI classes
        # removed by Blender while retaining the Python module briefly.
        # Reloading the current installed file is still safe and desirable.
        pass
    # Reinstalling an extension ZIP replaces files on disk.  Without this,
    # Python is allowed to retain its previous file lookup/cache and the
    # developer button can appear to reload an older WIP copy.
    importlib.invalidate_caches()
    addon_module = importlib.reload(addon_module)
    addon_module.register()
    return None


class ADVANCEDSKELETON_OT_reload_addon(bpy.types.Operator):
    """Reload this development add-on after its installed copy is synced."""

    bl_idname = "advanced_skeleton.reload_addon"
    bl_label = "Reload AdvancedSkeleton"

    def execute(self, _context):
        bpy.app.timers.register(_reload_addon_after_operator_finishes, first_interval=0.1)
        self.report({"INFO"}, "AdvancedSkeleton reload scheduled")
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_toggle_spline_ik_curves(bpy.types.Operator):
    """Show or hide only the internal Spline IK solve curves."""

    bl_idname = "advanced_skeleton.toggle_spline_ik_curves"
    bl_label = "Show Spline IK Curves"

    def execute(self, context):
        curves = [
            obj for obj in context.scene.objects
            if obj.type == "CURVE" and obj.name.startswith("MCH_SplineCurve_")
        ]
        if not curves:
            self.report({"WARNING"}, "No Spline IK curves have been built yet.")
            return {"CANCELLED"}
        collection = _get_or_create_scene_collection(context.scene, "SplineIK Debug")
        show = all(obj.hide_get() for obj in curves)
        collection.hide_viewport = not show
        for curve in curves:
            # Move pre-button curves out of Widgets on first use as well.
            if curve.name not in collection.objects:
                collection.objects.link(curve)
            curve.hide_set(not show)
            curve.hide_render = True
        self.report({"INFO"}, "Spline IK curves shown" if show else "Spline IK curves hidden")
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_face_debug_fear(bpy.types.Operator):
    """Write Face Control Box placement diagnostics into the project."""

    bl_idname = "advanced_skeleton.face_debug_fear"
    bl_label = "Write Debug"

    def execute(self, context):
        report_path, error = _write_face_control_box_debug(context.scene, context)
        if report_path is None:
            self.report({"ERROR"}, error)
            return {"CANCELLED"}
        self.report({"INFO"}, f"Wrote {report_path.name} in the AdvancedSkeletonBlender project.")
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_main_scale_debug(bpy.types.Operator):
    """Write the current Main-scale evaluation path into the project."""

    bl_idname = "advanced_skeleton.main_scale_debug"
    bl_label = "Write Main Scale Debug"

    def execute(self, context):
        report_path, error = _write_main_scale_diagnostic(context.scene, context)
        if report_path is None:
            self.report({"ERROR"}, error)
            return {"CANCELLED"}
        self.report({"INFO"}, f"Wrote {report_path.name} in the AdvancedSkeletonBlender project.")
        return {"FINISHED"}


def _default_demo_directory():
    """Find AdvancedSkeleton's downloaded Blender demo folder when possible.

    Blender copies an extension out of an installed ZIP, so its running module
    path does not retain the ZIP's original location.  We first check beside
    the running extension, then the normal Maya AdvancedSkeleton install(s).
    The visible Demo Folder field remains an explicit fallback for custom
    installs or shared/network locations.
    """
    expected_tail = Path("AdvancedSkeletonFiles") / "exampleFiles" / "downloads"
    module_path = Path(__file__).resolve()
    roots = list(module_path.parents)

    maya_app_dir = os.environ.get("MAYA_APP_DIR")
    if maya_app_dir:
        roots.append(Path(maya_app_dir))
    documents_maya = Path.home() / "Documents" / "maya"
    if documents_maya.exists():
        roots.extend(sorted(documents_maya.iterdir(), reverse=True))

    for root in roots:
        direct = root / expected_tail
        if direct.is_dir():
            return str(direct)
        maya_install = root / "scripts" / "AdvancedSkeleton" / expected_tail
        if maya_install.is_dir():
            return str(maya_install)
    return ""


def _demo_blend_items(scene, _context):
    folder_string = scene.advanced_skeleton_demo_directory.strip()
    if not folder_string:
        return [("", "No demo folder found", "Choose a Demo Folder below")]
    folder = Path(bpy.path.abspath(folder_string))
    if not folder.is_dir():
        return [("", "Demo folder not found", str(folder))]
    cache_key = str(folder.resolve())
    cached_items = _DEMO_BLEND_CACHE.get(cache_key)
    if cached_items is not None:
        return cached_items
    files = sorted(
        (path for path in folder.rglob("*.blend") if path.is_file()),
        key=lambda path: str(path).lower(),
    )
    if not files:
        items = [("", "No Blender demo files found", str(folder))]
        _DEMO_BLEND_CACHE[cache_key] = items
        return items
    items = [
        # Keep the animator-facing menu concise ("blaze" rather than a
        # directory path); retain the full path as the hover tooltip.
        (str(path), path.stem, str(path))
        for path in files
    ]
    _DEMO_BLEND_CACHE[cache_key] = items
    return items


class ADVANCEDSKELETON_OT_refresh_demo_files(bpy.types.Operator):
    """Refresh the cached list of available Blender demo files."""

    bl_idname = "advanced_skeleton.refresh_demo_files"
    bl_label = "Refresh Demo Files"

    def execute(self, _context):
        _DEMO_BLEND_CACHE.clear()
        return {"FINISHED"}


class ADVANCEDSKELETON_OT_open_demo_file(bpy.types.Operator):
    """Open the selected AdvancedSkeleton Blender demo file."""

    bl_idname = "advanced_skeleton.open_demo_file"
    bl_label = "Open Demo File"

    def execute(self, context):
        selected_path = context.scene.advanced_skeleton_demo_file
        if not selected_path:
            self.report({"ERROR"}, "Choose a Blender demo file first")
            return {"CANCELLED"}
        filepath = Path(selected_path)
        if not filepath.is_file() or filepath.suffix.lower() != ".blend":
            self.report({"ERROR"}, "Selected demo file no longer exists")
            return {"CANCELLED"}

        # Invoke Blender's own file-open operator instead of recreating its
        # unsaved-changes dialogue.  This preserves the standard Save /
        # Don't Save / Cancel workflow and its usual preferences.
        bpy.ops.wm.open_mainfile(
            "INVOKE_DEFAULT",
            filepath=str(filepath),
            load_ui=True,
            display_file_selector=False,
        )
        return {"FINISHED"}


class ADVANCEDSKELETON_Preferences(bpy.types.AddonPreferences):
    """Persistent, user-level UI preferences for AdvancedSkeleton."""

    bl_idname = __package__ or "advanced_skeleton_blender"

    show_import: bpy.props.BoolProperty(default=True)
    show_build: bpy.props.BoolProperty(default=True)
    show_demo: bpy.props.BoolProperty(default=False)
    show_developer: bpy.props.BoolProperty(default=False)

    def draw(self, _context):
        # These values are intentionally controlled by the sidebar headers,
        # rather than cluttering Blender's extension-preferences page.
        self.layout.label(text="Sidebar section state is saved automatically.")


def _sidebar_preferences(context):
    addon = context.preferences.addons.get(__package__ or "advanced_skeleton_blender")
    return addon.preferences if addon else None


def _get_sidebar_state(context, property_name):
    preferences = _sidebar_preferences(context)
    if preferences:
        return bool(getattr(preferences, property_name))
    return bool(getattr(context.scene, f"advanced_skeleton_{property_name}"))


def _set_sidebar_state(context, property_name, value):
    preferences = _sidebar_preferences(context)
    if preferences:
        setattr(preferences, property_name, value)
    else:
        setattr(context.scene, f"advanced_skeleton_{property_name}", value)


class ADVANCEDSKELETON_OT_toggle_section(bpy.types.Operator):
    """Toggle one first-level section of the AdvancedSkeleton sidebar."""

    bl_idname = "advanced_skeleton.toggle_section"
    bl_label = "Toggle AdvancedSkeleton Section"

    section_property: bpy.props.StringProperty(options={"HIDDEN"})

    def execute(self, context):
        allowed_properties = {
            "show_import",
            "show_build",
            "show_demo",
            "show_developer",
        }
        if self.section_property not in allowed_properties:
            self.report({"ERROR"}, "Unknown AdvancedSkeleton sidebar section")
            return {"CANCELLED"}
        current_value = _get_sidebar_state(context, self.section_property)
        _set_sidebar_state(context, self.section_property, not current_value)
        return {"FINISHED"}


class ADVANCEDSKELETON_PT_main_panel(bpy.types.Panel):
    """Import-only AdvancedSkeleton panel."""

    bl_label = f"AdvancedSkeleton {ADDON_VERSION}"
    bl_idname = "ADVANCEDSKELETON_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AdvancedSkeleton"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        def section_header(property_name, label):
            expanded = _get_sidebar_state(context, property_name)
            row = layout.row(align=True)
            operator = row.operator(
                ADVANCEDSKELETON_OT_toggle_section.bl_idname,
                text=label,
                icon="TRIA_DOWN" if expanded else "TRIA_RIGHT",
                emboss=False,
            )
            operator.section_property = property_name
            return expanded

        if section_header("show_import", "Import"):
            import_panel = layout.box()
            import_panel.operator(ADVANCEDSKELETON_OT_import_fbx.bl_idname, icon="IMPORT")
            import_panel.operator(ADVANCEDSKELETON_OT_reload_fbx.bl_idname, icon="FILE_REFRESH")
            import_panel.separator()
            import_panel.prop(scene, "advanced_skeleton_character_scale", text="Scale")
            import_panel.operator(
                ADVANCEDSKELETON_OT_set_character_scale.bl_idname,
                icon="FULLSCREEN_ENTER",
            )

        if section_header("show_build", "Build"):
            build_panel = layout.box()
            build_panel.prop(scene, "advanced_skeleton_body_json_path", text="Body JSON")
            build_panel.operator(ADVANCEDSKELETON_OT_build_rig.bl_idname, icon="CON_ROTLIKE")
            build_panel.separator()
            build_panel.prop(scene, "advanced_skeleton_face_json_path", text="Face JSON")
            build_panel.operator(
                ADVANCEDSKELETON_OT_build_face_rig.bl_idname,
                icon="ARMATURE_DATA",
            )

        if section_header("show_demo", "Demo"):
            demo_panel = layout.box()
            demo_panel.prop(scene, "advanced_skeleton_demo_directory", text="Folder")
            file_row = demo_panel.row(align=True)
            file_row.prop(scene, "advanced_skeleton_demo_file", text="File")
            file_row.operator(
                ADVANCEDSKELETON_OT_refresh_demo_files.bl_idname,
                text="",
                icon="FILE_REFRESH",
            )
            demo_panel.operator(
                ADVANCEDSKELETON_OT_open_demo_file.bl_idname,
                icon="FILE_FOLDER",
            )

        if DEVELOPER_BUILD:
            if section_header("show_developer", "Developer"):
                developer_panel = layout.box()
                developer_panel.operator(
                    ADVANCEDSKELETON_OT_toggle_spline_ik_curves.bl_idname,
                    icon="CURVE_DATA",
                )
                developer_panel.operator(
                    ADVANCEDSKELETON_OT_face_debug_fear.bl_idname,
                    icon="TEXT",
                )
                developer_panel.operator(
                    ADVANCEDSKELETON_OT_main_scale_debug.bl_idname,
                    icon="TEXT",
                )
                developer_panel.operator(
                    ADVANCEDSKELETON_OT_reload_addon.bl_idname,
                    icon="FILE_REFRESH",
                )

        layout.separator()
        layout.operator(ADVANCEDSKELETON_OT_go_to_build_pose.bl_idname, icon="LOOP_BACK")

CLASSES = (
    ADVANCEDSKELETON_OT_import_fbx,
    ADVANCEDSKELETON_OT_reload_fbx,
    ADVANCEDSKELETON_OT_load_body_json,
    ADVANCEDSKELETON_OT_set_character_scale,
    ADVANCEDSKELETON_OT_build_rig,
    ADVANCEDSKELETON_OT_build_face_rig,
    ADVANCEDSKELETON_OT_go_to_build_pose,
    ADVANCEDSKELETON_OT_reload_addon,
    ADVANCEDSKELETON_OT_toggle_spline_ik_curves,
    ADVANCEDSKELETON_OT_face_debug_fear,
    ADVANCEDSKELETON_OT_main_scale_debug,
    ADVANCEDSKELETON_OT_refresh_demo_files,
    ADVANCEDSKELETON_OT_open_demo_file,
    ADVANCEDSKELETON_Preferences,
    ADVANCEDSKELETON_OT_toggle_section,
    ADVANCEDSKELETON_PT_main_panel,
)


def register():
    bpy.types.Scene.advanced_skeleton_body_json_path = bpy.props.StringProperty(
        name="Body JSON",
        description="AdvancedSkeleton Body Rig JSON export",
        subtype="FILE_PATH",
    )
    bpy.types.Scene.advanced_skeleton_face_json_path = bpy.props.StringProperty(
        name="Face JSON",
        description="Optional AdvancedSkeleton Face SDK JSON export",
        subtype="FILE_PATH",
    )
    bpy.types.Scene.advanced_skeleton_character_scale = bpy.props.FloatProperty(
        name="Character Scale",
        description="Uniform scale applied to the imported skeleton",
        default=1.0,
        min=0.001,
        soft_max=100.0,
    )
    bpy.types.Scene.advanced_skeleton_show_import = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.advanced_skeleton_show_build = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.advanced_skeleton_show_demo = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.advanced_skeleton_show_developer = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.advanced_skeleton_demo_directory = bpy.props.StringProperty(
        name="Demo Folder",
        description="Folder containing downloaded AdvancedSkeleton Blender demo files",
        subtype="DIR_PATH",
        default=_default_demo_directory(),
    )
    bpy.types.Scene.advanced_skeleton_demo_file = bpy.props.EnumProperty(
        name="Demo File",
        description="Available Blender demo files",
        items=_demo_blend_items,
    )
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.advanced_skeleton_body_json_path
    del bpy.types.Scene.advanced_skeleton_face_json_path
    del bpy.types.Scene.advanced_skeleton_character_scale
    del bpy.types.Scene.advanced_skeleton_show_developer
    del bpy.types.Scene.advanced_skeleton_show_demo
    del bpy.types.Scene.advanced_skeleton_show_build
    del bpy.types.Scene.advanced_skeleton_show_import
    del bpy.types.Scene.advanced_skeleton_demo_file
    del bpy.types.Scene.advanced_skeleton_demo_directory


if __name__ == "__main__":
    register()

